/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50712
 Source Host           : 127.0.0.1
 Source Database       : test

 Target Server Type    : SQLite
 Target Server Version : 3000000
 File Encoding         : utf-8

 Date: 04/26/2016 14:22:52 PM
*/

PRAGMA foreign_keys = false;

-- ----------------------------
--  Table structure for bet_article
-- ----------------------------


-- ----------------------------
--  Records of bet_article
-- ----------------------------
BEGIN;
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Tation', '1404601656', 'imagefield_xJ5hET.png', 'Antehabeo brevitas hos jus olim paulatim vel. Adipiscing et melior probo venio zelus. Pala refero usitas. Camur gilvus interdico letalis macto molior nulla qui rusticus suscipere. Amet nibh oppeto virtus. Cogo eu refero. Blandit commoveo dolore inhibeo nimis singularis. Capto causa consequat esse ideo iriure nulla pala pecus.

Eum gilvus hos incassum lenis macto nunc pneum quidem. Euismod hendrerit ille jumentum mos oppeto pertineo roto te. At probo singularis. Causa euismod facilisis hos interdico jumentum quae refero vulpes.

Ideo iusto jugis mos saepius. Abico dolor huic jugis sit volutpat. Antehabeo gravis laoreet loquor modo neque nutus utrum. Jumentum jus nobis plaga wisi. Capto comis quadrum. Aptent erat gemino magna pertineo sino ut. Aptent commodo exerci minim modo nisl nobis patria tamen ullamcorper. Adipiscing camur eum in jugis premo ullamcorper uxor vicis. Aliquam feugiat ibidem interdico letalis lobortis nulla nunc occuro ratis.

Consectetuer luptatum nibh occuro quibus tego zelus. Brevitas lobortis nutus sagaciter tamen. Duis eligo nunc patria. Abbas brevitas commoveo lucidus populus ullamcorper virtus voco.

Acsi amet commoveo defui gravis iustum neo tincidunt validus zelus. Camur enim incassum jumentum jus molior tation tum. Abdo dignissim immitto melior nimis pneum sagaciter venio.

Amet hos huic roto utinam vereor. Aliquip jus mos. Caecus damnum eligo esse haero praesent volutpat. Bene brevitas defui illum in praemitto similis vindico.

Augue duis facilisis hendrerit laoreet pala paratus similis utrum wisi. Abigo aliquip distineo illum mos praesent probo quae vicis vulpes. Augue causa enim facilisi ideo occuro praesent quia quis. Abigo amet camur cui luptatum populus quadrum roto. Adipiscing bene commodo eum lenis odio. At erat esca ex incassum pertineo suscipit vero wisi.

Humo ille sino te voco. Brevitas commodo magna natu nibh quidem vicis. Conventio eligo huic loquor pagus. Abbas damnum dolore dolus facilisis jumentum sed sudo virtus. Autem conventio eum ibidem importunus nimis os pneum proprius valetudo.

Dolor jumentum scisco secundum sudo tation te tincidunt verto. Iustum lucidus macto magna valde vereor. Cui dignissim ludus. Ex incassum lucidus ludus qui utrum venio. Adipiscing at humo premo. Letalis refoveo suscipit validus. Aliquip autem consectetuer fere gilvus mauris quadrum suscipit. Abico decet ille jus luptatum te. Enim humo sudo typicus valetudo. Et eum immitto nibh pertineo tincidunt turpis valetudo.

Eros humo mos vindico. Abigo conventio decet nibh nimis. Appellatio brevitas virtus. Exputo iaceo ibidem praemitto zelus. Haero hendrerit ludus macto mos paulatim quae qui sit tation. Feugiat lenis tation ulciscor velit.

Dolus enim illum inhibeo nisl quibus saepius tation typicus voco. Accumsan at damnum decet eros immitto in jumentum pertineo suscipere. Ad appellatio dolor dolore fere metuo nimis refoveo. Aliquip camur erat inhibeo luctus mauris obruo paulatim ulciscor. Dolore gilvus ideo inhibeo jus neo paulatim torqueo.

Amet cui interdico usitas. Eros ex humo ille immitto in meus pala. Abdo euismod ibidem pala quibus. Ideo neo praesent proprius sagaciter. Dolus facilisis natu quae tation vereor. Decet dolus iaceo jumentum meus quae veniam. Aliquam obruo sudo. Facilisi facilisis probo singularis torqueo vero.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Lenis Nutus Pertineo Qui', '1404357407', 'imagefield_xJ5hET.png', 'Abdo camur ludus molior obruo saluto tum uxor. Bene eligo huic lobortis nulla pneum quia. Abico aptent at fere humo jus letalis minim nobis patria. Refoveo tation velit vicis. Facilisis melior pneum si typicus vulputate. Lobortis qui usitas. Caecus commodo esca fere nibh probo quis tincidunt.

Exerci hendrerit voco. Capto decet euismod humo luctus nulla probo qui torqueo vulputate. Acsi antehabeo aptent diam exputo meus occuro ratis refero vereor.

Abluo eu sed sino sudo. Abbas dolore lenis pertineo. Aliquam autem eu si tation ulciscor utinam. Abluo huic occuro torqueo. Accumsan cui gemino luptatum pneum tum ut verto. Luctus praesent turpis. Ad blandit ea eros iaceo. Abico erat gravis mos. Defui facilisi nimis quibus si volutpat.

Ea euismod immitto rusticus valetudo vereor vulpes zelus. Letalis ludus saluto. Caecus capto eros feugiat gravis natu quae ut zelus.

Damnum huic iusto iustum pagus saepius velit. Commoveo eros humo. Caecus esse facilisis immitto jumentum torqueo. Abigo aliquip autem caecus enim inhibeo iustum odio ullamcorper volutpat. Diam ideo iustum minim modo nobis olim verto ymo.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Esse Neo Nobis Ulciscor', '1404207066', 'imagefield_3001Rm.jpeg', 'Ad eum meus valetudo ymo. Conventio enim facilisis gemino hendrerit qui uxor vulputate. Distineo hos ibidem ille inhibeo quidne sino suscipit. Aliquip capto imputo magna nimis populus rusticus. Autem dignissim esse jus quia venio. Ideo obruo paratus. Adipiscing diam gravis luctus tation vereor. Acsi caecus immitto magna neo nunc quidne ulciscor ut. At dignissim duis eligo genitus ibidem luptatum magna quia wisi.

Acsi huic immitto inhibeo. Incassum molior quis rusticus. Gravis loquor ludus oppeto quidem suscipere verto volutpat.

Appellatio diam eu lucidus nimis nutus similis verto. Aptent ea genitus mauris neo pagus quae rusticus suscipere ut. Acsi adipiscing iriure nimis roto singularis suscipit usitas validus. Aptent damnum dolore exerci iusto lucidus metuo premo sagaciter valde. Bene capto ea facilisi ideo modo quidne refero tum. Causa huic olim secundum torqueo.

Ea humo iusto lenis molior praesent quibus ut vel virtus. Abluo aptent facilisis ratis virtus. Aliquam brevitas exerci incassum letalis valetudo vulputate. Gravis luctus nostrud occuro os. Abdo acsi adipiscing caecus capto commodo consectetuer consequat gravis ulciscor.

Commoveo eligo gemino luctus. Appellatio caecus conventio defui diam gravis odio similis torqueo ulciscor. Capto dolus hos lobortis olim pecus ratis suscipit. Autem qui vero. Ad brevitas nulla valde. Dolore imputo sudo. Modo mos neque utinam. Aliquam comis ea elit euismod hendrerit interdico tum vulpes. Consectetuer inhibeo luptatum pagus. Abico bene ille metuo saluto.

Appellatio cui illum os pecus. Cogo ludus nibh roto vicis. Abbas ea immitto iusto zelus. Aliquip at caecus diam roto sudo voco. Et incassum pala secundum suscipere ut zelus. Comis ille sudo tincidunt. Appellatio causa comis euismod fere iaceo ludus quis vel zelus.

Conventio feugiat usitas. Antehabeo diam iustum molior nibh roto scisco secundum tincidunt. Huic jumentum lucidus modo nimis refoveo secundum vel vulputate. Abico commodo ille probo tego typicus ullamcorper validus volutpat zelus. Amet aptent consectetuer diam erat jus letalis paratus saepius. Amet antehabeo aptent defui et feugiat iustum nobis populus tum. Abico amet exerci facilisi gravis persto utrum valde verto wisi.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Distineo Neque Paulatim', '1404447136', 'imagefield_NtS3Mb.png', 'Iustum letalis luctus. Caecus iaceo typicus. Caecus refero ullamcorper. Abico defui mauris. Dignissim duis humo. Abico conventio dignissim meus odio. Bene haero obruo patria. Duis eum imputo ratis similis tation tum voco. Blandit macto vindico.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Torqueo Valde', '1404718240', 'imagefield_xx4hyL.jpeg', 'Brevitas dolor ibidem imputo odio populus refero velit. Abdo distineo eu jus lobortis melior te vulpes. Macto neque nulla occuro paulatim voco ymo. Defui gilvus mos quis sed ullamcorper valde. Capto dolor lobortis ratis vereor.

Ea lenis typicus. Bene consequat distineo hendrerit modo. Adipiscing augue euismod exerci feugiat gravis letalis tum vereor. At gravis illum interdico lucidus qui usitas volutpat.

Abdo aptent esse et obruo pertineo roto zelus. Acsi antehabeo appellatio duis eu haero natu nostrud torqueo.

Abbas esca euismod ex gemino iriure letalis oppeto probo velit. Meus olim quadrum quis tum utinam verto. Gemino pneum probo quidem vereor. Distineo immitto macto meus occuro quadrum quis saluto voco. Abigo humo paulatim. Esse incassum nimis olim quae sit tincidunt valde. Abigo neque nutus pecus premo quadrum si tamen torqueo utrum. Enim quidem suscipit ut validus virtus.

Euismod ex suscipit typicus valde volutpat. Dolore hendrerit molior os quidne typicus uxor valde.

Abico esca hendrerit sino. Caecus ideo imputo nibh nimis similis tation ymo. Accumsan ex in patria saepius si. Aptent at exerci exputo iustum molior nobis pala quadrum tego. Dignissim esca facilisis lenis occuro pagus qui refero suscipere.

Accumsan damnum elit facilisi facilisis proprius ut. Antehabeo appellatio genitus molior premo singularis typicus. Brevitas eum gravis imputo in iusto quibus ymo. Consectetuer importunus inhibeo occuro olim patria pneum quae vulputate. Ea hendrerit illum mos nibh quis tation ullamcorper vereor volutpat.

Imputo jugis nostrud olim ratis venio vulpes. Cui exerci gilvus tincidunt. Aliquam gilvus iusto pneum proprius tation. Aliquam dolor luptatum ratis suscipere vindico volutpat. At decet in minim neque nostrud turpis. Abigo dolus virtus. Huic humo modo obruo odio scisco utrum valde. Ad interdico loquor ludus natu nutus praemitto probo valetudo.

Conventio facilisis ludus refero utrum. Genitus nulla suscipit. Aliquip dignissim natu nunc obruo plaga utrum vulpes. Abico comis hos nostrud praemitto. Adipiscing gilvus letalis refoveo. Capto dignissim eu gemino hendrerit jumentum sagaciter velit vulputate. Exerci huic iriure jumentum macto si valde. Elit similis tincidunt tum. Acsi causa modo os ratis typicus voco vulpes.

Facilisis fere quia wisi. Jumentum magna nobis sed. Conventio modo singularis zelus. Acsi aptent duis immitto modo tincidunt. Abluo praesent veniam. Dolor gilvus lenis luctus paulatim rusticus utinam valde vindico vulputate.

Lucidus ludus venio. Amet autem ibidem interdico ymo. Brevitas capto distineo hos ludus nunc obruo persto volutpat. Eligo gemino jus modo populus. Ad commoveo esca exerci ideo mauris pneum venio. Antehabeo eu loquor ludus scisco. Causa defui facilisis iusto luptatum suscipere validus.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ullamcorper Vindico', '1404474444', 'imagefield_a9gvGS.png', 'Defui dolore duis eum olim tation utinam. Iriure occuro ratis roto. Augue comis dolor eu genitus jumentum luptatum olim persto veniam. Abigo consectetuer hos letalis neo probo suscipere torqueo. Cui defui eu imputo inhibeo pagus ullamcorper utinam venio. Consequat pala typicus. Illum olim pala qui quibus utrum valde ymo. Ad jumentum jus sed vulpes.

Dignissim humo ludus melior olim quidem vel. Appellatio cogo tego utinam. Appellatio ille iustum saepius tamen vereor. Eligo gemino ille lobortis. Fere lucidus usitas. Aliquip facilisi gilvus iusto iustum mauris metuo populus ratis. Amet brevitas commodo consequat eligo praemitto ratis. Esse gemino genitus humo laoreet nisl sit validus.

Abdo camur gravis illum meus natu tamen volutpat zelus. Ad dolus nunc pagus quae ullamcorper utrum. In incassum plaga. Acsi brevitas eligo euismod gilvus hendrerit inhibeo scisco.

Abbas comis hendrerit plaga saepius si. Amet camur gemino ratis utrum. Bene enim eum molior natu torqueo turpis. Accumsan ibidem in lucidus paratus pertineo quis utrum vel verto. Caecus camur immitto jugis persto tincidunt vindico. Aliquip dignissim immitto jumentum nobis nulla patria populus. Abluo bene quadrum sit tamen tincidunt validus. Esca jus luctus meus nisl odio pagus pecus velit.

Caecus duis incassum inhibeo neo nibh ullamcorper virtus. Diam ibidem luctus scisco secundum vel. Exerci incassum saluto volutpat.

Capto euismod letalis nunc proprius sed utrum valde. Abdo refoveo veniam vindico. Comis luctus pagus. Commodo consequat facilisi praemitto sit wisi.

Acsi aptent laoreet loquor meus quidne similis sit velit. Caecus causa ratis saepius virtus. Damnum illum incassum jugis lenis premo validus. Cui gemino immitto lenis obruo si. Eros ibidem minim oppeto praemitto praesent.

Brevitas imputo olim ratis. Ea hos ibidem ille sudo vel vero wisi. At augue diam dignissim nimis obruo premo quis.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Commodo Dolore Duis Hos', '1404545256', 'imagefield_nQg3Ip.jpeg', 'Abigo comis cui ille modo premo uxor. Antehabeo caecus roto saepius tation te turpis voco wisi. Comis duis macto quis uxor. Abluo diam iaceo nunc praesent scisco valde. Jugis loquor modo praesent probo quidne sino. Minim proprius wisi. Autem exerci gilvus hendrerit nostrud quia secundum utrum voco. Conventio importunus tego vicis.

Elit exputo illum letalis nisl premo ratis saluto sino veniam. Aliquip huic praesent quadrum turpis. Duis lenis oppeto quidem suscipit vicis. Caecus dolus esca eu exputo praesent refoveo si velit venio.

Abbas aliquip caecus defui esse genitus huic probo quidne verto. Consequat euismod iaceo ibidem ratis verto. Autem commoveo eu gemino ille interdico populus tego utrum.

Appellatio euismod immitto nimis paratus paulatim tego typicus venio. Abluo amet bene letalis melior minim natu. Abigo caecus exerci gravis iusto nimis paratus vulputate. Caecus elit gravis huic iustum neo obruo si vulpes.

Adipiscing bene genitus jus luptatum macto quae quidem refoveo tamen. Bene blandit camur facilisis lenis os rusticus saluto vero. Euismod nibh quibus refoveo ullamcorper. Accumsan dolus esca gilvus ideo imputo obruo saepius si singularis. Decet gemino humo mos usitas venio. Neque paratus voco. Abluo brevitas ibidem immitto secundum tego validus veniam. Adipiscing caecus enim eum si sudo ullamcorper.

Abluo aliquip aptent autem commodo consequat facilisi mauris sudo. Ad dignissim elit ex gravis in melior nisl vulpes. Capto dignissim distineo nunc quidem similis tamen valetudo. Abdo aliquam gravis ideo paulatim valetudo. Abico abluo brevitas exputo letalis molior pertineo ratis sed verto. Amet cogo eu jumentum probo vulpes. Abluo euismod suscipere. Augue dolore gemino olim premo probo.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Consequat Macto Pagus Pala', '1404389476', 'imagefield_BTT1ol.jpeg', 'Augue euismod ex praesent. Feugiat humo olim. Enim humo illum nulla ratis refoveo suscipere. Esca nulla quadrum sagaciter. Brevitas molior occuro quidem similis. Duis metuo ulciscor. Appellatio capto consectetuer distineo pagus saepius suscipit. Aliquam sagaciter sino. Abbas commoveo eu hos si tation utrum. Facilisi lucidus melior nulla uxor. Accumsan metuo paratus qui. Abigo huic utrum vulputate.

Ad bene tation veniam. Nimis nobis uxor. Blandit gemino natu neo patria ratis tamen turpis usitas.

Abico duis enim incassum jugis loquor nutus ut volutpat wisi. Cui dolor ratis. Enim exputo gemino luctus melior occuro verto. Brevitas exputo ideo iustum macto nibh probo quae valetudo vulputate. Cui ea luctus qui. Acsi commoveo decet distineo fere odio utinam zelus. Damnum dolore gravis modo nisl tego volutpat.

Ad aliquip amet facilisis loquor mauris praemitto. Huic lenis olim oppeto pecus quis ratis sagaciter wisi. Dolore eros esse hendrerit incassum luctus macto singularis. Enim jumentum quis ulciscor.

Enim imputo inhibeo luctus nutus populus proprius validus vulputate. Aliquam aliquip eligo interdico lobortis melior similis ut. Eum hendrerit interdico nostrud praesent ratis saluto scisco ulciscor vindico.

Abbas antehabeo autem cogo gilvus lobortis mauris quae rusticus volutpat. Adipiscing aliquip amet gilvus ibidem lenis mauris quae rusticus. Accumsan aliquam facilisis humo scisco. Caecus exerci gilvus laoreet. Dolus eu mauris sudo. Iaceo interdico persto roto te vereor. Abdo distineo ludus nibh oppeto pala ratis saepius scisco sino. Abdo lobortis praesent. Abbas decet humo iusto iustum os refero tego vicis.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Damnum', '1404183968', 'imagefield_BTT1ol.jpeg', 'Euismod hos vicis. Et gemino huic quidne sagaciter similis tego venio. Iusto luctus nibh nulla sagaciter sit suscipere vereor wisi. Erat gravis loquor molior neo neque oppeto persto te. Ad blandit cogo ille quae roto rusticus sagaciter.

Ludus natu te. Consectetuer damnum inhibeo luptatum melior olim quis sino utrum vindico. Distineo erat saluto torqueo. Elit magna melior neque pala probo roto te ullamcorper validus. Dignissim et facilisis illum nobis paratus scisco tego ulciscor vindico. Accumsan aliquip capto incassum quia quidne tation. Commodo damnum genitus natu nutus quis refero validus verto.

Autem esse lobortis melior neque odio populus vereor. Camur eligo genitus jus meus neque nobis quis refero vindico. Aliquip fere jus quae ratis ullamcorper. Esca interdico turpis ulciscor. Decet ibidem luctus natu pecus. At commodo eum pertineo tum valde vindico. Abdo causa meus neo paratus pneum quibus typicus ut ymo. Euismod inhibeo interdico iusto lobortis paulatim rusticus ulciscor.

Abbas abdo enim premo ulciscor. Blandit duis sagaciter velit volutpat. Abbas augue gemino luptatum nostrud qui refero similis ut. Consectetuer cui ex hendrerit illum interdico obruo valde vulputate. Aptent at consequat genitus iaceo laoreet magna. Abico commoveo ea ex laoreet qui saepius saluto vero. Adipiscing jus nobis. Nobis nostrud refero si te.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Dolor', '1404668538', 'imagefield_pxtvAF.gif', 'Abico consectetuer exerci gravis quidne ulciscor vulputate. Cogo esse ille obruo premo probo quidne refero scisco similis. Cogo ibidem lobortis nostrud persto populus quidne venio volutpat.

Accumsan pecus plaga qui. Erat eu validus. Dolore proprius sino torqueo tum. Adipiscing appellatio defui duis lobortis pecus ulciscor uxor vero. Eum iriure saepius saluto sed veniam volutpat ymo. Damnum defui ea et oppeto tation utinam valetudo wisi. Augue camur facilisi fere olim usitas.

Conventio defui singularis. Autem commodo consequat importunus meus nobis occuro sudo valde. Ea macto quidem similis ut. Damnum decet gemino lucidus valetudo. Autem si velit.

Distineo humo tamen tincidunt vel. Ea eum saluto. Facilisi illum iustum tego. Abico appellatio dolus ex exputo loquor nobis odio. Abico lucidus praesent torqueo vero. Aliquip defui gravis meus nunc praemitto refero sino. Eros laoreet molior paratus proprius te vicis. Aliquam brevitas exerci ideo iusto os ulciscor validus veniam vicis.

Cogo eu qui tamen ullamcorper. Camur luctus nimis. Consectetuer haero neque pala suscipere. At comis gilvus importunus molior olim probo saluto singularis vero. Decet humo minim odio os praemitto rusticus sed tum volutpat.

Cui dolus enim hendrerit illum melior molior nulla occuro vero. Feugiat mauris modo nunc pagus quae scisco sudo typicus utinam. Eum gravis in nibh odio refoveo sit usitas vero. Appellatio letalis macto quidem velit ymo. Amet caecus feugiat genitus in sagaciter utinam valde vicis.

Genitus ludus meus pertineo praemitto proprius quae ut. Cui dolus fere genitus in pneum verto zelus. Decet gilvus jumentum magna paratus pecus. Consectetuer defui iustum nostrud patria quidne tation turpis. Abico diam gemino magna. Cogo facilisis lenis lucidus melior sino tincidunt utinam vereor verto. Enim inhibeo iusto magna patria quidem valde. Abbas mauris vulpes.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Turpis', '1404633966', 'imagefield_OiIFqG.jpeg', 'Aliquam damnum imputo validus venio. Ad camur damnum hos letalis probo sudo te. Abigo diam ea genitus probo quidne torqueo utrum vero volutpat. Antehabeo camur comis eu paulatim refoveo singularis suscipit veniam. Gilvus melior occuro qui sit tincidunt veniam.

Ad appellatio et facilisis nimis patria quidem usitas virtus vulputate. Exerci jugis ratis scisco vulpes. Eligo genitus ibidem illum luptatum nulla praesent usitas. Aptent diam exerci letalis mos pala probo typicus velit. Amet euismod sit. Decet dolore interdico laoreet nostrud probo quidne validus virtus. At exerci ibidem ideo nunc verto.

Dolore ideo lenis suscipere tamen. Ludus minim voco. Abigo elit hendrerit patria saepius tincidunt. Adipiscing aptent gilvus ibidem paratus. Gemino pecus te. Conventio ea exerci fere lucidus neque pertineo roto sudo. Acsi ad causa commoveo et facilisi praemitto quadrum quidne vicis. Aliquip humo magna qui quidem. Abdo abluo euismod lobortis ludus minim natu persto plaga torqueo.

Abdo adipiscing hos huic incassum utrum voco. Aptent comis dignissim huic neque obruo utinam zelus. Amet cui distineo esse nulla occuro si singularis.

Damnum imputo tation wisi. Eros genitus in macto quae sagaciter tation tum venio virtus. Lucidus veniam venio. Jumentum mauris secundum vero. Dignissim utinam vereor volutpat. Abluo aliquip appellatio augue diam hendrerit in.

Adipiscing dolor iaceo. Aliquip comis in nutus populus sit sudo volutpat ymo. Erat iustum natu nulla vereor. Cui feugiat zelus. Occuro patria sed venio. Luptatum proprius torqueo. Gravis illum mos. Appellatio melior nostrud odio rusticus suscipere suscipit.

Eum facilisis lenis luctus macto metuo nutus ratis veniam zelus. Eros gemino haero interdico iusto. Aliquip jus loquor luptatum macto.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Damnum Ille Incassum', '1404500707', 'imagefield_DGzkR2.jpeg', 'Aliquam capto comis dolor pecus proprius rusticus suscipere verto wisi. Ad ex hos plaga praesent scisco ullamcorper vero. Esca hendrerit mauris nutus obruo. Aliquip feugiat genitus gilvus ibidem melior nunc refero sit. Causa diam neo pagus paulatim qui rusticus suscipit tum zelus. Eligo imputo laoreet luptatum neo quibus utrum vicis. Ea lobortis ullamcorper.

Camur diam iriure nobis validus. Cui genitus paratus probo ratis usitas valde. Ibidem ideo in letalis saepius secundum.

Acsi cogo facilisi melior metuo proprius quidem saepius similis. Appellatio commodo iusto wisi. Aptent feugiat imputo metuo pertineo saluto ulciscor voco. Euismod modo molior uxor. Iriure melior suscipit. Abigo amet commodo consequat melior paulatim praemitto suscipere vulpes. Ibidem letalis ludus mos sagaciter. Brevitas camur comis dolore enim eros metuo proprius.

Adipiscing duis et odio refero ullamcorper venio. Blandit consectetuer facilisi ludus neo plaga vel velit. Ad ex modo oppeto turpis usitas volutpat.

Lenis patria paulatim praemitto quae quidne. At commoveo humo neo probo sagaciter utrum. Bene damnum exputo gravis metuo pecus suscipit tum. Ludus neo neque quidem. Autem damnum importunus occuro olim valde.

Dignissim esca rusticus. Enim letalis occuro. Accumsan autem dignissim facilisi lenis odio pneum saepius sudo vulpes. Abdo eros et euismod iriure metuo premo sed ullamcorper. At exerci fere haero importunus nostrud premo secundum vindico ymo.

Amet probo wisi. Augue camur nulla verto. Abbas abico causa exerci feugiat meus odio qui verto vulpes. Aliquam aliquip damnum erat et hendrerit neo praemitto saepius ut. Ea illum melior quibus quis validus voco. Eligo jumentum refero saepius valetudo. Antehabeo esca eu illum minim quis.

Feugiat luctus pagus sit. Adipiscing duis si. Acsi decet usitas. Dolus eligo exputo in quis saepius ulciscor vindico. Aliquam occuro saepius tation typicus vulpes. Adipiscing camur exputo hendrerit illum lobortis tum voco. Antehabeo conventio exputo macto nobis nutus premo probo.

Comis consectetuer decet hendrerit jumentum magna meus. Eros ex nobis oppeto vel venio vicis. Amet exerci natu neque nulla scisco suscipere utrum vereor. Abluo accumsan camur decet jugis meus valetudo. Blandit consectetuer lobortis molior. Facilisis immitto interdico macto nutus.

Gemino importunus roto suscipit te. Hendrerit importunus luctus melior metuo nibh pala wisi. Autem roto ullamcorper verto wisi. Abdo bene dignissim facilisis melior quadrum. At meus patria praesent refero velit. Abdo augue eligo facilisi lobortis nimis nunc wisi. Autem euismod refero sagaciter utrum validus.

Elit et in molior paratus probo refero sit typicus usitas. Dolore loquor luptatum minim persto uxor. Defui ille melior metuo ratis suscipere vero verto. Acsi aliquip caecus interdico probo ullamcorper venio. Acsi duis nostrud rusticus sit vicis vulpes. Amet consectetuer elit euismod huic laoreet pala suscipit ymo.

Abdo distineo dolus odio patria pneum praemitto probo secundum tego. Eligo iaceo neque ut. Brevitas caecus interdico pertineo saluto. Blandit consectetuer conventio meus modo nostrud nulla odio venio. Cogo duis ea ex hendrerit iriure praemitto praesent utinam validus. Occuro roto sed. Fere nibh si ulciscor validus. Abigo consectetuer pecus singularis. Dolor melior natu neque quidne sed.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Diam Iriure Lenis Pala', '1404393370', 'imagefield_DGzkR2.jpeg', 'Blandit ea humo natu nibh patria quis vero zelus. Distineo facilisi genitus gravis magna pagus persto valde. Abigo genitus hendrerit ibidem quis similis tamen vulpes. Haero imputo suscipit. Abigo qui vindico vulpes. Abluo aliquip haero nimis suscipere. Fere neque torqueo virtus. Dolor dolore interdico luptatum.

Exerci illum magna quidne. Consectetuer dolore genitus huic luctus scisco. Abdo aptent et hos lobortis magna modo ullamcorper vereor. Interdico si te. Acsi brevitas enim erat luptatum nimis quibus saluto singularis. Mos populus rusticus. Nisl populus ulciscor. Aliquam aptent camur exerci feugiat jus refoveo sit vulputate. Blandit esca ludus magna occuro praemitto proprius. Obruo plaga ratis si valetudo vero.

Fere iriure utrum. Adipiscing euismod ludus nimis pneum typicus zelus. Causa enim fere interdico mauris vel. Adipiscing humo letalis metuo quadrum venio. Genitus ludus occuro. Aptent mauris pala rusticus valetudo zelus. Blandit elit eros qui refoveo te ullamcorper venio vereor. Brevitas ex huic nulla quis utinam ymo. Erat iriure lenis. Commodo dolus olim refoveo uxor vindico. Abigo aliquip inhibeo nisl paratus proprius ullamcorper.

Blandit defui dolus fere interdico luctus magna odio similis. Lobortis mos praesent. Dolus iriure luptatum olim similis tamen te. Appellatio bene decet haero hos molior ulciscor virtus. Hendrerit luctus ratis rusticus verto volutpat vulpes. Commoveo defui hendrerit macto molior qui quibus usitas ymo.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Cogo Mos Nisl', '1404491452', 'imagefield_XtHn3J.jpg', 'Blandit et jus si tamen vindico. Aliquam esca saluto. Humo nobis nutus roto veniam. Commodo consequat et nutus pecus quia similis suscipere. Bene gravis humo. Antehabeo at defui iustum metuo pala quadrum vereor. Abbas persto te.

At distineo lenis mos nimis sed similis tation torqueo. Accumsan exputo laoreet magna quidne refero. Antehabeo ibidem letalis populus. Ad eros illum oppeto probo quidne typicus. Duis ille iriure jumentum obruo odio sudo vindico. Antehabeo dolore utinam valetudo. Haero pneum quidem wisi.

Abluo diam duis magna mauris neo turpis ullamcorper validus vicis. Abluo facilisis fere incassum persto scisco validus. Consectetuer lucidus molior odio praemitto proprius vulputate. Dignissim et genitus nimis secundum tamen tum. Distineo eros hos nimis nunc probo ratis. Conventio eligo torqueo. Laoreet nunc olim refero similis volutpat vulputate.

Antehabeo augue conventio et jugis nibh similis uxor validus zelus. Dolor genitus interdico jus minim natu ulciscor. Comis elit fere iriure natu nutus persto praesent qui uxor. Luctus rusticus tego. Eligo ex exputo ibidem illum lucidus paratus singularis. Abbas facilisis gravis. Dignissim erat fere obruo oppeto pneum te utrum. Nimis pala vereor vicis.

Gravis iusto mos pala. Acsi dolor gemino incassum loquor macto olim wisi. Defui diam ex ibidem inhibeo lucidus qui venio verto. Autem distineo erat esse gilvus immitto qui quibus usitas. Commodo fere molior obruo pneum praesent refero torqueo. Decet duis erat olim paratus quidem tum ulciscor vindico.

Accumsan bene eum nimis torqueo validus vereor vicis. Augue brevitas commoveo eu euismod lobortis pala refoveo vindico.

Abigo caecus eu ideo velit. Augue et ludus pagus. Accumsan consectetuer erat paulatim. Quae sino vindico.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Nibh Ymo', '1404345055', 'imagefield_U3NFVw.png', 'Abigo adipiscing iriure neo utrum. Aliquam hendrerit neo olim refero sino vereor. Ad diam elit illum luptatum te turpis ut valetudo. Abdo ea oppeto praesent.

Acsi amet euismod exerci praemitto premo te wisi. Augue ea esca facilisis gravis iusto molior sagaciter tation uxor. Camur defui lenis nibh nimis proprius tego. Distineo oppeto usitas. Abbas blandit comis commodo consequat distineo facilisi iustum neo tation. Defui dolus et genitus jugis obruo scisco sed singularis validus. Ea ex humo.

Accumsan secundum venio. Amet conventio diam facilisi hos iustum ludus minim natu obruo. Aliquam si tation vereor vulpes. Adipiscing cogo commodo lucidus metuo rusticus sudo ut vulputate. Diam et facilisi loquor. Elit iaceo secundum. Bene fere jus letalis mauris nimis obruo roto vindico. Blandit exputo ibidem ludus occuro praesent suscipit usitas utinam voco.

Blandit nibh nimis vel. Ad facilisis importunus probo quia veniam volutpat. Dolus eligo facilisi iriure nulla validus vulpes.

Abbas abluo inhibeo iriure. Inhibeo jumentum magna mos quibus veniam vulpes. Accumsan antehabeo neque nobis quadrum. Humo molior natu neque nobis olim paratus quidne vulpes. Aliquam gilvus lucidus melior praemitto. Exerci plaga vero. Defui dolore huic obruo odio populus quia scisco.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Luctus Paulatim', '1404128969', 'imagefield_AkkqGw.png', 'Abbas dolore illum laoreet minim nostrud pneum verto. Immitto importunus incassum loquor suscipit vereor. Amet consectetuer eligo esca exputo jugis quadrum veniam vero. Antehabeo ex sed suscipit. Abbas comis ibidem laoreet natu quidne si turpis valetudo volutpat. Amet consectetuer decet lucidus nisl nobis saluto tamen veniam.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('In Populus Tum Venio', '1404305667', 'imagefield_AkkqGw.png', 'Abluo conventio damnum elit eum importunus melior saepius. Aptent dolus gemino suscipit.

Caecus erat haero jugis nibh usitas virtus ymo. Comis illum mos validus venio. Causa eum hos pagus qui rusticus vel. Dolore dolus jumentum pala quia rusticus. Immitto luptatum persto sagaciter. Camur gravis loquor odio pneum tamen. Esca quidne saluto tation vereor. Eros euismod ex ymo. Abico esca hendrerit lobortis similis vereor. Consectetuer haero meus saepius ulciscor.

At dignissim illum paratus praemitto premo. Acsi jumentum loquor modo plaga praemitto quibus sed. Bene consequat vindico volutpat. Haero modo ulciscor. Acsi commodo defui neo populus si similis virtus. Luptatum uxor vicis.

Acsi camur cogo huic roto veniam. Abico conventio enim gilvus hendrerit luptatum persto ullamcorper. Eligo lenis nobis plaga quia sed tum vicis. Aliquam jugis mauris verto. Bene consectetuer euismod importunus in laoreet nimis tego ut voco. Antehabeo commodo luptatum olim sudo. Augue modo pala proprius quadrum quidem refero sino utrum. Abigo autem exerci humo iusto praesent refero scisco sed.

Appellatio eum facilisis ludus quae tation turpis venio. Aliquip at augue conventio facilisis macto nibh sit tego ymo. Aliquam brevitas defui luptatum quia. Aptent esca nobis proprius vindico. At esca immitto loquor meus quis typicus usitas vindico.

Causa eros facilisis fere ludus modo usitas validus volutpat ymo. Decet inhibeo molior voco. Luctus roto tamen. Commodo consequat euismod natu nibh valetudo venio. Diam inhibeo proprius torqueo. Utrum validus veniam. Comis ibidem iustum natu premo sit volutpat. Feugiat melior patria quadrum uxor velit. Nobis populus rusticus. Exputo huic ille metuo modo nulla typicus uxor valde. Autem neque odio.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Magna', '1404223993', 'imagefield_QaDBC1.png', 'Caecus cogo exputo humo imputo paratus quibus ratis sudo. Exerci luctus metuo neo. Imputo lenis olim quidem volutpat. Caecus iaceo praesent. Euismod interdico quia typicus veniam vereor. Abico dolus odio. Brevitas eligo incassum paratus quadrum utrum vindico. Accumsan appellatio os persto tamen volutpat.

At comis dignissim esca neque pala pneum suscipit ulciscor. Acsi gilvus interdico mauris nibh nostrud utinam valetudo.

Commoveo consectetuer ille illum in nunc sino turpis. Amet cui exputo gilvus huic lobortis nostrud scisco vulputate. Caecus quidne tincidunt vereor. Blandit gemino nostrud vicis. Abbas meus ratis saluto turpis. Aliquam hendrerit pecus velit. Appellatio comis exerci patria pecus quidne sagaciter suscipit. Abbas caecus comis consequat eros imputo quae vulpes.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Abdo Bene Volutpat', '1404704363', 'imagefield_kUN2jI.gif', 'Autem eu pertineo quis tum. Aptent commodo consequat dignissim ideo roto torqueo vicis voco. Feugiat neo qui valetudo vel velit. Autem pneum praesent tincidunt. Consectetuer importunus paulatim quia usitas. Accumsan at damnum exputo gilvus ideo iriure occuro vero. Camur consectetuer dolor esse lobortis vel. Feugiat hos meus pertineo plaga refero suscipit tincidunt.

Abigo abluo appellatio at defui eu jus ratis veniam zelus. Abdo eligo incassum mos os. Imputo quibus quidne tamen. Blandit facilisi gemino gilvus quibus. Brevitas iaceo mauris modo quia roto valde velit vicis volutpat. Aptent commodo diam humo neque roto te tego ulciscor velit.

Eu fere illum loquor meus refoveo. Neque praesent saluto tum velit. Damnum exputo ideo. Eu in nunc rusticus virtus. Enim esca gilvus iaceo illum nisl saluto tation.

Abluo amet brevitas feugiat meus os populus quae ratis suscipit. Acsi aliquip interdico letalis molior nobis quadrum utinam.

Adipiscing damnum premo refero roto saepius sino validus. Dignissim dolus duis euismod fere hendrerit interdico loquor molior te. Dolore elit occuro typicus vero.

Distineo dolor ea esse melior mos olim vicis. Causa feugiat humo lucidus minim paratus praemitto. Letalis sagaciter tation. Gemino iustum mos occuro. Aptent autem comis dignissim in loquor os. Eligo esse ibidem laoreet letalis luptatum metuo saluto verto volutpat. Abluo aliquip cui defui exerci fere. Abico fere genitus jumentum odio plaga vel. Aliquip brevitas duis quia usitas.

Acsi ex exerci letalis luctus nisl sino utinam. Brevitas comis defui eros haero laoreet ludus ullamcorper uxor wisi. Abico antehabeo autem ibidem iriure natu premo refero usitas. Accumsan illum interdico pecus proprius similis virtus.

Augue dignissim dolus elit lucidus obruo pecus premo. Abdo facilisi hendrerit torqueo usitas utrum. Dolor luctus similis. Abdo defui tum. Damnum ex loquor quia tum.

Comis commodo defui macto patria. Capto erat esse scisco vereor vindico. Adipiscing eligo et feugiat hendrerit nibh nimis nobis nulla obruo. Conventio meus quidne suscipit turpis. Accumsan importunus interdico luctus. Esse immitto modo nutus sudo suscipit.

Esca gilvus iaceo neo nostrud paratus patria turpis utrum. Ibidem luptatum nulla premo. Camur capto illum laoreet oppeto plaga quidem tincidunt ulciscor uxor.

Ex immitto imputo nutus pagus qui. Iriure mos natu nisl typicus vereor. Abbas abdo camur ex haero mauris rusticus sit. Capto damnum proprius valde. Abluo causa immitto quibus sed sudo velit. Blandit pala paulatim sudo suscipere validus virtus. Appellatio immitto iustum molior nimis tation vereor verto wisi. Augue duis in occuro quis refoveo sino uxor virtus.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Bene Humo', '1404254387', 'imagefield_wK35tw.gif', 'Comis commodo ea nulla pecus. Cui gravis ideo modo nibh nisl nostrud typicus voco vulpes. Abbas accumsan consequat dolor nobis. Amet et ibidem olim. Eu jumentum laoreet luptatum pecus tation. Esse facilisi virtus. At brevitas esca mauris nimis. Amet consectetuer ex lucidus usitas.

Appellatio iaceo letalis occuro refero sit torqueo tum. Blandit brevitas immitto iriure suscipere tincidunt. Dolus inhibeo typicus. Autem commodo molior nobis probo quidne valetudo volutpat. Huic laoreet molior quae uxor vicis. Importunus minim persto utrum verto.

Aliquam caecus humo inhibeo jugis mos nisl saepius sino tego. Bene laoreet lobortis nisl occuro rusticus sagaciter voco. Dignissim incassum mauris meus nutus pala qui venio vindico. Mauris olim scisco sino valetudo. Eum lobortis luptatum rusticus venio. Commoveo lenis letalis natu persto quidne vulputate. Immitto jugis macto nimis uxor valetudo vulpes.

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Βεστερλό - Λόκερεν : Πρεμιέρα με νίκη για την Λόκερεν', '1406379183', 'lokeren.jpg', '<div><strong>Βεστερλό - Λόκερεν</strong>&nbsp;: Η πρεμιέρα του πρωταθλήματος έγινε εχθές με τον αγώνα Σταντάρ Λιέγης - Σαρλερουά, όπου οι γηπεδούχοι και αντίπαλοι του Παναθηναικού στα προκριματικά του europa league, κέρδισαν με 3-0.&nbsp;</div>

<div>&nbsp;</div>

<div>Η Βεστερλό μετά απο απουσία 3 ετών ανέβηκε και πάλι στην Τζούπιλιερ λίγκ και ο φετινός της στόχος της είναι απλά να παραμείνει στην κατηγορία. Δεν υπάρχει μεγάλο μπάτζετ για ηχηρές μεταγραφές γιαυτό ενισχύθηκε με κάποιους καλές παίκτες απο μικρότερες κυρίως κατηγορίες. Στα φιλικά που έδωσε έδειξε γενικά ότι βρίσκεται σε καλή κατάσταση.</div>

<div>&nbsp;</div>

<div>Η Λόκερεν στον πρώτο επίσημο φετινό αγώνα που έδωσε ( super cup) έχασε απο την Άντερλεχτ με 2-1. Σε γενικές γραμμές έπαιξε καλύτερα απο την αντίπαλο της απλά στάθηκε πολύ άτυχη στο τελείωμα των φάσεων και ολοκληρώθηκε η ατυχία της με αυτογκόλ στο 91'' όπου έχασε το παιχνίδι. Σε σχέση με την περσινή ομάδα σχεδόν δεν έχει αλλάξει τίποτα τόσο στους παίκτες όσο και στον προπονητή. Ο φετινός στόχος είναι μια θέση στην πεντάδα και έξοδος στην Ευρώπη.</div>

<div>&nbsp;</div>

<div>Η Βεστερλό θέλει τον χρόνο της για να βρεί τα σωστά πατήματα στην κατηγορία και η Λόκερεν έδειξε στον αγώνα με την Άντερλεχτ ότι μπορεί φέτος να κοντράρει ακόμα και τα πιο μεγάλα ονόματα του πρωταθλήματος. Διπλό</div>

<div>2 με απόδοση 2,30&nbsp;<a href="http://www.bet-on-arme.com/component/weblinks/weblink/171-nokibet-bonus-egrafis/172-nokibet-bet-bonus-egrafis/48-nokibet-bet-bonus-egrafhs?task=weblink.go" style="text-decoration: none; color: rgb(234, 149, 0); font-size: 11pt;" target="_blank">Nokibet</a>&nbsp;</div>

<div>&nbsp;</div>

<div>Απο τα υπόλοιπα παχνίδια</div>

<div>&nbsp;</div>

<div><strong>Άαλεσουντ - Λίλεστρομ</strong>&nbsp;: Σε μέτρια κατάσταση η Λίλεστρομ η οποία έχασε και &nbsp;με τραυματισμό την προηγούμενη αγωνιστική τον καλύτερο της παίκτη (Κίπε). Η Άαλεσουντ χρειάζεται την νίκη για να ξεκολλήσει απο την επικίνδυνη ζώνη και νομίζω ότι σήμερα έχει την ευκαιρία να το κάνει. Άσσος</div>

<div>1 με απόδοση 2,30&nbsp;<a href="http://www.bet-on-arme.com/component/weblinks/weblink/127-stoiximan-%CE%BC%CF%80%CE%BF%CE%BD%CE%BF%CF%85%CF%82-%CE%B5%CE%B3%CE%B3%CF%81%CE%B1%CF%86%CE%B7%CF%82/19-stoiximan-stoixima?task=weblink.go" style="text-decoration: none; color: rgb(234, 149, 0);" target="_blank">stoiximan</a></div>

<div>&nbsp;</div>

<div><strong>Μπάια - Ιντερνασιονάλ</strong>&nbsp;: Η Μπάια τρέχει μεγάλο σερί ντεφορμαρίσματος και δεν νομίζω ότι θα συνέλθει σήμερα με την Ιντερνασιονάλ. Οι φιλοξενούμενοι είναι σε πολύ καλή φόρμα και το επιβεβαιώσαν αυτό πέρνωντας το δίπλο μέσα στο Σάο πάολο και επιλέον διαθέτουν ομάδα η οποία είναι τουλάχιστον ένα επιπέδο πιο πάνω απο τους γηπεδούχους.&nbsp;</div>

<div>2 με απόδοση 2,30&nbsp;<a href="http://www.bet-on-arme.com/component/weblinks/weblink/163-netbet-stoixima/46-netbet-bonus-eggrafis?task=weblink.go" style="text-decoration: none; color: rgb(234, 149, 0);" target="_blank">Netbet</a></div>

<div>&nbsp;</div>

<div><strong>Κοπεγχάγη - Νόρτζελαντ</strong>&nbsp;: Θύμα έκπληξης έπεσαν οι γηπεδούχοι στην πρεμιέρα του πρωταθλήματος φέρνοντας ισοπαλία με την νεοφώτιστη Σίλκεμποργκ. Αντίθετα η Νόρτζελαντ έδειξε πολύ καλά στοιχεία στον αγώνα με την Βεστζελαντ και ειδικά στον επιθετικό τομέα. Οι αποδόσεις δίνουν ισχυρό φαβορί τους γηπεδούχους, αλλά με το δεδομένο ότι η Κοπεγχάγη έχει κρίσημο αγώνα στην Ουκρανία με την Ντνιεπρ για τα προκριματικά του champions league νομίζω ότι η κόντρα αξίζει περισσότερο.</div>

<div>X2 με απόδοση 2,05&nbsp;<a href="http://www.bet-on-arme.com/component/weblinks/weblink/127-stoiximan-%CE%BC%CF%80%CE%BF%CE%BD%CE%BF%CF%85%CF%82-%CE%B5%CE%B3%CE%B3%CF%81%CE%B1%CF%86%CE%B7%CF%82/19-stoiximan-stoixima?task=weblink.go" style="text-decoration: none; color: rgb(234, 149, 0);" target="_blank">stoiximan</a></div>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Η Aυστρία παίζει μπάλα', '1406380653', 'lokeren.jpg', '<p><strong>ΑΚ ΠΕΛΕΤΣ (2η - 3β)</strong>&nbsp;- Η αλλιώς ονομαζόμενη Βόφσμπεργκερ ξεκίνησε εντυπωσιακά τη σεζόν. Επικράτησε 4-1 στην έδρα της Αντμίρα, σε ένα ματς όπου η διαφορά στο τελικό σκορ δεν αντικατοπτρίζει πλήρως την εικόνα του αγώνα. Οι δύο ομάδες μοιράζονταν τις φάσεις και υπήρχε ισορροπία μέχρι να γίνει το 1-2 (63ο λεπτό) και στη συνέχεια η αποτελεσματικότητα της Βακ Πέλετς οδήγησε στο 1-4. Τα περισσότερα γκολ πάντως προήλθαν από αμυντικά λάθη και αδράνεια της αντιπάλου. Όταν συμβαίνει κάτι τέτοιο, δεδομένου ότι το δείγμα είναι μόνο ένας αγώνας, είναι δύσκολο να κρίνουμε κατά πόσο το σκορ οφείλεται στην επιθετική λειτουργία της νικήτριας ή στην αμυντική δυσλειτουργία της ηττημένης. Μεσοβδόμαδα, η γηπεδούχος έφερε 1-1 με μια εναλλακτική ομάδα της Τσέλσι στο ουδέτερο Κλάγκενφουρτ. Το κλίμα ήταν πανηγυρικό. Οι φίλαθλοι περίμεναν να δουν κάποιους αστέρες της Τσέλσι. Κάτι τέτοιο δε συνέβη, όμως το τελικό σκορ δεν παύει να μένει στην ιστορία του αυστριακού συλλόγου. Τώρα υποδέχεται την Αούστρια Βιέννης, με αντίπαλο την οποία έχει 0-1-3 τα δύο τελευταία χρόνια.<br />
<br />
<strong>ΑΟΥΣΤΡΙΑ ΒΙΕΝΝΗΣ (6η - 1β)&nbsp;</strong>- Το μη χείρον βέλτιστον... Η Αούστρια δεν κατάφερε να κερ΄δισει στην πρεμιέρα του πρωταθλήματος, αλλά και του τεχνικού Μπαουμγκάρτνερ στον πάγκο της. Από τη στιγμή όμως που ισοφάρισε στις καθυστερήσεις της αναμέτρησης το γκολ της Γκρόντιγκ (1-1 εντός), μάλλον ικανοποιημένη πρέπει να είναι. Οι Βιολετί έμειναν πίσω στο σκορ στο 54ο λεπτό και από το σημείο εκείνο πήραν την κατοχή, πίεσαν, δημιούργησαν ευκαιρίες (12-5 σουτ) και τελικά δικαιώθηκαν. Καλείται πολύ γρήγορα να κερδίσει τους χαμένους βαθμούς σε μία αρκετά δύσκολη έδρα. Η παράδοση την ευνοεί, αλλά δεν αρκεί. Πρέπει να βελτιώσει την απόδοσή της τώρα που βρίσκεται σε μεγαλύτερο βαθμό ετοιμότητας. Υπάρχει ακόμη η πιθανότητα ανακατατάξεων στο ρόστερ, όμως από τη διοίκηση υποστηρίζουν πως όποιος αποχωρήσει θα αντικατασταθεί. Απόντες από το σημερινό ματς είναι 3 διεθνείς με την εθνική U19 της Αυστρίας, ωστόσο μόνο ο ταλαντούχος Χόρβατ (Μ, 17 χρονών με 12 συμμετοχές πέρσι) επηρεάζει.<br />
<br />
<strong>ΕΚΤΙΜΗΣΗ - Καλή η Βόλφσμπεργκερ στην πρεμιέρα, όμως πρέπει να τη δούμε κόντρα σε μια πιο καλή άμυνα. Η Αούστρια έχει την εμπειρία, την παράδοση και κυρίως την ποιότητα για να πάρει όλους τους βαθμούς και να ρεφάρει γρήγορα τους δύο που έχασε στην πρεμιέρα.</strong></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('SUPER CUP ΡΩΣΙΑΣ ΤΣΣΚΑ ΜΟΣΧΑΣ- ΡΟΣΤΟΦ', '1406394402', 'super cup.jpg', '<p>Τελικός σουπερ καπ σήμερα στη ρωσία....</p>

<p>&nbsp;Η ΤΣΣΚΑ δείχνει να είναι έτοιμη για να σηκώσει το &nbsp;έκτό της σουοερ καπ στην ιστορία τής.Ενίσχυμένη από την άλλη η&nbsp;Ροστοφ ωστόσο δε δείχνει ικανή για τη νίκη απέναντι σε &nbsp;μία ΤΣΣΚΑ που προέρχεται από ενα σερί 9 αγωνων χωρίς ήτα απο τη περσυνή σεζόν.</p>

<p>&nbsp;</p>

<p><u><strong>ΠΡΟΤΑΣΗ</strong></u>&nbsp; &nbsp;O AΣΣΟΣ &nbsp;1 &nbsp; 1.52 στην www.2winbet.gr</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΤΟΠΙΚΟ ΝΤΕΡΠΙ ΔΑΝΙΑΣ  Κοπεγχάγη-Νόρτζελαντ', '1406395376', 'DANIAS.jpg', '<p>Κατά παράδοση η <strong>Κοπεγχαγη</strong> είναι το φαβορί για τη νίκη .Η Νορτζελαντ δεν κινήθηκε εντονα στο μεταγραφικό παζαρι και αναμένετα ευκόλα η δύσκολα η Κοπεγχάγη να πάρει τη νίκη.</p>

<p><u><strong>ΠΡΟΤΑΣΗ&nbsp;</strong></u>&nbsp;&nbsp;Ο ΑΣΣΟΣ 1 στο 1.80 2WINBET.GR&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΒΡΑΖΙΛΙΑ', '1406396058', 'SANTOS.jpg', '<p>Να υπενθυμίσουμε ότι η <u><strong>ΣΑΝΤΟΣ</strong></u>&nbsp; μετρά 9 στα 11 &nbsp;under !!!! απεναντί της η&nbsp;Σαπεκοένσε .</p>

<p><u><strong>ΠΡΟΤΑΣΗ:</strong></u>&nbsp;&nbsp;UNDER στο 1..62 2WINBET.GR</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΓΕΙΤΟΝΙΚΟ ΝΤΕΡΠΜΙ ΣΤΗ ΒΡΑΖΙΛΙΑ Τζόινβιλ – Αβάι', '1406396435', 'AVAI.jpg', '<p>Υποτιμιτικά αντιμετωπίζουν οι στοιχηματικές εταιρέιες τη φιλοξενούμενη ομάδα με την γηπεδουχο να μην είναι και στη καλύτερη δυνατή κατάσταση.</p>

<p><u><strong>ΠΡΟΤΑΣΗ</strong></u>&nbsp;&nbsp;ΕΚΠΛΗΞΗ &nbsp;ΔΙΠΛΟ 2 &nbsp;4.75 στην 2WINBET.GR</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ελβετία   Γιουνγκ Μποις-Ααράου', '1406460888', 'gioung mpoyw.jpg', '<p>Με τη χειρότερη αμυνα απο το περσινό ελοβετικό πρωτάθλημα ερχεται η Ααράου αντιμέτωπι την σαφώς καλύτερη&nbsp;<strong>&nbsp;Γιουνγκ Μποις</strong>.Θα στηρίξουμε τον <strong>ασσο&nbsp;</strong>.Επίπλέον η Αααράου μετά από μία αποητυετική χρονιά δεν ενισχύθηκε.</p>

<p><u><strong>Πρόταση :</strong></u>&nbsp; &nbsp;ασσσός 1.62 απόδοση στην www.2winbet,gr</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Tριαδα του πιγκουίνου ', '1406461375', 'pigouin.jpg', '<p>&nbsp;O Πιγκουινος προτείνει &nbsp; τριαδούλα για ταμειάκι....</p>

<p>&nbsp;&nbsp;&nbsp;188. &nbsp;&nbsp;Βαντούζ-Ζυρίχη &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>2</strong>&nbsp;&nbsp;</p>

<p>&nbsp; &nbsp;195. &nbsp; Βασιλεία-Λουκερνη &nbsp; &nbsp; 1</p>

<p>&nbsp; &nbsp;196. &nbsp; Γκρόντινκγ-Στουρμ Γκρατς &nbsp; <strong>χ</strong></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πληρώνει ο Ασσός της Χονκα (2.15 απόδοση οπαπ)', '1406461837', 'xonka.jpg', '<p>Αρκετά υψηλή τιμή στον άσσο της <strong>Χόνκα</strong> απέναντι σε μιά κακή τουρκου με 9 στις 10 ήττες εκτός έδρας... Σε μη καλή κατάστη και η<strong> Χόνκα&nbsp;</strong>ωστόσο έχει την ευκαρία να επιστρέψει στις νίκες... ενώ είχε πάρει και το διπλό στην έδρα της τουρκου.&nbsp;</p>

<p><strong>Πρόταση: &nbsp;</strong>Ασσός &nbsp;.2.30 απόδοση στην www.2winbet.gr</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('223 .  Γκοιας -Σαο Παολο και under....', '1406462328', 'goias.jpg', '<p>Δικαωθήκαμε για την επιλογή μας στο χθεσινό ματς από τη Βραζιλία με το under της Σαντος.Σήμερα θα τιμήσουμε το&nbsp;γκοιας -σαο παολο .</p>

<p><u><strong>Πρόταση</strong></u>&nbsp; 223. under &nbsp;1.57&nbsp;</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; no goal &nbsp;1.73&nbsp;</p>

<p>www.2winbet.gr</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('231. Φλαμένγκο-Μποταφόγκο ', '1406462717', 'flamengo.jpg', '<p><u><strong>Το ντέρπι του ρίου&nbsp;</strong></u></p>

<p>Με νέο προπονητή η φλαμένγκο και με την προσιτορία υπερ της ισοπαλίας..</p>

<p><u><strong>Πρόταση &nbsp;:</strong></u>&nbsp; &nbsp;231 &nbsp; .Χ με απόδοση 3.20 στην www.2winbet.gr</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Για του φίλους των 2-3  goal', '1406463129', 'GOAL.jpg', '<p><strong>194. ΧΑΓΚΕΣΟΥΝΤ- ΣΤΑΡΤ &nbsp;&nbsp;</strong></p>

<p><strong>198.ΑΙΚ-ΦΑΛΚΕΝΜΠΕΡΓΚ</strong></p>

<p><strong>213. ΧΑΜΚΑΜ-ΡΑΝΑΧΑΙΜ</strong></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Τριαδα για μεροκάματο....', '1406463462', 'ftoxos.jpg', '<p>192. Μιελπμπι - Γκετεμποργκ &nbsp; <strong>goal/goal</strong>&nbsp;</p>

<p>193.Μπρόμαποικάρνα-Οτβίταμπεργκ &nbsp;<strong>over&nbsp;</strong></p>

<p>199.Ελσφμποργκ-Νορσέπινγκ &nbsp; &nbsp; &nbsp; &nbsp; <strong>&nbsp;Χ2</strong></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Η προτασή μας για τένις του ATP challenger', '1406467334', 'Virtua_Tennis_01.jpg', '<p>ΑΓΩΝΑΣ 27/07/2014 &nbsp;και ώρα 23.00</p>

<p>&nbsp;</p>

<p>Fabrice Martin - Fritz Wolmarans (ATP Challenger Vancouver) &nbsp;</p>

<p><strong>ΠΡΟΤΑΣΗ:&nbsp;</strong>Fabrice Martin&nbsp;&nbsp;1.83 &nbsp;απόδοση</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('236. ΦΡΕΝΤΡΙΚΣΤΑΝΤ - ΚΡΙΣΤΙΑΝΣΟΥΝΤ (20:00)', '1406501256', 'norway-flag-1.jpg', '<p>Σε εξαιρετική αγωνιστική κατάσταση βρίσκεται η Φρέντρικσταντ καθώς στις τελευταίες εννέα αναμετρήσεις της έχει συλλέξει 20 βαθμούς (6 νίκες, 2 ισοπαλίες, 1 ήττα), οι οποίοι την έχουν καθιερώσει στις θέσεις που οδηγούν στα πλέι οφ ανόδου.Μία σπουδαία μεταγραφική κίνηση που θα τη βοηθήσει να κάνει την τελική επίθεσή της, ώστε να καταλάβει μία από τις δύο πρώτες θέσεις που οδηγούν στην απευθείας άνοδο στη μεγάλη κατηγορία της Νορβηγίας πραγματοποίησε η Κρίστιανσουντ. Ο λόγος για τον 27χρονο Γκανέζο ανασταλτικό μέσο, Αζίζ Ιντρίς, που αγωνιζόταν στην Χαμ Καμ. Πρόταση: 1 και under 2.5</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('237.ΧΑΚΕΝ - ΤΖΟΥΓΚΑΡΝΤΕΝ (20:05)', '1406502636', 'sweeden.jpg', '<p>Ενισχυμένη παρουσάζεται η Χακεν και αήτητη στά 5 τελευταία ματς να σημειωθεί ότι ο αγώνας δε θα διεξαχθεί στην φυσική της έδρα .. <strong>Πρόταση: goal goal και 1</strong></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Γ΄ Προκριματικός γύρος champions league ', '1406638820', 'ch.jpeg', '<p>Με τρείς αγώνες ξεκινάει σήμερα ο γ΄ προκριματικός γύρος του&nbsp;champions league .&nbsp;</p>

<p>101.&nbsp;<strong>ΣΠΑΡΤΑ ΠΡΑΓΑΣ</strong><strong>&nbsp;-&nbsp;</strong><strong>MALMO FF&nbsp;</strong>στήν Πράγα διεξάγεται ο πρώτος αγώνας του γ΄προκριματικού και η Σπάρτα δε δείχενι διαθέσιμη να χαριστεί στην Σουδική ομάδα που δεν θα έχει στη συνθεσή της το βασικό επιθετικό διδυμο της.&nbsp;</p>

<p><u><strong>ΠΡΟΤΑΣΗ</strong></u>&nbsp; &nbsp;ΑΣΣΟΣ με απόδοση 1.50 στην&nbsp;<a href="http://www.2winbet.gr">http://www.2winbet.gr</a></p>

<p>102.&nbsp;<strong>ΣΛΟΒΑΝ ΜΠΡΑΤ.</strong><strong>&nbsp;-&nbsp;</strong><strong>ΣΕΡΙΦ ΤΙΡΑΣΠΟΛ </strong>&nbsp;Εδω μιλάμε για την Σεριφ Τιρασπόλ που πρωταγωνιστεί &nbsp;μια δεκαετία τωρα στο πρωτάθλημα της χώρας της ωστ΄σο οταν μιλαμε για ευρωπαικό αγώνα τα δεδομένα αλλαζόυν και θεωρώ το χ ικανοποιητικό αποτέλεσμα.</p>

<p><u><strong>ΠΡΟΤΑΣΗ</strong></u>&nbsp;&nbsp;ΙΣΟΠΑΛΙΑ &nbsp;με απόδση 3.20 στην&nbsp;<a href="http://www.2winbet.gr">http://www.2winbet.gr</a>&nbsp;</p>

<p>103.&nbsp;<strong>ΝΤΕΜΠΡΕΤΣΕΝ</strong><strong>&nbsp;-&nbsp;</strong><strong>ΜΠΑΤΕ ΜΠΟΡΙΣΟΦ &nbsp;</strong>και εδώ η ισοπαλία έχει τη τιμητική της και με ρίσκο το διπλό&nbsp;</p>

<p><u><strong>ΠΡΟΤΑΣΗ</strong></u>&nbsp;&nbsp;Χ2 ΔΕ &nbsp; ( 1.47&nbsp;<a href="http://www,2winbet.gr">http://www,2winbet.gr</a>&nbsp;)&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Απουσίες στο Σπάρτα-Μάλμε ', '1406639250', 'sentoni_261008.jpg', '<p>Σίγουρα πίο έτοιμη ομάδα&nbsp;η <strong>Μάλμε</strong> καθόσον είναι ήδη στο&nbsp;β΄ γύρο του Σουηδικού πρωταθλήματος αλλά απουσιάζουν για τον αποψινό αγώνα οι <strong>δύο βασικοί επιθετικοί </strong>της .</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('100. ΒΑΛΕΡΕΝΓΚΑ - ΣΤΑΜΠΑΕΚ', '1406640121', 'vif_b.jpg', '<p>Να μη χαλάσει τη γιορτή στους φιλάθλους της θέλει σημέρα η Βαλερένγκα συνδιαζόντας νίκη με τα 101 χρόνια ζωής και με το πρώτο σκόρερ του πρωταθλήματος στη συνθεσή της. Από την άλλη η Σταμπαεκ που προκρίθηκε στα προημετελικά του κυπέλλου θα προσπαθήσει να χαλασει το πανυγηρι στις κερκίδες.&nbsp;</p>

<p><u><strong>&nbsp;ΠΡΟΤΑΣΗ</strong></u>&nbsp;ΑΣΣΟΣ (1.40)&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Η αθλήτρια από το Καζακστάν που είναι... υπερβολικά όμορφη για να παίζει', '1406640466', 'newego_LARGE_t_1101_54379139_type12713.jpg', '<p>Στο μάτι του κυκλώνα βρίσκεται τις τελευταίες ημέρες μια έφηβη βολεϊμπολίστρια από το Καζακστάν, όχι όμως λόγω των αθλητικών της ικανοτήτων αλλά λόγω της εμφάνισής της, η οποία, όπως φαίνεται, περνάει κάθε άλλο παρά απαρατήρητη</p>

<p>Η 17χρονη Σαμπίνα Αλτινμπέκοβα, είναι τόσο όμορφη που καταφέρνει να μαγνητίζει όλα τα βλέμματα τη στιγμή που η ομάδα της βρίσκεται στο παρκέ. Διαπίστωση στην οποία προχώρησε ακόμη και ο ίδιος ο προπονητής της ομάδας, ο οποίος παραδέχτηκε ότι κατά τη διάρκεια των αγώνων οι φίλαθλοι παρακολουθούν μόνο τη συγκεκριμένη αθλήτρια.</p>

<p>«Είναι αδύνατο να δουλεύει κανείς υπό αυτές τις συνθήκες», δηλώνει ο Νούρλαν Σαντίκοφ, προπονητής της εθνικής ομάδας νεανίδων σε μήνυμά του που μεταφράστηκε από τη Daily Mail: «Το κοινό συμπεριφέρεται σαν να υπάρχει μία και μόνο παίκτρια στο πρωτάθλημα».<br />
<br />
Ο Σαντίκοφ αναφερόταν σε ένα πρόσφατο τουρνουά στην Ταϊβάν κατά το οποίο η νεαρή αθλήτρια έκανε ιδιαίτερη αίσθηση, με το κοινό να μη σταματά να ανεβάζει στο internet φωτογραφίες και βίντεο που δείχνουν τη νεαρή αθλήτρια να προθερμαίνεται στο παρκέ, να αγωνίζεται ή απλώς να κάθεται αμέριμνη. Όλες οι σχετικές αναρτήσεις έχουν «φιλοδωρηθεί» από τους χρήστες με δεκάδες ή και εκατοντάδες χιλιάδες likes και viewsΗ εφημερίδα The Straits – Times ανέφεραν μάλιστα ότι οι ταϊβανέζοι φίλαθλοι εμφανίστηκαν στο γήπεδο κρατώντας σημαίες του Καζακστάν και αρκετές ώρες πριν την έναρξη του αγώνα για να πάρουν αρκετές δόσεις από... Αλτινμπέκοβα</p>

<p>Αν και στα μέσα κοινωνικής δικτύωσης υπάρχουν αναρίθμητες σελίδες που σχετίζονται με την αθλήτρια, ακόμη και ένας λογαριασμός Twitter με περισσότερους από 22.000 «ακολούθους», η επίσημη διαδικτυακή παρουσία της 17χρονης περιορίζεται σε έναν λογαριασμό Instagram και μια σελίδα στο vk.com, ένα μέσο κοινωνικής δικτύωσης δημοφιλές στη βόρεια Ευρώπη.</p>

<p>Η ίδια πάντως δηλώνει «Ήμουν κολακευμένη στην αρχή, αλλά όλο αυτό γίνεται λίγο υπερβολικό. Θέλω να επικεντρωθώ στο βόλεϊ και να είμαι γνωστή για αυτό και τίποτε άλλο» ενώ οι γονείς της είναι κατηγορηματικά αντίθετοι με τις αλεπάλληλες προτάσεις που της έχουν γίνει να γίνει μοντέλο.</p>

<p>Πηγή: Huffington Post</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Το λεξικό του στοιχήματος', '1406641016', 'λεξ.jpeg', '<p><strong>Το απόλυτο λεξικό για το διαδικτυακό στοίχημα. Αναλυτικά όλη η ελληνική και διεθνής ορολογία.&nbsp;</strong></p>

<p><strong>Ακριβές Σκορ</strong>&nbsp;: Το τελικό σκορ μετά το τέλος των 90 λεπτών του αγώνα.</p>

<p><strong>Ακριβές Σκορ και Σκόρερ (Scorecast)</strong>&nbsp;: Είναι το στοίχημα όπου ο παίκτης ποντάρει στο τελικό αποτέλεσμα της αναμέτρησης και τον πρώτο σκόρερ που θα βάλει γκολ.&nbsp;</p>

<p><strong>Αμερικάνικο Στοίχημα :</strong>&nbsp;Είναι το ειδικό στοίχημα όπου ο παίκτης ποντάρει στην νίκη της γηπεδούχου ή φιλοξενούμενης ομάδας και η ισοπαλία αντιστοιχεί με μονάδα και επιστρέφεται το ποσό του πονταρίσματος.</p>

<p><strong>Ανταλλακτήριο Στοιχημάτων ( Betting Exchange)&nbsp;</strong>: Είναι τα στοιχήματα που γίνονται χωρίς τη διαμεσολάβηση του μπουκμάκερ αλλά η απόδοση και το κέρδος αγοράζεται από άλλο παίκτη.</p>

<p><strong>Αυτογκόλ :</strong>&nbsp;Το ειδικό στοίχημα που προβλέπει αν θα επιτευχθεί αυτογκόλ σε μία ποδοσφαιρική αναμέτρηση.</p>

<p><strong>Απόδοση:&nbsp;</strong>Είναι το ποσοστό κέρδους που καταβάλλεται στους παίκτες σε περίπτωση επιτυχίας.&nbsp;</p>

<p><strong>Άρμπιτραζ (Arbitrage Bet) :</strong>&nbsp;Είναι το είδος πονταρίσματος που ο παίκτης στοιχηματίζει και στα τρία σημεία (νίκη, ισοπαλία, ήττα) ώστε η επιτυχία να είναι σίγουρη. Η επιλογή γίνεται σε διαφορετικούς μπουκμάκερ που εξασφαλίζουν τις μεγαλύτερες αποδόσεις της αγοράς στοιχήματος.</p>

<p><strong>Ασιατικό Χάντικαπ (Asian Handicap )&nbsp;</strong>: Είναι το ειδικό στοίχημα που δίνεται πλεονέκτημα γκολ στο ποδόσφαιρο ή πόντων σε αγώνα μπάσκετ πριν ξεκινήσει τι παιχνίδι . Π.χ. αν υπάρχει +1 γκολ στην γηπεδούχο ομάδα τότε για να έρθει 1 ο αγώνας πρέπει να κερδίσει με τουλάχιστον 2 γκολ διαφορά(2-0, 3-1, 4-2, 3-0 κλπ.). Σε περίπτωση ισοπαλίας επιστρέφεται το ποσό του πονταρίσματος</p>

<p><strong>Accumulator Bet</strong>:&nbsp;Χρησιμοποιείται και ο όρος Parlay και στα ελληνικά είναι το Παρολί στοίχημα. Είναι το στοίχημα στο οποίο ο παίκτης συνδυάζει 2 ή περισσότερα γεγονότα στο ίδιο κουπόνι. Κερδισμένο είναι το στοίχημα που θα πιάσει όλα τα γεγονότα.&nbsp;&nbsp;</p>

<p><strong>Anytime Σκόρερ:</strong>&nbsp;Να σκοράρει κάποιος παίκτης οποιαδήποτε στιγμή του αγώνα&nbsp;</p>

<p><strong>Antepost:&nbsp;</strong>Μακροχρόνιο στοίχημα όπως για παράδειγμα νικητής Τσάμπιονς Λιγκ.</p>

<p><strong>Back:</strong>&nbsp;Ο πιο συνηθισμένος τρόπος στοιχηματισμού. Ποντάρισμα υπέρ κάποιου σημείου.</p>

<p><strong>Betting Limits (Όρια στοιχηματισμού):</strong>&nbsp;Είναι τα όρια στοιχηματισμού μέσα στα οποία μπορεί να ποντάρει ένας παίκτης. Τα όρια αυτά καθορίζονται από τον Bookmaker ο οποίος καθορίζει το ελάχιστο και το μέγιστο ποντάρισμα σε κάθε στοίχημα.&nbsp;</p>

<p><strong>BIC/SWIFT Αριθμός&nbsp;</strong>: Είναι ο λέξη που περιλαμβάνει αριθμούς και γράμματα με την οποία γίνεται η ταύτιση της τράπεζας στην οποία θα γίνει μία κατάθεση σε έναν λογαριασμό. Χρησιμοποιείται στις καταθέσεις και στις αναλήψεις των παικτών.&nbsp;</p>

<p><strong>Bookings:&nbsp;</strong>Είναι Ειδικό Στοίχημα στο οποίο ο παίκτης προβλέπει αν το άθροισμα των καρτών σε έναν αγώνα είναι μεγαλύτερο ή μικρότερο από το όριο που έχει θέσει ο Bookmaker. Η κάθε κίτρινη κάρτα μετράει για 10 πόντους και η κάθε κόκκινη μετράει για 25 πόντους. &nbsp;</p>

<p><strong>CVC</strong>: Αντιστοιχεί στον Card Verification Code. Ο κωδικός αυτός βρίσκεται στο πίσω μέρος της πιστωτικής κάρτας και απαιτείται σε όλες τις καταθέσεις που γίνονται μέσω τηλεφώνου ήInternet.<br />
&nbsp;&nbsp;<br />
<strong>Γκανιότα ( Juice )</strong>&nbsp;: Είναι το ποσοστό κέρδους του μπουκμάκερ.</p>

<p><strong>Γκολ-Γκολ (GG)</strong>:&nbsp; Το να σημειώσουν τέρμα και οι δύο ομάδες.</p>

<p><strong>Διπλό Αποτέλεσμα ( Ημίχρονο/Τελικό)</strong>&nbsp;: Είναι το στοίχημα όπου ο παίκτης πρέπει να επιτύχει το αποτέλεσμα του Α΄ ημιχρόνου και του τελικού του αγώνα .</p>

<p><strong>Διπλή Ευκαιρία (Double Chance)</strong>&nbsp;: Είναι το ειδικό στοίχημα όπου ο παίκτης μπορεί να επιλέξει δύο αποτελέσματα ταυτόχρονα (1Χ,12,Χ2).</p>

<p><strong>Δίχως Ισοπαλία ( Draw No Bet)</strong>&nbsp;: Το ειδικό στοίχημα όπου ο παίκτης ποντάρει στην νίκη του γηπεδούχου ή της φιλοξενούμενης ομάδας με την ισοπαλία να του επιστρέφει το ποσό του στοιχήματος. Παρόμοιο με το Αμερικάνικο Στοίχημα .</p>

<p><strong>Δεκαδικές αποδόσεις (Decimal Odds)&nbsp;</strong>: Είναι ο τύπος των αποδόσεων που χρησιμοποιούνται ευρέως για τον υπολογισμό της κάθε επιτυχίας. Λέγονται και Ευρωπαϊκές αποδόσεις και εκφράζονται με νούμερα όπως το 1.20,1.40, 1.70 κλπ. &nbsp;</p>

<p><strong>Dead heat:&nbsp;</strong>&nbsp;Όταν σε ένα αθλητικό γεγονός δύο ή τρεις συμμετέχοντες καταλαμβάνουν την ίδια θέση.</p>

<p><strong>Draw no bet:&nbsp;</strong>Είδος στοιχηματισμού στο οποίο το προσφερόμενο γεγονός εάν έρθει ισόπαλο, σου επιστρέφεται το ποσό στοιχηματισμού που έχεις ποντάρει.&nbsp;</p>

<p><strong>Ειδικό Στοίχημα :</strong>&nbsp;Είναι η κατηγορία στοιχημάτων που περιλαμβάνει τα όλα τα είδη πονταρισμάτων εκτός από τα κλασσικά 1,Χ και 2.</p>

<p><strong>Ευρωπαϊκό Χάντικαπ (European Handicap)</strong>&nbsp;: Είναι το ειδικό στοίχημα όπου δίνει πλεονέκτημα γκολ στο ποδόσφαιρο ή πόντων στο μπάσκετ πριν ξεκινήσει ο αγώνας. Υπάρχει ακέραιο χάντικαπ σε μία ομάδα και η διαφορά του από το ασιατικό είναι ότι υπάρχει και η ισοπαλία για επιτυχία.</p>

<p><strong>Eco Card</strong>: Υπηρεσία μέσω της οποίας μπορούν να γίνονται καταθέσεις και αναλήψεις στο λογαριασμό ενός παίκτη.</p>

<p><strong>European Handicap:&nbsp;</strong>Είναι το στοίχημα στο οποίο μία ομάδα έχει ακέραιο προβάδισμα σε σχέση με την αντίπαλο της. Στο στοίχημα αυτό υπάρχουν 3 πιθανά αποτελέσματα σε αντίθεση με το Ασιατικό χάντικαπ.&nbsp;<br />
&nbsp;<br />
<strong>Fixed Odds:</strong>&nbsp;Είναι οι προκαθορισμένες αποδόσεις.&nbsp;<br />
&nbsp;<br />
<strong>Ζωντανό Στοίχημα (Live Betting)</strong>&nbsp;: Ο στοιχηματισμός κατά τη διάρκεια ενός αγώνα όπου οι αποδόσεις μεταβάλλονται διαρκώς ανάλογα με την εξέλιξη του.</p>

<p><strong>Ζωντανό Σκόρ (Livescore)</strong>&nbsp;: Η παρακολούθηση της εξέλιξης ενός αγώνα σε πραγματικό χρόνο .<br />
Θα πετύχουν γκολ και οι δύο ομάδες (Goal-Goal) : Είναι το ειδικό στοίχημα όπου προβλέπεται ότι και οι δύο ομάδες μίας αναμέτρησης θα πετύχουν τουλάχιστον 1 γκολ.</p>

<p><strong>Ημίχρονο / Τελικό :</strong>&nbsp; Συνδυασμός του αποτελέσματος μετά το πρώτο και μετά το δεύτερο ημίχρονο του αγώνα.</p>

<p><strong>Head to Head:&nbsp;</strong>Είναι Ειδικό Στοίχημα σε πολλά αθλητικά γεγονότα στο οποίο ο παίκτης προβλέπει ανάμεσα σε 2 συμμετέχοντες (παίκτης ή ομάδα) ποιος θα τερματίσει σε καλύτερη θέση.&nbsp;<br />
&nbsp;&nbsp;<br />
<strong>IBAN :</strong>&nbsp;Είναι ο αριθμός τραπεζικού λογαριασμού που χρησιμοποιείται για να γίνει μία συναλλαγή σε διατραπεζικό σύστημα. Το ακρωνύμιο IBAN αντιστοιχεί στο International Bank Account Number.</p>

<p><strong>IBAS:</strong>&nbsp;Τα αρχικά του οργανισμού Arbitration Betting Service. Σκοπός του είναι να λύσει τυχόν διαφορές ανάμεσα σε παίκτες και bookmaker.&nbsp;</p>

<p><strong>Juice:</strong>&nbsp;Στα ελληνικά σημαίνει γκανιότα και είναι το κέρδος του Bookmaker από ένα γεγονός. Θα τπ βρείτε και ως book percentage ή book edge.</p>

<p><strong>Live Betting:&nbsp;</strong>Είναι το στοίχημα κατά τη διάρκεια ενός αγώνα. Ο Bookmaker δίνει αποδόσεις, που μεταβάλλονται ανάλογα με την εξέλιξη του αγώνα, για γεγονότα που αφορούν το ματς.&nbsp;</p>

<p><strong>Κλασματικές αποδόσεις (Fractional Odds) :</strong>&nbsp;Είναι ο τύπος των αποδόσεων που χρησιμοποιούνται κυρίως στην Αγγλία για τον υπολογισμό της κάθε επιτυχίας. Τις συναντάμε με τη μορφή κλασμάτων τύπου 2/5, 3/7, 2/1 κλπ.</p>

<p><strong>Μακροχρόνια Στοίχημα ( Ante Post Bet)&nbsp;</strong>: Είναι το ειδικό στοίχημα με μακροχρόνια διάρκεια που οι παίκτες ποντάρουν στον νικητή μίας διοργάνωσης και πρέπει να περιμένουν μέχρι τη λήξη όλων των αγωνιστικών περιόδων.</p>

<p><strong>Μονό αποδεκτό στοίχημα (Single Bet)&nbsp;</strong>: Η τοποθέτηση στοιχήματος μόνο σε ένα αθλητικό γεγονός.<br />
Mobile Betting : Στοίχημα στο κινητό τηλέφωνο . Η δυνατότητα των παικτών να παίξου stoixima από το smartphone ή τη ταμπλέτα τους.</p>

<p><strong>Μπόνους (Bonus) :</strong>&nbsp;Είναι οι προσφορές των μπούκμακερ ώστε να προσελκύσουν νέους παίκτες ή να επιβραβεύσουν τους παλιούς.</p>

<p><strong>Μπούκμεϊκερ ή Μπουκ (<em>Bookmaker ή Bookie</em>)&nbsp;</strong>: Είναι οι διαχειριστές των αποδόσεων που αναλαμβάνουν τις τοποθετήσεις των στοιχημάτων από τους παίκτες και την πληρωμή των νικηφόρων κουπονιών.</p>

<p><strong>Money Line:</strong>&nbsp;Στις αμερικάνικες αποδόσεις, ο bookmaker προσφέρει αποδόσεις που έχουν διαφορετική μορφή. Εμφανίζεται το ποσό που πρέπει να ποντάρει κανείς για να κερδίσει 100 Δολάρια ή πόσα μπορεί να κερδίσει κάποιος αν ποντάρει 100 Δολάρια.<br />
&nbsp;&nbsp;<br />
<strong>Neteller :&nbsp;</strong>Είναι ηλεκτρονικό πορτοφόλι που εξυπηρετεί στις συναλλαγές με τον μπουκμάκερ.<br />
Όρια Στοιχηματισμού (Bet Limit ) : Είναι τα χρηματικά όρια στα οποία ο παίκτης μπορεί να κάνει το ποντάρισμα του, με ελάχιστο και μέγιστο όριο. Ο κάθε μπουκμάκερ έχει διαφορετικό όρια που ξεκινάνε από το €0.01 και μπορούν να φτάσουν μέχρι και €100.000.</p>

<p><strong>Νο Γκολ (NG):</strong>&nbsp;Να μη σημειώσουν τέρμα και οι δύο ομάδες.</p>

<p><strong>Odds:&nbsp;</strong>Είναι οι αποδόσεις που αφορούν κάποιο γεγονός και είναι αυτές που καθορίζουν το κέρδος που μπορεί να προκύψει αν κερδηθεί το στοίχημα. Υπάρχουν οι δεκαδικές, οι κλασματικές και οι αμερικάνικες αποδόσεις.&nbsp;<br />
&nbsp;<br />
<strong>Outsider ( Rag ή Underdog)</strong>&nbsp;: Η ομάδα με το σημείο που έχει την υψηλότερη απόδοση και θεωρείται σχετικά δύσκολο έως αδύνατο να κερδίσει.</p>

<p><strong>Over/Under :&nbsp;</strong>Ο συνολικός αριθμός των γκολ μετά το τέλος των 90 λεπτών του αγώνα θα είναι πάνω ή κάτω από Χ τέρματα.</p>

<p><strong>Παρολί (Accumulator Bet ή Parlay ) :</strong>&nbsp;Ο συνδυασμός δύο ή και περισσότερων στοιχημάτων σε ένα κουπόνι που για να πληρωθεί πρέπει να είναι όλα επιτυχημένα.</p>

<p><strong>Προμήθεια :</strong>&nbsp;Λειτουργεί στα ανταλλακτήρια στοιχήματος και είναι η προμήθεια σε ποσοστό που παίρνει η ιστοσελίδα από τα κέρδη των παικτών σε αντάλλαγμα την παροχή αυτής της υπηρεσίας.</p>

<p><strong>Πρώτος Σκόρερ</strong>: Πρώτος παίκτης που σκοράρει στον αγώνα.</p>

<p><strong>Paypal&nbsp;</strong>: Είναι ηλεκτρονικό πορτοφόλι που εξυπηρετεί στις συναλλαγές με τον μπουκμάκερ.</p>

<p><strong>Paysafecard</strong>&nbsp;: Είναι προπληρωμένη κάρτα που ο παίκτης χρησιμοποιεί για να κάνει κατάθεση χρημάτων.</p>

<p><strong>Push:</strong>Η επιστροφή του ποσού στοιχηματισμού λόγω ακύρωσης ενός γεγονότος ή ισοπαλίας.&nbsp;</p>

<p><strong>Σκόρερ</strong>&nbsp;: Είναι το ειδικό στοίχημα όπου ο παίκτης ποντάρει σε έναν συγκεκριμένο παίκτη της αθλητικής αναμέτρησης να βάλει το πρώτο ή το τελευταίο ή οποιοδήποτε ή 2 και άνω ή χατ-τρικ γκολ.</p>

<p><strong>Σύνολο Τερμάτων</strong>: Ο συνολικός αριθμός των γκολ μετά το τέλος των 90 λεπτών του αγώνα.</p>

<p><strong>Σύνολο γκολ Μονά-Ζυγά :</strong>&nbsp;Ο τελικός αριθμός τερμάτων ανεξαρτήτως ποια ομάδα σκοράρει και το αν αυτός θα είναι μονός η ζυγός.</p>

<p><strong>Σύστημα (System Bet) :</strong>&nbsp;Είναι ένα κουπόνι με 3 ή περισσότερα γεγονότα με τον παίκτη να ζητάει να επιβεβαιωθούνε μία συγκεκριμένη σειρά από αυτά. Για παράδειγμα εάν επιλέξει το 2/5 θα έχει επιλέξει 5 αθλητικά γεγονότα και θα πρέπει τουλάχιστον 2 από αυτά να επιβεβαιωθούν ώστε να κερδίσει το ελάχιστο ποσό κέρδους. Σε περίπτωση περισσότερων επιτυχιών το κέρδος είναι πολύ μεγαλύτερο για τον παίκτη.</p>

<p><strong>Σύστημα Καναδικό ( Canadian System)</strong>&nbsp;: Είναι σύστημα σε κουπόνι που περιλαμβάνει 5 διαφορετικές επιλογές σε αθλητικά γεγονότα. Το κουπόνι δημιουργεί ένα σύστημα με 26 στοιχήματα (στήλες) με 1 πενταπλό παρολί, 5 τετραπλά παρολί, 10 τριπλά παρολί και 10 διπλά παρολί. Για να κερδίσει κάποιος το ελάχιστο ποσό πρέπει να επαληθευθούν τουλάχιστον 2 επιλογές.</p>

<p><strong>Σύστημα Γιάνκι (Yankee System)&nbsp;</strong>: Είναι σύστημα σε κουπόνι που περιλαμβάνει 5 διαφορετικές επιλογές σε αθλητικά γεγονότα. Το κουπόνι δημιουργεί ένα σύστημα με 11 στοιχήματα (στήλες) με 1 τετραπλό παρολί, 4 τριπλά παρολί και 6 διπλά παρολί. Για να κερδίσει κάποιος το ελάχιστο ποσό πρέπει να επαληθευθούν τουλάχιστον 2 επιλογές.</p>

<p><strong>Σύστημα Σούπερ Γιάνκι ( Super Yankee)&nbsp;</strong>: Είναι σύστημα σε κουπόνι που περιλαμβάνει 5 διαφορετικές επιλογές σε αθλητικά γεγονότα. Το κουπόνι δημιουργεί ένα σύστημα με 26 στοιχήματα (στήλες) με 1 πενταπλό παρολί, 5 τετραπλά παρολί, 10 τριπλά παρολί και 10 διπλά παρολί. Για να κερδίσει κάποιος το ελάχιστο ποσό πρέπει να επαληθευθούν τουλάχιστον 2 επιλογές. Είναι το ίδιο με το Καναδικό Σύστημα.</p>

<p><strong>Σύστημα Γολιάθ ( Goliath System) :</strong>&nbsp;Είναι σύστημα σε κουπόνι που περιλαμβάνει 8 διαφορετικές επιλογές σε αθλητικά γεγονότα. Το κουπόνι δημιουργεί ένα σύστημα με 247 στοιχήματα (στήλες) με 1 οκταπλό παρολί, 8 επταπλά παρολί, 28 εξαπλά παρολί, 56 πενταπλά παρολί,70 τετραπλά παρολί, 56 τριπλά παρολί και 28 διπλά παρολί. Για να κερδίσει κάποιος το ελάχιστο ποσό πρέπει να επαληθευθούν τουλάχιστον 2 επιλογές.</p>

<p><strong>Σύστημα Λάκι 63 (Lucky 63 System )&nbsp;</strong>: Είναι σύστημα σε κουπόνι που περιλαμβάνει 6 διαφορετικές επιλογές σε αθλητικά γεγονότα. Το κουπόνι δημιουργεί ένα σύστημα με 63 στοιχήματα (στήλες) με 1 εξαπλό παρολί, 6 πενταπλά παρολί, 15 τετραπλά παρολί, 20 τριπλά παρολί, 15 διπλά παρολί και 6 μονά αποδεκτά γεγονότα. Για να κερδίσει κάποιος το ελάχιστο ποσό πρέπει να επαληθευθεί τουλάχιστον 1 επιλογή.</p>

<p><strong>Σύστημα Λάκι 15 (Lucky 15 System ) :</strong>&nbsp;Είναι σύστημα σε κουπόνι που περιλαμβάνει 4 διαφορετικές επιλογές σε αθλητικά γεγονότα. Το κουπόνι δημιουργεί ένα σύστημα με 15 στοιχήματα (στήλες) με 1τετραπλό παρολί, 4 τριπλά παρολί, 6 διπλά παρολί και 4 μονά αποδεκτά γεγονότα. Για να κερδίσει κάποιος το ελάχιστο ποσό πρέπει να επαληθευθεί τουλάχιστον 1 επιλογή.</p>

<p><strong>Σύστημα Πατέντα ( Patent)</strong>&nbsp;: Είναι σύστημα σε κουπόνι που περιλαμβάνει 3 διαφορετικές επιλογές σε αθλητικά γεγονότα. Το κουπόνι δημιουργεί ένα σύστημα με 26 στοιχήματα (στήλες) με 1 τριπλό παρολί, 3 διπλά παρολί και 3 μονά αποδεκτά γεγονότα. Για να κερδίσει κάποιος το ελάχιστο ποσό πρέπει να επαληθευθεί τουλάχιστον 1 επιλογή.</p>

<p><strong>Σύστημα Τρίξι ( Trixie System)&nbsp;</strong>: Είναι σύστημα σε κουπόνι που περιλαμβάνει 3 διαφορετικές επιλογές σε αθλητικά γεγονότα. Το κουπόνι δημιουργεί ένα σύστημα με 4 στοιχήματα (στήλες) με 1τριπλό παρολί και 3 διπλά παρολί. Για να κερδίσει κάποιος το ελάχιστο ποσό πρέπει να επαληθευθούν τουλάχιστον 2 επιλογές.</p>

<p><strong>Σύστημα Χέιντζ ( Heinz System) :&nbsp;</strong>Είναι σύστημα σε κουπόνι που περιλαμβάνει 6 διαφορετικές επιλογές σε αθλητικά γεγονότα. Το κουπόνι δημιουργεί ένα σύστημα με 57 στοιχήματα (στήλες) με 1 εξαπλό παρολί, 6 πενταπλά παρολί,15 τετραπλά παρολί, 20 τριπλά παρολί και 15 διπλά παρολί. Για να κερδίσει κάποιος το ελάχιστο ποσό πρέπει να επαληθευθούν τουλάχιστον 2 επιλογές.</p>

<p><strong>Σύστημα Σούπερ Χέιντζ ( Super Heinz System) :</strong>&nbsp;Είναι σύστημα σε κουπόνι που περιλαμβάνει 7 διαφορετικές επιλογές σε αθλητικά γεγονότα. Το κουπόνι δημιουργεί ένα σύστημα με 120 στοιχήματα (στήλες) με 1 επταπλό παρολί, 7 εξαπλά παρολί, 21 πενταπλά παρολί,35 τετραπλά παρολί, 35 τριπλά παρολί και 21 διπλά παρολί. Για να κερδίσει κάποιος το ελάχιστο ποσό πρέπει να επαληθευθούν τουλάχιστον 2 επιλογές.</p>

<p><strong>Skrill</strong>&nbsp;( πρώην Moneybookers) : Είναι ηλεκτρονικό πορτοφόλι που εξυπηρετεί στις συναλλαγές με τον μπουκμάκερ.</p>

<p><strong>Teaser:</strong>&nbsp;Είναι το στοίχημα στο οποίο ο παίκτης ορίζει το ύψος του χάντικαπ που θέλει να ποντάρει. Η απόδοση του στοιχήματος μεταβάλλεται ανάλογα με το ύψος του χάντικαπ.</p>

<p><strong>Treble (Τριάδα)&nbsp;</strong>:Είναι το ποντάρισμα στον συνδυασμό 3 σημείων.</p>

<p><strong>Two way</strong>: Είναι το στοίχημα σε γεγονότα με 2 πιθανά αποτελέσματα. Πχ τέτοια γεγονότα είναι το μπάσκετ,το βόλεϊ κ.ά.&nbsp;</p>

<p><strong>Trading:</strong>&nbsp;Είναι η τοποθέτηση στοιχημάτων χωρίς τη μεσολάβηση του Bookmaker. Ένας παίκτης δεν αγοράζει απόδοση για ένα γεγονός από έναν Bookmaker αλλά από κάποιον άλλον παίκτη<br />
ο οποίος μπορεί να προσφέρει καλύτερη απόδοση για το γεγονός αυτό.</p>

<p><strong>Τελικό Αποτέλεσμα:&nbsp;</strong>Τελικό αποτέλεσμα αγώνα - νίκη, ισοπαλία, ήττα (στη&nbsp;διάρκεια του κανονικού&nbsp;αγώνα).</p>

<p><strong>Φαβορί (Favourite ή Chalk )</strong>&nbsp;: Η ομάδα που έχει τη μικρότερη απόδοση σε έναν αγώνα και θεωρείται ότι θα επικρατήσει.</p>

<p><strong>Χάντικαπ Τερμάτων:</strong>&nbsp; Τελικό αποτέλεσμα αγώνα (στην διάρκεια του κανονικού αγώνα) συν το Χάντικαπ Τερμάτων που δόθηκε σε μία από τις ομάδες.</p>

<p><strong>Value Betting</strong>: Είναι το ποντάρισμα σε σημεία των οποίων η πιθανότητα επαλήθευσης εκτιμά ο παίκτης ότι είναι υψηλότερη σε σχέση με την πιθανότητα στην απόδοση που έχει δώσει ο Bookmaker. Εκτιμά δηλαδή ο παίκτης ότι η απόδοση ενός σημείου είναι πολύ υψηλότερη από όσο θα έπρεπε να είναι.&nbsp;</p>

<p>πηγή foxbet.gr</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Οι 24 Νόμιμες εταιρείες ιντερνετικού στοιχηματισμού στη χώρα μας', '1406641892', 'online-gambling-greece.jpg', '<p>Σας παρουσιαζουμε τις 24 εταιρείες που λειτουργούν νόμιμα στη χώρα μας</p>

<div>
<div><strong>As IMG Kasiinod&nbsp;</strong></div>

<div>Η εταιρία με έδρα την Εσθονία δραστηριοποιείται πάνω από μία δεκαετία στο χώρο των καζίνο και διαθέτει 15 καταστήματα στη χώρα. Στο διαδικτυακό καζίνο λειτουργεί τρεις ιστοχώρους.<br />
<br />
<strong>Β2B Gaming Services Malta Limited &nbsp;&amp; &nbsp;Kingmaker Services Limited</strong><br />
Oι δύο εταιρίες είναι θυγατρικές της&nbsp;Bge Realisations Limited, με την τελευταία να είναι επίσης θυγατρική της Leisure &amp; Gambling PLC η οποία είναι ιδιοκτήτρια του&nbsp;<a href="http://client.betshop.com/main.asp?id=foxbet&amp;url=http://gr.BETSHOP.com" rel="nofollow" target="_blank">www.betshop.com</a>&nbsp;.&nbsp;<br />
Υπό την άδεια της B2Β λειτουργούν επίσης οι ιστοσελίδες&nbsp;<a href="http://online.callbet.gr/main.asp?id=foxbet.gr&amp;url=http://www.callbet.gr" rel="nofollow" target="_blank">Callbet.gr,</a>&nbsp;<a href="http://www.stoiximan.gr/?clkco=bb22e41d-45a9-4adc-a20c-2b7cc75a9ed2&amp;adid=296" target="_blank">Stoiximan.gr</a>&nbsp;και<a href="http://www.bet365.gr/home/?affiliate=365_148076" rel="nofollow" target="_blank">Bet365.gr</a>.&nbsp;<br />
<br />
<strong>Cash Point (Malta) Limited</strong><br />
Γερμανική εταιρία που δραστηριόποιειται από το 1996 στο χώρο με έδρα τη Μάλτα.&nbsp; To<a href="http://account.cashpointpartners.com/processing/clickthrgh.asp?btag=a_87b_257&amp;aid=" rel="nofollow" target="_blank">www.cashpoint.gr</a>. Η Cashpoint κατέχει ηγεμονική θέση στη Γερμανική και Αυστριακή αγορά. Χορηγός επίσης των Βόλφσμπουργκ, Χέρτα και της Αυστριακής Άλταχ.<br />
<br />
<strong>Diamond Link Limited &amp; Lucky Strike Limited</strong><br />
Οι δύο εταιρίες έχουν έδρα τη Μάλτα και λειτουργούν τον ιστότοπο&nbsp;<a href="http://banners.playbetaffiliates.com/redirect.aspx?pid=2188&amp;bid=1634" rel="nofollow" target="_blank">www.playbet.gr</a>. H εταιρία έχει μπει αρκετά δυναμικά στην αγορά, ειδικά μέσω της τηλεοπτικής καμπάνιας. Τελευταία έχει ανεβάσει τις αποδόσεις και συνεχώς βελτιώνει το προϊόν της.&nbsp;<br />
<br />
<strong>Silver Link Limited</strong><br />
Επίσης εταιρεία με έδρα τη Μάλτα, όμως όσο και αν ψάξαμε, δεν βρήκαμε πολλά στοιχεία. Τον Οκτώβριο του 2011, όταν και εκδόθηκε δελτίο τύπου για την ίδρυση της<a href="http://banners.playbetaffiliates.com/redirect.aspx?pid=2188&amp;bid=1634" target="_blank">Playbet.gr</a>&nbsp;φέρεται να είναι μαζί με τις Diamond και Lucky Strike οι ιδιοκτήτριες εταιρείες.<br />
<br />
<strong>Doms Cars Ltd &nbsp;</strong>&nbsp;- &nbsp;&nbsp;<strong>Doms Holding Ltd &nbsp;</strong>&nbsp;- &nbsp;&nbsp;<strong>Longflex Ltd &nbsp;</strong><br />
Όλες οι παραπάνω εταιρίες συνδέονται άμεσα ή έμμεσα με τη Novigroup Limited, η οποία έχει έδρα το βρετανικό Isle of Man. H Novigroup έκανε την &nbsp;εμφάνιση της στον ελληνικό χώρο με την ιστοσελίδα&nbsp;<a href="http://www.novibet.com/Handlers/AffiliateLanding.ashx?aff=fxbt" target="_blank">www.novibet.com</a>. H Νοvibet, είναι από τις πλέον αξιόπιστες εταιρείες μεταξύ των "24" και αποσκοπεί σε δυναμική είσοδο στην Ευρωπαϊκή αγορά. Το Isle of Man άλλωστε θέτει πιο αυστηρά κριτήρια για την έκδοση αδειών συγκριτικά με Μάλτα και Κουρακάο. Πρόσφατα υπέργραψε συνεργασία με την Quickfire, εταιρεία της Μicrogaming, με σκοπό να βελτιώσει τις gaming υπηρεσίες που προσφέρει.<br />
<br />
<strong>Love 2 Celebrate Ltd</strong><br />
Υπό την άδεια της Love2celebrate λειτουργεί η&nbsp;<strong>Netbet</strong>. H ιστοσελίδα είναι μία από τις τελευταίες προσθήκες στη λίστα και αποτελεί έναν από τους πιο δυνατούς παίκτες στην ελληνική αγορά.&nbsp;<br />
<br />
<strong>Doms Cars Limited</strong>: Από τις 23/11/11 η εταιρεία δεν υφίσταται πλέον και μου κάνει εντύπωση που εξακολουθεί να αναφέρεται με την παραπάνω ονομασία. Στις 23/11 μετονομάστηκε σε Lexgaming Limited η οποία συνδέεται με τον ιστότοπο<a href="http://www.lexcasino.com/" target="_blank">www.lexcasino.com</a>&nbsp;(ανενεργό) που παρέχει καζίνο, αθλητικό στοίχημα και πόκερ.<br />
<strong>Doms Holding Limited:</strong>&nbsp;Εταιρεία που επίσης δεν υφίσταται, καθώς στις 05/04/12 μετονόμαστηκε σε Statusbet Limited, η οποία συνδέεται με τον ιστότοπο<a href="http://www.statusbet.com/" target="_blank">www.statusbet.com</a></div>

<p><strong>Εldorado Sportwetten GmbH</strong></p>

<div>Κάτοχος της ιστοσελίδας&nbsp;<a href="http://www.2winbet.gr"><span style="color:#FF0000">http://www.2winbet.gr</span></a><span style="color:#FF0000">&nbsp;</span>είναι μια καινούργια εταιρεία που παρέχει αξιόπιστες υπηρεσίες με &nbsp;αρκετές επιλογές και &nbsp;πολύ ανταγωνιστικές αποδόσεις που προσφέρει. Πλουσια σε επιλογές στοιχηματισμου&nbsp;και αθλημάτων.Με κάθε εγγραφή είναι η μοναδική εταιρεία που προσφέρει <strong>&nbsp;δωρεάν 5 ευρώ </strong>όπου μπορούν να παιχτούν οπουδήποτε (στοίχημα, ζωντανό στοίχημα, καζίνο κτλ), Αξιο αναφοράς είναι και τα που προσφέρει ειδικά για τους λάτρεις του καζίνο</div>

<div><strong>Gambling Malta Limited</strong><br />
Με έδρα τη Μάλτα, η εταιρεία δραστηριοποιείται στο χώρο των online casino, με πιο γνωστούς ιστότοπους το&nbsp;<a href="http://www.maltagrancasino.eu/" target="_blank">www.maltagrancasino.eu</a>&nbsp;.&nbsp;Υπάρχουν πολλά παράπονα από παίκτες σχετικά με το payout των προϊόντων της και καταγγελίες στην LGA.</div>
</div>

<p><strong>GLB GmbH&nbsp;&nbsp;</strong><br />
Αυστριακή εταιρεία, ιδρύθηκε το 2009 και διατήρει το ιστοχώρο&nbsp;<a href="https://www.goalbetint.com/click.php?ac=89126842" rel="nofollow" target="_blank">www.goalbet.com</a>. Αξιόπιστη εταιρεία με εξαιρετικές αποδόσεις και πλούσιο live.<br />
<br />
<strong>Magic Services Limited</strong><br />
Συνδέεται με την εταιρεία Μagic Gaming Online Limited. Μεταβαίνοντας στη σελίδα<a href="http://www.magicgame.biz/" target="_blank">www.magicgame.biz</a>, η οποία ανήκει στη Magic Gaming Online, βλέπουμε ότι δραστηριόποιειται στον Ασιατικό χώρο και φέρεται να αναλαμβάνει τη δημιουργία και βελτιστοποίηση κυρίως παιχνιδιών για το Casino.<br />
<br />
<strong>Meridian Gaming Limited</strong><br />
Mε έδρα τη Μάλτα, ξεκίνησε τη λειτουργία της το 2008 και διατηρεί τη σελίδα<a href="http://ads.non-stop-bet.com/clicks?c=220&amp;b=41&amp;cb=8790&amp;aff_id=5030&amp;url=https%3A%2F%2Fmeridianbet.gr&amp;affsource=nsb" rel="nofollow" target="_blank">www.meridianbet.gr</a>. Προσφέρει από τις καλύτερες αποδόσεις της αγοράς. Η εταιρεία είναι Σέρβικης προελεύσεως και διατηρεί το μεγαλύτερο δίκτυο επίγειων καταστημάτων στη χώρα.<br />
<br />
<strong>On line Amusement Solutions Limited</strong>&nbsp;<br />
Κάτοχος του διακτυακού καζίνο&nbsp;<a href="http://casinostar777.com/" target="_blank">casinostar777.com</a>, με έδρα τη Μάλτα, ενώ ιδιοκτήτης είναι ο επιχειρηματίας Χρήστος Πλατσατούρας.&nbsp;Στα θετικά το γεγονός πως χρησιμοποιεί τα παιχνίδια της Amaya, από τις κορυφαίες εταιρείες στο χώρο του Casino μαζί με την ισραηλινή Playtech.<br />
<br />
<strong>On line Amusement Solutions LV</strong><br />
H εταιρεία έχει έδρα τις Ολλανδικές Αντίλλες και πιο συγκεκριμένα το Κουρακάο, ενώ διατηρεί επίσης γραφεία και κατέχει άδεια στη Μάλτα από το 2011. Διατηρεί το site&nbsp;&nbsp;<a href="https://www.championsbet.net/" rel="nofollow" target="_blank">www.championsbet.net</a>, το οποίο προσφέρει αθλητικό στοίχημα, καζίνο και πόκερ. Ιδιοκτήτης ο Θωμάς Πλατσατούρας.<br />
<br />
<strong>Paddy Power P.I.C</strong>.<br />
To όνομα Paddy Power αποτελεί εγγυηση στο χώρο του στοιχήματος. Η Ιρλανδική εταιρεία είναι από τους κορυφαίους μπουκμέϊκερ στη Βρετανία και όχι μόνο, ενώ προσφέρει πλούσια γκάμα ειδικών στοιχημάτων. Δεν χρειάζεται να την αναλύσουμε, εφόσον η αξιοπιστία της είναι εφάμιλλη των William Hill, Bet365 κλπ. Επίσης είμαι χρόνια πελάτης και απόλυτα ικανοποιημένος, αν και τελευταία δεν προσφέρει τόσο καλές αποδόσεις. H ιστοσελίδα είναι&nbsp;&nbsp;<a href="http://media.paddypower.com/redirect.aspx?pid=10068420&amp;bid=6030" target="_blank">www.paddypower.com</a>&nbsp;.&nbsp;Επιπλέον αποτελεί τον επίσημο πάροχο διαδικτυακού στοιχήματος των Μάντσεστερ Σίτι και Έβερτον.<br />
<br />
<strong>Personal Exchange International Limited</strong><br />
To&nbsp;<a href="http://media.mybet.com/redirect.aspx?pid=6909&amp;bid=2671" rel="nofollow" target="_blank">www.mybet.com</a>&nbsp;είναι από τις κορυφαίες εταιρείες στο χώρο και έκανε την εμφάνιση του το 2001. Αποτελεί μία από τις πλέον αξιόπιστες εταιρείες, ενώ προσφέρει και εξαιρετικές αποδόσεις. Επιπλέον αποτελεί επίσημο χορηγό των Φορτούνα Ντίσελντορφ και Γκρόϊτερ Φιρτ.<br />
<br />
<strong>Rebels Gaming Limited</strong><br />
Kάτοχος της ιστοσελίδας&nbsp;<a href="http://www.betrebels.com/Default.aspx?promoCode=L2TQAAAAABTG66DC" rel="nofollow" target="_blank">www.betrebels.com</a>, λειτουργεί με έδρα τη Μάλτα από το 2011. H εταιρεία είναι αξιόπιστη και έχει καλό live.<br />
<br />
<strong>Sporting Odds Limited</strong><br />
H Sportingodds επκροσωπεί τις&nbsp;<a href="http://sportingbeteur.adsrv.eacdn.com/Processing/ClickThrough.ashx?btag=a_48134b_16563c_&amp;affid=23551&amp;siteid=48134&amp;adid=16563&amp;c=" rel="nofollow" target="_blank">www.vistabet.gr</a>&nbsp;και&nbsp;<a href="http://sportingbeteur.adsrv.eacdn.com/Processing/ClickThrough.ashx?btag=a_48134b_14043c_&amp;affid=23551&amp;siteid=48134&amp;adid=14043&amp;c=" rel="nofollow" target="_blank">www.sportingbet.gr</a>&nbsp;δύο από τις κορυφαίες εταιρείες με μακρόχρονη πορεία στο χώρο. Το όνομα τους αποτελεί εγγύηση στο χώρο των online τυχερών παιχνιδιών.<br />
<br />
<strong>STS Sportwetten GmbH</strong><br />
Διαθέτει άδεια όμως προς το παρόν δεν δραστηριοποιείται μέσω κάποια εταιρείας στην Ελλάδα.&nbsp;<br />
<br />
<strong>Υez Gaming Limited</strong><br />
Kάτοχος της σελίδας&nbsp;www.directslot.com, έχει έδρα τη Μάλτα και ξεκίνησε φέτος τη λειτουργία της. Δεν γνωρίζουμε περαιτέρω στοιχεία σχετικά με την εταιρεία.&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('107.  ΑΚΤΟΜΠΕ -ΣΤΕΑΟΥΑ ', '1406729309', 'ch.jpeg', '<p><strong>Χωρίς ήττα οι Καζάκοι εντός έδρας </strong>....</p>

<p>Σχετικά έυκολα η Ακτόμπε&nbsp; βρέθηκε στον γ΄ προκριματικό με δύο νίκες επί της Ντιναμό Τυφλίδας και χωρίς να δεχθεί γκολ.Με δύο νίκες προκρίθηκε και η Στεαουα και αμφότερες θα θέλουν να αποκτήσουν το προβάδισμα για την πρόκριση.</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ: </span><span style="color:#0000FF">UNDER ( 1.44 <a href="http://www.2winbet.gr" target="_blank">http://www.2winbet.gr</a></span> <span style="color:#0000FF">)</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('108. ΚΑΡΑΜΠΑΓΚ- ΣΑΛΤΣΜΠΟΥΡΓΚ', '1406730578', 'ch.jpeg', '<p class="rtejustify">Η Καραμπαγκ πρόκριθηκε άνετα από το β΄γύρο&nbsp; πετυχαίνοντας δύο νίκες με 1-0 εκτόςεδράς και ευρεία νίκη 4-0 εντός. επί της κατά πολυ αδύνατης Βαλέτα. Από το ρόστερ της ξεχωρίζουν δύο βραζιλιάνοι επιθετικοί Ρεινάλντο και Σουμπίνιο.Η Σλατσμπθργκ σπάει πλάκα στο πρωτάθλημα της χώρας της Εξαιρετικά ενισχυμένη τη φετινή χρονιά με πρωταρχικό στόχο την είσοδο της στους ομίλους</p>

<hr />
<p><span style="color:rgb(255, 0, 0)">ΕΚΤΙΜΗΣΗ : </span><span style="color:rgb(0, 0, 255)">2</span></p>

<p>&nbsp;</p>

<p><span style="color:#FFA500">EXTRA TIP:</span> <span style="color:#0000FF">Τα τελέυταία χρόνια η Σαλτσμπουργκ αδυνατεί να μπεί στους ομίλους του Τσαμπιονς Λιγκ </span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('109. ΑΕ ΛΕΜΕΣΟΥ - ΖΕΝΙΤ ', '1406731498', 'ch.jpeg', '<p><span style="color:#0000FF">Κυνηγώντας την υπέρβαση .......</span></p>

<p class="rtejustify">Δεν διεξάγεται στη φυσική έδρα της γηπεδούχου.Διεκδήκησε μέχτι τέλους το τίτλο στη Κυπρο αλλά τον έχασε από τον Αποέλ.Αρκετές αλλαγές στο ρόστερ , παρέμεινε οσώσο ο προπονητής&nbsp; Πέτε ο οποίος αναμένεται να παρατάξει την ομάδα με πρώτο στόχο το μηδέν στην άμυνα .Έχασε το πρωτ΄θλημα από τα χέρια της στη Ρωσία η Ζενίτ .αλλαγή προπονητή ( προσλήφθηκε ο Βίλας Μπόας) ενώ απέκτεισε και τον Αργεντινό Γκαράι . Πρώτο επίημο μάτσς για τη Ζενίτ.</p>

<hr />
<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ : </span><span style="color:#0000FF">UNDER</span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('110. ΕΛΣΙΝΚΙ- ΑΠΟΕΛ ', '1406732073', 'ch.jpeg', '<p><span style="color:#FF0000">Θα το παλέψει αλλά........</span></p>

<p>&nbsp;</p>

<p class="rtejustify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">Στα 19 ματς αύξησε το αήττητο σε όλες τις διωργανώσεις η Ελσίνκι μετά την εκτός έδρας ισοπαλία με την Τούρκου.Έγιναν πολλές αλλαγές προφυλάχτηκαν βασικοί εν όψει του σημερινού αγώνα .Από μια εξαιρετική σεζόν προέρχεαι ο Αποέλ που κατέκτησε τα πάντα στη Κυπρο. Παραμένει στην Τεχνική ηγεσία ο Γιώργος Δώνης και ενισχύθηκε σημαντικά στην άμυνα με τη προσθήκη τουΠαπάζογλου.</span></span></p>

<hr />
<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ :</span>&nbsp; <span style="color:#0000FF">1</span></p>

<p>&nbsp;</p>

<p><span style="color:#FF8C00">EXTRA TIP:</span> <span style="color:#0000FF">Ισχυρή στην έδρας της η Ελσίνκι , σε καλύτερο επίπεδο ετοιμότητας&nbsp; και σε καλή τιμή ο άσσος </span><span style="color:#FF0000">2.70 <a href="http://www.2winbet.gr" target="_blank">http://www.2winbet.gr</a></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('111. ΝΤΝΙΕΠΡ - ΚΟΠΕΓΧΑΓΗ ', '1406732693', 'ch.jpeg', '<p><span style="color:#0000FF">Μετακόμιζει στο Κίεβο....</span></p>

<p>&nbsp;</p>

<p><span style="font-family:verdana,geneva,sans-serif">Λόγω των δυσάρεστων γεγονότων ο αγώνα θα διεξαχθεί στο Κίβεο και όχι στη φυσική έδρα της Ντνιεπρ. Με το δεξί έχεο μπεί στις ενγχώριες υποχρεώσεις της στο Ουκρανικό Πρωτάθλημα καθώς επιβλήθηκε με 2-0 της Μέταλουργκ. Στο ξέκινημα του πρωταθληματος και η Κοπεγχάγη .</span></p>

<hr />
<p>&nbsp;</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ :</span> <span style="color:#0000FF">ΑΣΣΟΣ</span> <span style="color:#0000FF">1 </span></p>

<p>&nbsp;</p>

<p><span style="color:#FF8C00">EXTRA TIP:</span><span style="color:#0000FF"> Μόνο ήττες μετρά η Κοπεγχάγη στα τελευταία 4 παιχνίδια που έδωσε εκτός έδρας η Κοπεγχάγη .</span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('112. ΓΚΡΑΣΧΟΠΕΡΣ-ΛΙΛ ', '1406733566', 'ch.jpeg', '<p><span style="color:#FF0000">Με αμυντικούς προσανατολισμούς.....</span></p>

<p>&nbsp;</p>

<p><span style="font-size:14px"><span style="font-family:verdana,geneva,sans-serif">Στραβά και ανάποδα ξεκίνησε η Γκρασχόπερς στο νέο πρωτάθλημα με τις δύο πρώτες αγωνιστικές να μετρά&nbsp; 2 ήτττες. Η άμυνα της Λιλ ήταν αυτή ππου την οδήγησε στη κατάληψη της προνομιούχου θέσης για να αγωνιστεί στα προκριματικά του Τσαμπιονς Λιγκ .Σιγουρα θα κατέβει για ένα&nbsp; θετικό αποτέλεσμα.</span></span></p>

<p>&nbsp;</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ:</span>&nbsp; <span style="color:#0000FF">UNDER </span></p>

<p>&nbsp;</p>

<p><span style="color:#FF8C00">EXTRA TIP:</span>&nbsp; <span style="color:#FF0000">Μόνο Ευρωπαικούς αποκλεισμούς γνωρίζει η Γκρασχόπερς απο το 2007 !!!</span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('113. ΛΟΥΝΤΟΓΚΟΡΕΤΣ-ΠΑΡΤΙΖΑΝ', '1406734921', 'ch.jpeg', '<p><span style="color:#0000FF">Με οδηγό την παράδοση ...</span></p>

<p>&nbsp;</p>

<p><span style="font-size:14px">Η Λουντογκόρετς έχει περισσότερα επίσημα παιχνίδια στα πόδια της, τη νώρα που η Παρτιζαν ψάχνει ακόμα για μεταγραφές και τις υποχρεώσεις της να ξεκινούν στις 9 Αυγούστου </span>.</p>

<p>&nbsp;</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ:</span>&nbsp; <span style="color:#0000FF">ΑΣΣΟΣ 1</span></p>

<p><br />
&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('114. ΣΤΑΝΤΑΡ ΛΙΕΓΗΣ VS ΠΑΝΑΘΗΝΑΙΚΟΣ', '1406735672', 'panathinaikos-champions-league-620x412.jpg', '<p><span style="color:#FF0000">Με αυτοπεποίθηση..............</span></p>

<p>&nbsp;</p>

<p class="rtejustify"><span style="font-size:14px"><span style="font-family:verdana,geneva,sans-serif">Εντυπωσιακό ξεκίνημα για τη Στανταρ στο Βελγικό πρωτάθλημα μετατρέποντας σε περίπατο το ντέρμπι μίσους με τη Σαρλεουα .Ο Παναθηναικός έπειτα από αποθσία από τα Ευρωπαικά σαλόνια επιστρέφει .Ο μπεργκ το οπλο του Παναθηναικού.</span></span></p>

<p>&nbsp;</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ: </span><span style="color:#0000FF">ΑΣΣΟΣ 1 </span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('115. ΦΕΓΕΝΟΡΝΤ VS ΜΠΕΣΙΚΤΑΣ ', '1406736116', 'index.jpg', '<p><span style="font-size:14px"><span style="color:rgb(0, 0, 255)">Αποδυναμωμένη η Φέγενορντ...</span></span></p>

<p>&nbsp;</p>

<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">Η φέγενορντ βρίσκεται στα προκριματικά μέσω της&nbsp; δέυτερης θέσης που κατέλαβε πέρυσι στο πρωτάθλημα . Αλλαγή προπονητή με τη θέση του Κούμαν να πέρνει ο Ρούτεν. Ενισχύθηκε η Μπεσίκτας με την απόκτήση του Μπά από τη Τσέλσι.Ικανή για το αποτέλεσμα η Τουρκική ομάδα .</span></span></p>

<p>&nbsp;</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ:</span> <span style="color:#0000FF">Χ2</span><br />
&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά Τσαμπιονς Λιγκ ', '1406736505', 'index.jpg', '<p><span style="font-size:14px">116.&nbsp;&nbsp; Ααλμπόργκ VS Ντιναμό Ζάγκρεμπ </span></p>

<p><span style="color:#FF0000">EKTIMHΣΗ</span>: <span style="color:#0000FF">ΓΚΟΛ </span></p>

<p><span style="font-size:14px">117. Μάριμπορ VS Μακάμπι </span></p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ : </span><span style="color:#0000FF">ΑΣΣΟΣ 1</span></p>

<p>118. Λέγκια VS&nbsp; Σέλτικ</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ</span> : <span style="color:#0000FF">Χ </span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Τριάδα ταμείου ', '1406736891', 'index.jpg', '<p><span style="color:#FF0000">114.</span> ΣΤΑΝΤΑΡ -ΠΑΝΑΘΗΝΑΙΚΟΣ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">UNDER</span></p>

<p><span style="color:#FF0000">115.</span> ΦΕΓΕΝΟΡΝΤ- ΜΠΕΣΙΚΤΑΣ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">Χ2</span></p>

<p><span style="color:#FF0000">116.</span> ΑΑΛΜΠΟΡΓΚ- ΝΤΙΝΑΜΟ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> ΓΚΟΛ</span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά  europa league', '1406808807', 'uefa.jpg', '<p><span style="color:#FF0000">124.</span> &nbsp; ΣΑΧΤΙΟΡ- ΧΑΙΝΤΟΥΚ &nbsp; <span style="color:#0000FF">ΓΚΟΛ&nbsp;</span></p>

<p><span style="color:#FF0000">125. </span>&nbsp; ΑΣΤΑΝΑ- ΑΙΚ ΣΤΟΚΧΟΛΜΗΣ <span style="color:#0000FF">ΓΚΟΛ&nbsp;</span></p>

<p><span style="color:#FF0000">126.</span> &nbsp; ΝΕΦΤΣΙ-ΣΑΚΙΡ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> UNDER</span></p>

<p><span style="color:#FF0000">127. </span>&nbsp; ΑΣΤΡΑ ΠΛΟΕΣΤΙ - ΛΙΜΠΕΡΕΤΣ &nbsp; &nbsp;<span style="color:#0000FF">1&nbsp;</span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('130. ΟΜΟΝΟΙΑ- ΜΕΤΑΛΟΥΡΓΚ ', '1406809167', 'uefa.jpg', '<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span style="color:#0000FF">Βήμα πρόκρισης.....&nbsp;</span></span></span></p>

<p>&nbsp;</p>

<p class="rtejustify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">Νίκη που θα βάλει τις βάσεις για πρόκριση θέλει η Ομόνοια και το μάτς είναι στα μέτρα της .Η Μέταλουργκ , που συμμμετέχει συνεχώς από 2011 σε προκριματικά απέκλεισε με γκόλ στο τελευταίο λεπτό την Ζελεσνιτσάρ 2-2 εκτός και πήρε την πρόκριση στο σύνολο των γκόλ.</span></span></p>

<p class="rtejustify">&nbsp;</p>

<p class="rtejustify"><span style="color:#FF0000"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">ΕΚΤΙΜΗΣΗ &nbsp; &nbsp;</span></span></span><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span style="color:#0000FF">ΑΣΣΟΣ</span></span></span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις από uefa europa league...', '1406809452', 'uefa.jpg', '<p><span style="color:#FF0000">131. </span>&nbsp; ΡΟΥΧ ΧΟΡΖΟΦ- ΕΣΜΠΕΡΓΚ &nbsp;<span style="color:#0000FF"> Χ2</span></p>

<p><span style="color:#FF0000">132.</span> &nbsp; ΑΙΝΤΧΟΦΕΝ- ΣΕΝΤ ΠΟΛΕΝ <span style="color:#0000FF">OVER</span></p>

<p><span style="color:#FF0000">133. </span>&nbsp; ΓΚΕΤΕΜΠΡΟΓΚ- ΡΙΟ ΑΒΕ &nbsp;<span style="color:#0000FF"> &nbsp;1&nbsp;</span></p>

<p><span style="color:#FF0000">134.</span> &nbsp; ΚΑΡ. ΚΑΡΑΜΠΟΚ- ΡΟΖΕΝΜΠΟΡΓΚ &nbsp;<span style="color:#0000FF">2&nbsp;</span></p>

<p><span style="color:#FF0000">135. </span>&nbsp; ΜΠΟΛΕΣΛΑΒ-ΛΥΩΝ &nbsp; <span style="color:#0000FF">UNDER</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ο πιγκουίνος προτείνει.....', '1406810237', 'uefa.jpg', '<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">Θα ξεκινήσω την ευρωπαική βραδιά με το 146 του κουπονιού <strong>Κλαμπ μπρίζ- Μπρόντπι ,&nbsp;</strong>Αμφότερες οι ομάδες διαθέτουν ποιότητα μεσοεπιθετικά επομένως η επιλογή του <strong>γκολ&nbsp;</strong>είναι το φαβορί. Στο 151&nbsp;<strong>Στιαρναν-Λεχ Πλόζαν&nbsp;</strong>με καλή ψυχολογία η Στιαρναν στον αγώνα και με τα τεέυταία της 8 παιχνίδια να είναι στο οβερ .Σκοράρει η Λεχ Πλόζαν και η εκτίμηση μοθ για το ματς <strong>γκολ .</strong>Τελος το 152 <strong>Σεντ ΤΖονσον-Σπαρτακ Τρναβα</strong> .Θα το παλέψουν χωρίς να ανοιχτουν και το<strong> under &nbsp;</strong>φανταζει ιδανικο..</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('147. Μαιντζ- Αστέρας Τρίπολης ', '1406811221', 'uefa.jpg', '<p><span style="color:#FF0000">Μπορεί να τα καταφέρει ...</span></p>

<p>&nbsp;</p>

<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">Δέν έπεισε στο &nbsp;τελευταίο φιλικό η Μάιντζ , ο οποία κέρδισε με γκόλστο φινάλε την Μπερτόν ομάδα 4 ης κατηγορίας της Αγγλίας.Νέα τάξη πραγμάτων και στο πάγκο , αφού ο Τούχελ αντικαταστάθηκε από τον Χίουλμαντ.Πάντως ούτε μία ήττα στα παιχνίδια προετοιμασίας τους δεν είχαν οι κόκκινοι.Ο Αστέρας έκανε τα έυκολα δύσκολα στη ρεβάνς με τη Ροβανιέμι , αφου ισοφαρίστηκε από 2-0 2-2 ,ωστοσο έδειξε χαρακτηρα και πήρε τη νικη πρόκριση με 4-2.Αναμένεται κλειστό ματς.</span></span></p>

<p>&nbsp;</p>

<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ:</span> <span style="color:#0000FF">UNDER</span></span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('147. Μαιντζ- Αστέρας Τρίπολης ', '1406811226', 'uefa.jpg', '<p><span style="color:#FF0000">Μπορεί να τα καταφέρει ...</span></p>

<p>&nbsp;</p>

<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">Δέν έπεισε στο &nbsp;τελευταίο φιλικό η Μάιντζ , ο οποία κέρδισε με γκόλστο φινάλε την Μπερτόν ομάδα 4 ης κατηγορίας της Αγγλίας.Νέα τάξη πραγμάτων και στο πάγκο , αφού ο Τούχελ αντικαταστάθηκε από τον Χίουλμαντ.Πάντως ούτε μία ήττα στα παιχνίδια προετοιμασίας τους δεν είχαν οι κόκκινοι.Ο Αστέρας έκανε τα έυκολα δύσκολα στη ρεβάνς με τη Ροβανιέμι , αφου ισοφαρίστηκε από 2-0 2-2 ,ωστοσο έδειξε χαρακτηρα και πήρε τη νικη πρόκριση με 4-2.Αναμένεται κλειστό ματς.</span></span></p>

<p>&nbsp;</p>

<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ:</span> <span style="color:#0000FF">UNDER</span></span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('149. ΣΑΡΑΓΙΕΒΟ - ΑΤΡΟΜΗΤΟΣ', '1406811939', 'europa-league-logo.jpg', '<p><span style="font-size:14px"><span style="color:rgb(0, 0, 255)">Με το κόσμο δίπλα του ο Ατρόμητος ....</span></span></p>

<p>&nbsp;</p>

<p><span style="font-size:14px">Με ναυλομένο τσάρτερ από τη διοίκηση του Ατρομήτου στο πλευρό του θα βρεθουν πέριπου 100 φίλαθλοι για να τον υποστηρίψουν στη προσπάθεια για ένα καλό αποτέλεσμα που θα του δώσει προβάδισα για τη πρόκριση .Μπορεί να μην έχει εγχώριες υποχρεώσεις η Σαράγιεβο δείχνει έτοιμη να γράψει ιστορία. Επιφυλλακτικός ο Ατρόμητος από τη μία και επιθετική η Σαραγιεβο από την άλλη αναμένεται να αλληλοεξουδετερωθουν. </span></p>

<p>&nbsp;</p>

<p><span style="color:#FF0000"><span style="font-size:14px">ΕΚΤΙΜΗΣΗ</span>:</span>&nbsp; <span style="color:#0000FF">ΙΣΟΠΑΛΙΑ</span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('150. Σοσιεδαδ-Αμπερντιν  La bombita', '1406813102', 'europa-league-logo.jpg', '<p><span style="color:#FF0000"><span style="font-size:14px">Κόντρα στο φαβορί...</span></span></p>

<p><span style="font-size:14px">Με προβληματίζουν οι αποδόσεις!! φαβορί η Σοσιεδαδ , αλλα η ομάδα δεν έχει φτάσει ούτε στα μισά της προετοιασίας της ,φεύγουν συνεχώς παίχτες ενώ από την άλλη η Αμπερντίν στο προηγούμενο γύρο απέκλεισε την Ολλανδική Γκρόνινγκεν με νίκη μέσα στην Ολλανδία γίατι όχι και εδω η εκπληξη. <span style="color:#FF0000">ΕΚΤΙΜΗΣΗ:</span><span style="color:#0000FF"> Χ2 </span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Χωρίς φόβο ο Αστέρας Τρίπολης.....', '1406814665', 'asteras.gif', '<p><span style="color:#FF0000"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">Δεν τρομάζει η Μαιντζ......</span></span></span></p>

<p>Η Μαιντζ είναι μία από τις πλέον βελτιωμένες ομάδες της Γερμανίας τα τελεταία χρόνια και το οφείλει στον Τόμας Τούχελ&nbsp; και παραμένει άγνωστο για πίο λόγο αποχώρησε ο εξαιρετικός τεχνικός από το τιμόνι της ομάδας..Ο Δανός Χιοθλμαντ που ανέλαβε τα ηνία θα έχει δύσκολο εργο αν και ουσιαστικά παραλαμβάνει μία ομάδα έτοιμη .Πολύ δυνατή στην έδρα της η Μαιντζ που αντλέι δύναμη από την έντονη συμμετοχή τωνοπαδών που γεμίζουν την Κοφεις Αρένα ωστόσο η χρονικη περίοδος δε βοηθάει και πληροφορίες αναφέουν από Γερανία ότι δεν εχουν πουληθεί όλα τα εισητηρία ισως γιαίτ βλέπον σαν έυκοολο εργο τον αγώνα. Η Ελληνική ομάδα δεν υπολείπεται σε βαθμό ετοιμότητας των Γερμανών και μπορεί να οδηγήσει το παιχνίδι σε χαμηλό ρυθμό.Δελεαστικη και η απόδοση του under.</p>

<p>&nbsp;</p>

<p><br />
&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Σαράγεβο - Ατρόμητος 1-2', '1406839161', 'fytanidis_nastos_atromitos.jpg', '<p><span style="background-color:rgb(255, 255, 255); font-family:open sans,helvetica,arial,sans-serif; font-size:12px">Μπορεί να μην έπιασε την καλύτερη δυνατή απόδοση σε όλο το παιχνίδι με την Σαράγεβο όμως βρήκε τον τρόπο να σκοράρει δύο φορές και&nbsp;να πάρει τη νίκη και μαζί και τον πρώτο λόγο για την πρόκριση. Ο Ατρόμητος χάρις στα γκολ των Φυτανίδη στο 11'' και Νάστου στο 74'' επικράτησε 2-1 εκτός έδρας των Βόσνιων, κάνοντας αποφασιστικό βήμα για την πρόκριση στην συνέχεια του&nbsp;</span><span style="font-family:open sans,helvetica,arial,sans-serif; font-size:13px">Europa League.</span><br />
<br />
<span style="font-family:open sans,helvetica,arial,sans-serif; font-size:12px">Διάβασε περισσότερα στο:&nbsp;<a href="http://www.gazzetta.gr/football/article/638464/saragevo-atromitos-1-2#ixzz3953iynLP" style="margin: 0px; padding: 0px; color: rgb(0, 51, 153); text-decoration: none;">Σαράγεβο - Ατρόμητος 1-2 | gazzetta.gr</a>&nbsp;</span><br />
&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Μάιντς - Αστέρας Τρίπολης 1-0', '1406839258', '1132490.jpg', '<p>Με 4-2-3-1 παρέταξαν τις ομάδες τους στον αγωνιστικό χώρο οι δύο προπονητές στο ξεκίνημα του αγώνα. Ο Στάικος Βεργέτης προτίμησε να αφήσει τον Μπαντή στον πάγκο και να βάλει κάτω από τα δοκάρια τον Θεοδωρόπουλο.</p>

<p>Από εκεί και πέρα, ο Λούι ήταν δεξιά στην άμυνα, ο Παντελιάδης αριστερά και οι Ζησόπουλος, Γκοϊάν στα στόπερ. Αμυντικά χαφ οι Κουρμπέλης, Μουνάφο και μπροστά τους δεξιά ο Μπαντιμπανγκά, αριστερά ο Μάσα και στον άξονα ο Ρόλε. Μόνος του στην κορυφή ο Ντε Μπλάσις.</p>

<p><strong>Στον πάγκο ο Καπίνο</strong></p>

<p>Στον αντίποδα, ο Κάσπερ Χιούμλαντ προτίμησε τον Κάριους για τον «άσσο» αφήνοντας τον νεοαποκτηθέντα Στέφανο Καπίνο στον πάγκο. Το δεξί άκρο της άμυνας κάλυπτε ο Χάρα, το αριστερό ο Παρκ Γιο Χο και οι Νοβέσκι, Μπελ αποτελούσαν το κεντρικό αμυντικό δίδυμο. Στα χαφ οι Γκάις, Μπαουμγκάρτλινγκερ και μπροστά τους οι Μόριτς, Μάλι και Κου. Μοναδικός προωθημένος ο Οκαζάκι.</p>

<p><strong>Έκλεισε τους χώρους, είχε δοκάρι</strong></p>

<p>Ο Αστέρας ξεκίνησε καλά και συνέχισε το ίδιο καλά στο πρώτο ημίχρονο κλείνοντας τους χώρους στη Μάιντς και απομακρύνοντας κάθε κίνδυνο, όταν η μπάλα πήγαινε μέσα στην εστία του Θεοδωρόπουλου. Μάλιστα, θα μπορούσε να πετύχει και γκολ, αλλά ο... κεραυνός του Μάσα έξω από την περιοχή τράνταξε το οριζόντιο δοκάρι του Κάριους στο 40''.</p>

<p>Οι Αρκάδες προσπαθούσαν να απειλήσουν κυρίως με τον Μπαντιμπανγκά και τις εξαιρετικές ενέργειές του από δεξιά, όμως δεν έβρισκε κάποιον εκ των συμπαικτών του στις όποιες προσπάθειες είχε. Στο 30'' ο Ντε Μπλάσις κατάφερε με προβολή να γυρίσει την μπάλα από πολύ πλάγια, αλλά ο Μπελ την απομάκρυνε, ενώ το σουτ του Μπαντιμπανγκά δύο λεπτά αργότερα κόντραρε και κατέληξε κόρνερ.</p>

<p>Ο σύλλογος της Τρίπολης έβλεπε τους Γερμανούς να μην απειλούν ιδιαίτερα (μοναδική τελική στο 6'' η κεφαλιά του Μπαουμγκάρτλινγκερ) και πέραν του δοκαριού θα μπορούσε να σκοράρει και στο 36''. Ο Ντε Μπλάσις έκλεψε την μπάλα, τη σήκωσε για τον Ρόλε, αυτός με κεφαλιά τροφοδότησε τον Μάσα, που με νέα κεφαλιά την έστειλε πάνω από τα δοκάρια του αντίπαλου γκολκίπερ.</p>

<p><strong>Ο νόμος του ποδοσφαίρου</strong></p>

<p>Τελικά, ίσχυσε ο νόμος του ποδοσφαίρου. Η Μάιντς όχι μόνο απείλησε, αλλά βρήκε και δίχτυα στην πρώτη καλή της φάση στο ματς. Στην πρώτη φορά που η άμυνα του Αστέρα δεν απομάκρυνε την μπάλα ο Κου βρήκε με κεφαλιά τον Οκαζάκι στο 45'' και αυτός με κοντινή προβολή νίκησε τον Θεοδωρόπουλο για να ανοίξει το σκορ στο Coface Arena. Έτσι, οι φιλοξενούμενοι έμειναν πίσω στο σκορ δευτερόλεπτα πριν την ανάπαυλα και με το... παράπονο, αφού φώναξαν για οφσάιντ.</p>

<p><strong>Με άλλη ψυχολογία η Μάιντς, οπισθοχώρησε ο Αστέρας</strong></p>

<p>Στην επανάληψη η Μάιντς μπήκε με άλλη ψυχολογία έχοντας το γκολ του πρώτου ημιχρόνου, όμως και πάλι ο Αστέρας είχε τη μεγάλη ευκαιρία, που ήταν η μοναδική του συλλόγου της Τρίπολης στο δεύτερο μέρος.</p>

<p>Ο Μπαντιμπανγκά έβγαλε ωραία σέντρα από τα δεξιά, ο Ντε Μπλάσις έκανε το σουτ στην κίνηση στο δεύτερο δοκάρι, αλλά αστόχησε από πολύ κοντά. Ακολούθησαν δύο σουτ του Μάλι στο 50'' και στο 52'', με το πρώτο να περνάει εκτός και το δεύτερο να αποκρούει δύσκολα ο Θεοδωρόπουλος για να απομακρύνει σε κόρνερ.</p>

<p>Η τελευταία φορά που απειλήθηκε ο γκολκίπερ του Αστέρα ήταν στο 54'' και στο ανάποδο ψαλίδη του Μόριτς, ενώ στη συνέχεια οι φιλοξενούμενοι οπισθοχώρησαν, κάτι που οφειλόταν στις αλλαγές του Βεργέτη. Ο τεχνικός των Αρκάδων σκέφτηκε περισσότερο τη ρεβάνς και να μη δεχτεί η ομάδα του άλλο τέρμα. Κάτι που δεν έγινε και το 1-0 έμεινε μέχρι τέλους και δυσκόλεψε τη ρεβάνς στην Τρίπολη.</p>

<p>&nbsp;</p>

<p><br />
<br />
<span style="font-family:open sans,helvetica,arial,sans-serif; font-size:12px">Διάβασε περισσότερα στο:&nbsp;<a href="http://www.gazzetta.gr/football/article/638470/maints-asteras-tripolis-1-0#ixzz3954M1fTC" style="margin: 0px; padding: 0px; color: rgb(0, 51, 153); text-decoration: none;">Μάιντς - Αστέρας Τρίπολης 1-0 | gazzetta.gr</a>&nbsp;<br />
Follow us:&nbsp;<a href="http://ec.tynt.com/b/rw?id=aTTRCUHYOr4Q9lacwqm_6l&amp;u=gazzetta_gr" style="margin: 0px; padding: 0px; color: rgb(17, 86, 136); text-decoration: none;" target="_blank">@gazzetta_gr on Twitter</a>&nbsp;|&nbsp;<a href="http://ec.tynt.com/b/rf?id=aTTRCUHYOr4Q9lacwqm_6l&amp;u=gazzetta.gr" style="margin: 0px; padding: 0px; color: rgb(17, 86, 136); text-decoration: none;" target="_blank">gazzetta.gr on Facebook</a></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('112. ΟΣΤΑΝΔΗ-ΑΝΤΕΡΛΕΧΤ', '1406844958', '21432_news.jpg', '<p>Απουσιαζουν από τους γηπεδούχους οι :&nbsp;Χαβιέ Λούισιντ , Μπράιαν Βίλεμς κεντρικός αμυντικός&nbsp;και ο Νιλς Πιέρ&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Μουντομπάσκετ 2014: Οι νέοι δείχνουν τον δρόμο στην Εθνική Ελλάδας', '1406845758', 'mudo.jpg', '<div>
<div>
<div>Η αναγγελία της άφιξής του στην Αθήνα μέσω μηνύματος που δημοσίευσε στον προσωπικό λογαριασμό του στο twitter το περασμένο Σάββατο, ήταν η πρώτη σοβαρή ένδειξη ότι ο Νικ Καλάθης δεν θα έχανε με τίποτα το επικείμενο Παγκόσμιο Πρωτάθλημα της Ισπανίας (30 Αυγούστου - 14 Σεπτεμβρίου) με την Εθνική Ανδρών.&nbsp;<br />
&nbsp;</div>

<div>Από χθες είναι και οριστικό, καθώς ο ομογενής γκαρντ των Μέμφις Γκρίζλις ενημερώθηκε από την αρμόδια επιτροπή της Διεθνούς Ομοσπονδίας Καλαθοσφαίρισης ότι η ποινή του για τη χρήση της ουσίας ταμοξιφαίνης αφορά αποκλεισμό τεσσάρων μηνών, ισχύει από την ημέρα της ανακοίνωσης του αποκλεισμού του στο ΝΒΑ (18 Απριλίου), συνεπώς θα μπορεί να αγωνιστεί με τα γαλανόλευκα μετά τις 18 Αυγούστου. Πρακτικά, αυτό σημαίνει ότι ο «πυραυλοκίνητος» πόιντ γκαρντ θα χάσει τα δύο τουρνουά προετοιμασίας στο Πο (8-10 Αυγούστου, με αντιπάλους τις Σερβία, Γαλλία και Κροατία) και στο Κάουνας (16-18 Αυγούστου, με τις Λιθουανία, Σλοβενία και Νέα Ζηλανδία), αλλά θα αγωνιστεί στους δύο φιλικούς αγώνες με την Τουρκία στο ΟΑΚΑ (20/8) και στην Κωνσταντινούπολη (22/8).&nbsp;<br />
&nbsp;</div>

<div>Η τροπή στην υπόθεση του Νικ Καλάθη προκαλεί τεράστια ανακούφιση στον ομοσπονδιακό τεχνικό Φώτη Κατσικάρη, καθώς του δίνει την ευκαιρία να προχωρήσει το πλάνο που έχει οραματιστεί απόντος του αρχηγού του Ολυμπιακού, Βασίλη Σπανούλη.&nbsp;<br />
&nbsp;</div>

<div>Το συγκεκριμένο πλάνο βασίζεται στις αγωνιστικές αρετές του 25χρονου γκαρντ, ο οποίος θα έχει στα χέρια του τα «κλειδιά» της ομάδας, ήτοι τη δημιουργία και τις βασικές αποφάσεις, συνεπικουρούμενος στην περιφερειακή γραμμή από τον έμπειρο Νίκο Ζήση και τους Βαγγέλη Μάντζαρη και Κώστα Σλούκα, οι οποίοι θα μπουν τελικά στο πούλμαν με προορισμό το Καρπενήσι, όπου θα διεξαχθεί το βασικό στάδιο της προετοιμασίας.&nbsp;<br />
&nbsp;</div>

<div>Αναφορικά με τον Καλάθη, έχουν ενδιαφέρον δύο στοιχεία. Την απολογία του και γενικότερα την υπερασπιστική γραμμή του ενώπιον της FIBA ανέλαβε ο νομικός και πρώην πρόεδρος της Ελληνικής Ποδοσφαιρικής Ομοσπονδίας Σοφοκλής Πιλάβιος, ο οποίος, για την ιστορία, είχε αναλάβει την εκπροσώπηση ενός σπουδαίου μπασκετμπολίστα, του Θοδωρή Παπαλουκά, στην εξεύρεση συμβιβαστικής λύσης με την ΚΑΕ Ολυμπιακός τον Νοέμβριο του 2013. Το δεύτερο γεννά ακόμη μεγαλύτερη ίντριγκα προκαλώντας... γκελ στους οπαδούς του Παναθηναϊκού, καθώς εν αναμονή της χθεσινής απόφασης ο Καλάθης επισκέφθηκε τα γραφεία της ΚΑΕ Παναθηναϊκός και συναντήθηκε με τον ιδιοκτήτη της ΚΑΕ, Δημήτρη Γιαννακόπουλο.&nbsp;<br />
&nbsp;</div>

<div>Με ένα τεράστιο χαμόγελο, μάλιστα, και κρατώντας τη φανέλα του Τριφυλλιού -&nbsp;δώρο του ιδιοκτήτη -&nbsp;έδωσε την υπόσχεση πως «αυτή τη στιγμή ο στόχος μου είναι να παίξω όσο το δυνατόν καλύτερα στο ΝΒΑ, αλλά το βέβαιο είναι πως όταν επιστρέψω στην Ευρώπη θα αγωνιστώ μόνο στον Παναθηναϊκό». Οι Πράσινοι, πάντως, έχουν αποφασίσει να καλύψουν το κενό του με την απόκτηση του αμερικανού γκαρντ ΝτεΜάρκους Νέλσον (29 ετών, 1,93 μ.), ο οποίος τα δύο τελευταία χρόνια φόρεσε τη φανέλα του Ερυθρού Αστέρα και βρίσκεται πολύ κοντά στο Τριφύλλι. &nbsp;<br />
&nbsp;</div>

<div>Εν τω μεταξύ, στο σημερινό ραντεβού της Εθνικής αναμένεται να δώσει κανονικά το «παρών» και ο τρίτος Ερυθρόλευκος Γιώργος Πρίντεζης, καθώς, σύμφωνα με τις πληροφορίες των «ΝΕΩΝ», η ΚΑΕ Ολυμπιακός έβαλε νερό στο κρασί της «επιτρέποντας» στους αθλητές της να ακολουθήσουν από την πρώτη ημέρα την αποστολή της Εθνικής στην πρωτεύουσα της Ευρυτανίας. Διεμήνυσε, όμως, στους υπευθύνους της Ελληνικής Ομοσπονδίας Καλαθοσφαίρισης ότι οι νομικοί και ασφαλιστικοί σύμβουλοί της θα επισκεφθούν σήμερα τα γραφεία της ΕΟΚ στο ΟΑΚΑ, προκειμένου να ελέγξουν τα ασφαλιστήρια συμβόλαια των διεθνών, και ότι αν αυτά κριθούν ανεπαρκή, θα δημιουργηθεί εκ νέου πρόβλημα στη συμμετοχή των τριών παικτών.</div>

<div>&nbsp;</div>

<div><strong>ΔΙΨΑ ΓΙΑ ΔΙΑΚΡΙΣΗ.&nbsp;</strong>Αξίζει, πάντως, να σημειωθεί ότι άπαντες οι διεθνείς -&nbsp;συμπεριλαμβανομένων φυσικά των Πρίντεζη, Μάντζαρη και Σλούκα -&nbsp;δείχνουν τεράστια δίψα ενόψει της έναρξης της προετοιμασίας. Ο «εθισμένος», μάλιστα, στα μέσα κοινωνικής δικτύωσης Γιάννης Αντετοκούνμπο έχει δημοσιεύσει στον προσωπικό λογαριασμό του στο Instagram τον εαυτό του με τη φανέλα της Εθνικής και επωδό τη φράση «Ετοιμοι για πόλεμο - Εθνική Ελλάδος Μπάσκετ»! Ολα αυτά έρχονται σε αντίθεση, θυμίζουμε, με την ξαφνική άρνηση του τρίτου Ελληνα, που αγωνίζεται στο ΝΒΑ, Κώστα Κουφού.</div>

<div>&nbsp;</div>

<div>πηγη ΤΑ ΝΕΑ www.tanea.gr</div>
</div>
</div>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('«Η Ελλάδα επιστρέφει και στο βόλεϊ»', '1406846128', 'volley-451.jpeg', '<p>Συγχαρητήρια ανακοίνωση για την πορεία της Εθνικής στο Ευρωπαϊκό Λιγκ, εξέδωσε και ο Σύλλογος φίλων Ελληνικών ομάδων πετοσφαίρισης.</p>

<p><strong>ναλυτικά η ανακοίνωση του συλλόγου:</strong></p>

<p>«Το μέλλον τους ανήκει</p>

<p>Ο Σύλλογος Φίλων Ελληνικών Εθνικών Ομάδων Πετοσφαίρισης εκφράζει τα θερμά του συγχαρητήρια στους παίκτες και την τεχνική ηγεσία της Εθνικής μας ομάδας των Ανδρών για την κατάκτηση της 2ης θέσης στο European League και παράλληλα εύχεται ταχεία ανάρρωση στον άτυχο του δεύτερου τελικού Παναγιώτη Πελεκούδα.</p>

<p>Παρά τις δύο ήττες από το Μαυροβούνιο στον τελικό, η πορεία του αντιπροσωπευτικού μας συγκροτήματος στην διοργάνωση χαρακτηρίζεται ως θετική, αφού οι διεθνείς μας απέδειξαν πως το μέλλον τους ανήκει και ότι το ελληνικό βόλεϊ μπορεί να αισιοδοξεί σε καλύτερες ημέρες.</p>

<p>Έπειτα από αρκετούς μήνες σκληρής προετοιμασίας αλλά και αγώνων, οι παίκτες της Εθνικής μας έφθασαν ένα βήμα πριν την έξοδό τους στο World League.</p>

<p>Με την αγωνιστικότητα και το πάθος τους έδειξαν πως η αντίστροφη μέτρηση για την επιστροφή της Ελλάδας στην elite του Ευρωπαϊκού και Παγκοσμίου βόλεϊ έχει ήδη ξεκινήσει.</p>

<p>Αρκεί ΟΛΟΙ ΜΑΖΙ, να επενδύσουμε στην φετινή πορεία, να διορθώσουμε τα όποια λάθη έγιναν και να συνεχίσουμε από εκεί που σταματήσαμε…</p>

<p>Να σταθούμε δίπλα στην Εθνική μας ομάδα και να την στηρίξουμε πραγματικά προκειμένου να επιστρέψει εκεί που πρέπει…</p>

<p>Γιατί το ΑΞΙΖΕΙ και το ΔΙΚΑΙΟΥΤΑΙ…»</p>

<p>&nbsp;</p>

<p><br />
<br />
Διάβασε περισσότερα στο:&nbsp;<a href="http://www.gazzetta.gr/volleyball/article/637126/i-ellada-epistrefei-kai-sto-volei#ixzz395X1ah2n" style="margin: 0px; padding: 0px; color: rgb(0, 51, 153); text-decoration: none;">«Η Ελλάδα επιστρέφει και στο βόλεϊ» | gazzetta.gr</a>&nbsp;<br />
&nbsp;</p>

<div>&nbsp;</div>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('102. Λίλεστρομ-Μπραν ', '1406846771', 'norway-flag-1.jpg', '<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span style="color:#0000FF">Δύσκολα για τη Μπράν εκτός εδρας ....</span></span></span></p>

<p>Με καλή αμυντική λειτουργία οι γηπεδούχοι οι οποόιοι δύσκολα δέχονται&nbsp;το γκόλ θα επιδιεξουν τη νίκη με τα στατιστικά να είναι υπέρ του. Στη 15 η θέση της βαθμολογίας η Μπραν και με κάκιστη παρουσία στα εκτός έδρας ματς δύσκοαλ θα αποσπασει κάτι θετικό προερχόμενη και από εντός έδρας ήττα από τη βίκιβγ με 1-0 σκόρ και καή ψυχολογία.. <span style="color:#FF0000">ΕΚΤΙΜΗΣΗ </span>&nbsp; <span style="color:#0000FF">1&nbsp;&nbsp;</span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('112. ΟΣΤΑΝΔΗ-ΑΝΤΕΡΛΕΧΤ', '1406847272', 'ΩΕΛ.jpeg', '<p><span style="font-family:verdana,geneva,sans-serif"><span style="color:#FF0000">Μέ στόχο του τρείς βαθμούς η Αντερλεχτ...</span></span></p>

<p><span style="font-size:14px">Η πρωταθλήτρια Βελγίου για τη χρονιά που πέρασε <strong>Αντερλεχτ</strong> δοκιμάζεται στην Οστάνδη με μοναδικό στόχο τη νίκη απέναντι σε μία μέτρια ομάδα και με σημαντικές απουσίες όπως αυτή του αρχηγού &nbsp;της..</span></p>

<p>&nbsp;</p>

<p><font color="#ff0000">&nbsp;ΕΚΤΙΜΗΣΗ &nbsp; </font><span style="color:#0000FF">2</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('100. ΡΟΥΜΠΙΝ- ΣΠΑΡΤΑΚ Μ', '1406886918', 'RV.jpg', '<p><span style="color:#FF0000"><span style="font-size:14px">Καλύτερη η Σπαρτάκ ....</span></span></p>

<p>Αρκετές αλλαγές έχουν γίνει στο σύνολο της Ρουμπίν Καζάν . Στη Σπαρτάκ τη τεχνική ηγεσία ανέλαβε ο πρωην τεχνικός της Βασιλείας με μία επιτυχημένη χρονιά.</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ</span>: &nbsp;<span style="color:#0000FF">Χ2 &nbsp;</span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('101. ΣΙΛΚΕΜΠΟΡΓΚ - ΣΟΝΤΕΡΙΣΚΕ', '1406887226', 'dan.jpg', '<p><span style="color:#0000FF"><span style="font-size:14px">Με σκληρές αμυνες....</span></span></p>

<p>Προκεται για &nbsp;δύο ομάδες της Δανίας με σφιχτές άμυνες και η ανάπτυξη του στο γήπεδο είναι με στόχο να κρατήσουν το μηδεν στην άμυνα.Κλειαστο ματας περιμενουμε.</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ</span> &nbsp;<span style="color:#0000FF">Χ &nbsp;</span>και &nbsp;<span style="color:#0000FF">under &nbsp;&nbsp;&nbsp;</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('103. ΑΣΙΡΙΣΚΑ- ΕΣΤΕΡ', '1406887607', 's.jpg', '<p><span style="font-size:14px"><span style="color:#0000FF">Μόνο νίκη θέλει η Ασιρίσκα ....</span></span></p>

<p>Με κακές εμφανίσεις μέχρι τώρα στο πρωτάθλημα η Ασιρισκα βρίσκεται στη τελευταία θέση της βαθμολογίας.Κατάφερε τη προηγούμη αγωνιστικη΄ωστόσο να άρει το βαθμό στην έδρα της Χάμαρμπι και έχοντας κλή ψυχολογία θέλει να πάρει τη νίκη που μόνο έυκολα δε θα έρθει με την Εστερ να προερχεται από νίκη με καθαρό σκορ 2-0 επί της Ανκελχομς..</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ</span><span style="color:#0000FF"> &nbsp;OVER &nbsp;</span></p>

<p><span style="color:#FF8C00">EXRA TIP </span><span style="color:#0000CD">Με επιθετικό σχήμα και οι δύο ομάδες θα κατεβουν στον αγωνιστικό&nbsp;χώρο.&nbsp;</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Εναρξη στη β ΄ Γαλλίας ...', '1406887984', 'GA.jpg', '<p><span style="color:#FF0000">Κάθέ αρχή και δύσκολη...</span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">104</span>. ΑΡΛ- ΑΖΑΞΙΟ &nbsp; <span style="color:#0000FF">&nbsp;Χ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">105</span>. ΓΚΑΖΕΛΕΚ- ΒΑΛΕΝΣΙΕΝ &nbsp; &nbsp;<span style="color:#0000FF">1</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">106</span>. ΛΑΒΑΛ- ΝΙΟΡ &nbsp;<span style="color:#0000FF"> 2 και under&nbsp;</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">107</span>.ΝΑΝΣΙ-ΝΤΙΖΟΝ &nbsp; <span style="color:#0000FF">1</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">108.</span> ΝΙΜ-ΑΝΖΕ <span style="color:#0000FF">UNDER</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">109</span>.ΟΣΕΡ -ΧΑΒΡΗ <span style="color:#0000FF">Χ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">110. </span>ΣΑΤΟΡΟΥ - ΤΡΟΥΑ &nbsp;<span style="color:#0000FF">OVER</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">111</span>. ΤΟΥΡ- ΚΡΕΤΕΙΓ<span style="color:#0000FF"> &nbsp;2-3 ΓΚΟΛ&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Μια τριάδα και μία τετράδα από τον Πιγκουίνο...', '1406888500', 'B.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">103. </span>&nbsp;ΑΣΙΡΙΣΚΑ- ΕΣΤΕΡ &nbsp; <span style="color:#0000FF">OVER</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">111. &nbsp;</span>ΤΟΥΡ-ΚΡΕΤΕΙΓ &nbsp;<span style="color:#0000FF"> 2-3 GOAL</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">114</span>. &nbsp;ΚΟΡΚ- ΝΤΑΝΤΑΛΚ &nbsp; &nbsp;<span style="color:#0000FF">GOAL GOAL&nbsp;</span></span></p>

<hr />
<p><span style="color:#FF0000">104</span>. ΑΡΛ-ΑΖΑΞΙΟ <span style="color:#0000FF">&nbsp; 2</span></p>

<p><span style="color:#FF0000">107</span>.ΝΑΝΣΙ-ΝΤΙΖΟΝ <span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">117.</span>ΝΤΡΟΧΕΝΤΑ-ΓΙΟΥ ΣΙ ΝΤΙ &nbsp; <span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">118</span>. ΣΕΝΤ ΠΑΤΡΙΚΣ-ΣΛΙΓΚΟ ΡΟΒΕΡΣ <span style="color:#0000FF">Χ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πιθανό διπλό στο Τουρ- Κρετέιγ', '1406888791', 'GA.jpg', '<p><span style="color:#FF0000">Μπορεί η κρετειγ...</span></p>

<p>Με σοβαρά οικονομικά προβλήματ η Τουρ στην οποία απαγορέυτηκαν οι μεταγραφές..και δεν ενισχύθηκε μπορεί να κάνει το διπλό η κρετειγ.</p>

<p><span style="color:#FF0000">ΠΡΟΤΑΣΗ</span> &nbsp; &nbsp;<span style="color:#0000FF"> 2 &nbsp; </span><span style="color:#FFA07A">3.45 απόδοση .</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('113.ΦΟΡΤΟΥΝΑ- ΜΠΡΑΟΥΝΣΒΑΙΓΚ', '1406889059', 'GER.jpg', '<p><span style="font-size:14px"><span style="color:#0000FF">Ικανή γία το απότέλεσμα η Μπραουνβαιγκ...</span></span></p>

<p><span style="font-size:14px; line-height:22.399999618530273px">Πιο δεμένη ομάδα η Μπραουνβαιγκ μπορει να πάρει βαθμό η και βαθμούς .Με νέα αποκτήματα η φορτούνα και παρά τα καλα φιλικά δε μας πείθει.</span></p>

<p><span style="color:#FF0000"><span style="font-size:14px; line-height:22.399999618530273px">ΕΚΤΙΜΗΣΗ &nbsp;</span></span><span style="color:#0000FF"><span style="font-size:14px; line-height:22.399999618530273px"> Χ2&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('3-4-5 Σύστημα ημέρας', '1406889403', 'se.jpg', '<p>101. ΣΙΛΚΕΜΠΟΡΓΚ- ΣΟΝΤΕΡΙΣΚΕ &nbsp; <span style="color:#00FFFF">&nbsp;</span><span style="color:#0000FF">Χ</span></p>

<p>106. &nbsp;ΛΑΒΑΛ- ΝΙΟΡ &nbsp; &nbsp; <span style="color:#0000FF">2</span></p>

<p>111.ΤΟΥΡ-ΚΡΕΤΕΙΓ <span style="color:#0000CD">&nbsp;2</span></p>

<p>114. ΚΟΡΚ-ΝΤΑΝΤΑΛΚ <span style="color:#0000FF">&nbsp;Χ</span></p>

<p>116. ΝΤΕΡΙ-ΜΠΟΕΜΙΑΝ <span style="color:#0000FF">&nbsp;Χ&nbsp;</span></p>

<p><span style="color:#FFA500">Σύστημα 3,4,5 &nbsp; και καλα κέρδη&nbsp;</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('118. ΣΕΝΤ -ΠΑΤΡΙΚΣ- ΣΛΙΓΚΟ ΡΟΒΕΡΣ', '1406889696', 'iris.jpg', '<p><span style="color:#0000FF"><span style="font-size:14px">Με τους γηπεδούχους η παράδοση..</span></span></p>

<p><span style="font-size:14px">Με δυσκολία θα έρθει ο άσσος για του αγίους περσινούς πρωταθλητές . Η ομάδα των Αγίων είναι &nbsp;ση τρίτη θέση του βαθμολογικου και με νίκη παραμένει στο κόλπο για διεκδίκηση του τίτλου .</span></p>

<p><span style="color:#FF0000"><span style="font-size:14px">ΕΚΤΙΜΗΣΗ &nbsp;</span></span><span style="color:#0000FF"><span style="font-size:14px">Με ρίσκο ο ασσος και κάλυψη χ&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Σε φόρμα η Αβάι....', '1406889864', 'br.jpg', '<p><span style="font-size:14px">Με αυτοπεποίηθηση η Αβαι έχει σταθερά ανοδική πορεία παρουσιαζόντας καλή εικόνα .Στηρίζουμε τον άσσο.</span></p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ</span> <span style="color:#0000FF">Ασσος&nbsp;</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Βρέχει γκολ στην Ιρλανδία', '1406890085', 'iris.jpg', '<p><span style="color:#FF0000">114</span>. ΚΟΡΚ ΝΤΝΤΑΛΚ &nbsp;<span style="color:#0000FF"> goal goal&nbsp;</span></p>

<p><span style="color:#FF0000">115</span>. ΛΙΜΕΡΙΚ ΣΑΜΡΟΚ &nbsp; <span style="color:#0000FF">OVER&nbsp;</span></p>

<p><span style="color:#FF0000">117.</span> ΝΤΡΟΧΕΝΤΑ- ΓΙΟΥ ΣΙ ΝΤΙ <span style="color:#0000FF">&nbsp;4-6 goal&nbsp;</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('126.ΤΙΧΟΥΑΝΑ-ΤΙΓΚΡΕΣ', '1406905640', 'images.jpg', '<p><span style="color:#FF0000">Η γνωστή μας Τιγκρες με το σενάριο μεταγραφης Πουλίδο...</span></p>

<p>Στο αγωνιστικό κομμάτι η Τίγκρες προέρχεται από μία ευρεία νίκη με 4-0 και η ανιπαλός της σήμερα προέρχεται από νίκη .Προβλέπεται ένα ανοιχτό ματσς με αρκετα&nbsp; γκόλ.</p>

<p><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ&nbsp;</span> <span style="color:#0000FF">OVER</span><br />
&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Με αγωνιστική δράση από Ιαπωνία ξεκινά το κουπόνι Σαββάτου', '1406925960', 'BqgvZFJIQAA_QsD.jpg', '<p><span style="font-size:14px">Για τους φίλους του Ιαπωνικού πρωταθλήματς επιλέξαμε και σας προτείνουμε τρεία σημεία που ξεχωρίζουν :</span></p>

<p><span style="font-size:13px"><span style="font-family:arial"><span style="color:#FF0000">130.&nbsp;</span> ΤΟΚΥΟ - ΣΙΜΙΖΟΥ</span></span>&nbsp;&nbsp; <span style="color:#0000FF">ΑΣΣΟΣ</span></p>

<p><span style="color:#FF0000"><span style="font-size:13px"><span style="font-family:arial">132</span></span><strong><span style="font-size:13px"><span style="font-family:arial">.</span></span></strong></span><span style="font-size:13px"><span style="font-family:arial"><span style="color:#FF0000"> </span>ΚΑΣΙΒΑ - ΚΑΒΑΣΑΚΙ&nbsp;&nbsp; <span style="color:#0000FF">UNDER</span></span></span></p>

<p><span style="color:#FF0000"><span style="font-size:13px"><span style="font-family:arial">133.</span></span></span><span style="color:rgb(0, 0, 255)"><strong><span style="font-size:13px"><span style="font-family:arial">&nbsp; </span></span></strong></span><span style="font-size:13px"><span style="font-family:arial">ΝΙΙΓΚΑΤΑ - ΤΣΕΡΕΖΟ ΟΣΑΚΑ&nbsp;<span style="color:#0000FF"> </span></span></span><span style="color:#0000FF">ΑΣΣΟΣ</span></p>

<p><br />
&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('137. Λειψία -Αάλεν ', '1406971808', 'germania.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">Βάπτισμα πυρός για τη Λειψία....</span></span></p>

<p><span style="font-size:14px; line-height:22.399999618530273px">Από δυο σερί ανόδους κατηγορίας προέρχεται η Λειψία και έχοντας ξοδέψει αρκετά χρήματα για μεταγγραφές ευπλπιστεί να εδρεωθεί στή β΄κατηγορία και να διεκδηκίσει οτι καύτερο. Από την άλλη πίο έμπειρη η Άαλεν στη κατηγορία και ισως αυτό και μόνο θα δυσκολέψει τη γηπεδούχο .Αναμένεται κλειστό παιχνίδι και θα χρειασεί χρόνος να βρούν πατήματα οι δύο ομαδες.</span></p>

<p><span style="font-size:14px; line-height:22.399999618530273px"><span style="color:#FF0000">ΕΚΤΙΜΗΣΗ: </span>&nbsp; <span style="color:#0000FF">UNDER&nbsp;</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ά Νορβηγίας ', '1406972346', 'norway-flag-1.jpg', '<p><span style="color:#0000FF">145. &nbsp;ΣΤΡΟΜΣΓΚΟΝΤΣΕΤ - ΣΟΓΚΝΤΑΛ &nbsp; &nbsp;</span><span style="color:#FF0000">ΑΣΣΟΣ</span></p>

<p><span style="color:#0000FF">174. &nbsp;ΒΙΚΙΝΓΚ - ΒΑΛΕΡΕΝΓΚΑ &nbsp;</span><span style="color:#FF0000"> &nbsp;Χ2&nbsp;</span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πρωτάθλημα Ρωσίας..', '1406973234', 'Flag_of_Russia.png', '<p><span style="color:#FF0000"><strong>168. ΟΥΡΑΛ – Μ. ΣΑΡΑΝΣΚ&nbsp;</strong></span><strong>Ακόμα δεν έχει πιστέψει η Ουράλ πως σώθηκε και πρέμεινε στη κατηγορία τη περσινή σεζόν , πιο έτοιμη και πίστη στις δυνατότητες της Μ Σαρανσκ .</strong><span style="color:#0000CD"><strong>ΕΚΤΙΜΗΣΗ &nbsp;Χ2 &nbsp;</strong></span><span style="color:#FF0000"><strong>140. ΑΡΣΕΝΑΛ ΤΟΥΛΑ – ΖΕΝΙΤ </strong></span><strong>Φαβορί η Ζενίτ άλλα και με το μυαλό στη Κυπριακή Αελ για της Ευρωπαικές υποχρεώσεις ισώς κρύει παγίδες ο ματς. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ no bet .</span><span style="color:#FF0000">131.&nbsp;ΤΣΣΚΑ ΜΟΣΧΑΣ – ΤΟΡΠΕΝΤΟ ΜΟΣΧΑΣ&nbsp;</span>Δυνατή η Τσσκά Μόσχας αποτελέι το φαβορί για τη κατάκτηση του πρωταθλήματος&nbsp;απεναντί της μία ιστορική ομάδα που επιστρέφει στη πρώτη κατηγορία. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 1 .</span></strong></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Δανία:Με το μυαλό στο Τσαμπιονς Λιγκ για Κοπεγχάγη και Ααλμποργκ', '1406973770', 'Flag_of_Denmark.svg_.png', '<p><span style="color:#FF0000"><strong>141. ΒΕΣΤΖΕΛΑΝΤ – ΚΟΠΕΓΧΑΓΗ &nbsp;:</strong></span><span style="font-size:14px">Η Βεστετλαντ &nbsp;κ<span style="font-family:verdana,arial,sans-serif">όν</span><span style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif">τρα στη Νόρντζελαντ είχε στείλει το μήνυμα πως φέτος θα παίξει περισσότερο επιθετικά από πέρσι. Απέναντι στην Οντένσε απέδειξε πως αυτό ισχύει, χάρη στον επιθετικό της μονόλογο στο πρώτο ημίχρονο πήρε μια εύκολη νίκη που θα μπορούσε να είναι μεγαλύτερη, αν ήταν πιο προσεκτική στην τελική προσπάθεια.</span><span style="font-family:verdana,arial,sans-serif">Η Κοπεχγαγη&nbsp;</span><span style="font-family:verdana,arial,sans-serif">Την Τετάρτη στο Κίεβο απέσπασε 0-0 από την Ντνιέπρ, αύξησε τις πιθανότητες πρόκρισης στην επόμενη φάση του Τσάμπιονς Λιγκ, «βράζει» για το... ξύλο που δέχθηκαν οι οπαδοί της από μασκοφόρους Ουκρανούς στο ημίχρονο. «</span><em>Αυτές ήταν εικόνες ντροπής και δεν έπρεπε να συμβούν, περιμένουμε την τιμωρία της αντιπάλου»</em><span style="font-family:verdana,arial,sans-serif">, δήλωσαν προπονητής και πρόεδρος. Οι Ουκρανοί ισχυρίζονται πως το περιστατικό ξεκίνησε όταν οπαδοί της Κοπεγχάγης σήκωσαν μια... ρωσική σημαία, η διοίκηση της ομάδας το αρνείται. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 2-3 ΓΚΟΛ. </span><span style="color:#FF0000">170&nbsp;</span></span></span><span style="color:#FF0000"><strong>ΟΝΤΕΝΣΕ – ΑΑΛΜΠΟΡΓΚ</strong></span><strong>&nbsp;</strong><span style="font-family:verdana,arial,sans-serif; font-size:11px">Ο</span><span style="font-size:14px"><span style="font-family:verdana,arial,sans-serif">υ</span><span style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif">ραγός μετά από δύο ματς και άρχισαν να τη ζώνουν τα φίδια. Κάκιστη στο ματς με τη Βέστζελαντ, είχε ρόλο κομπάρσου από την αρχή, ξύπνησε όταν ήταν αργά και απλά μείωσε σε 3-1 στο δεύτερο ημίχρονο.Την Τετάρτη γνώρισε εντός έδρας ήττα από την Ντιναμό Ζάγκρεμπ (0-1) για τα προκριματικά του Τσάμπιονς Λιγκ, δύσκολο το έργο της στον επαναληπτικό της Κροατίας που ακολουθεί. Μαγική εικόνα το σκορ, είχε πολλές ευκαιρίες στο πρώτο ημίχρονο, δοκάρι στο πρώτο δεκάλεπτο και γενικά άξιζε το γκολ, όμως οι πιο έμπειροι Κροάτες χτύπησαν εκεί που έπρεπε. </span><span style="color:#0000FF"><span style="font-family:verdana,arial,sans-serif">ΕΚΤΙΜΗΣΗ Χ</span></span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Φινλανδία .142 ΜΙΛΙΚΟΣΚΙ-ΕΛΣΙΝΚΙ ', '1406974189', 'FIL.jpg', '<p><span style="font-size:14px"><span style="font-family:verdana,arial,sans-serif"><strong>Η Ελσίνκι </strong>Κατέβαλλε τεράστια προσπάθεια την Τετάρτη απέναντι στον ΑΠΟΕΛ και άγγιξε μία σπουδαία ευρωπαϊκή νίκη για τον τρίτο προκριματικό του Τσάμπιονς Λιγκ. Εφαρμόζοντας έξυπνη τακτική προηγήθηκε 2-0 στο πρώτο ημίχρονο με γκολ του εξτρέμ Σάβατζ (11'', 45+1'' πεν.). Στο 49'' όμως η χαζή αποβολή του φορ Κάντζι την ανάγκασε να παίξει ταμπούρι στα εναπομείναντα λεπτά και οι πρωταθλητές Κύπρου (είχαν και δοκάρι στο 39'') έφτασαν δίκαια στο 2-2 (70'', 74'').Για την Μιλικόσκι κ</span><span style="font-family:verdana,arial,sans-serif">αιρό είχε να πραγματοποιήσει τόσο ψυχωμένη και παθιασμένη εμφάνιση όσο αυτή κόντρα στην Κουόπιο. Μολονότι λοιπόν βρέθηκε πίσω στο σκορ στο 8'' με πέναλτι και έμεινε με δέκα στο 20'', κέρδισε 5-3 βάζοντας πέντε γκολ (45'', 67'', 76'', 85'' πεν., 87'') με παίκτη λιγότερο! <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ OVER&nbsp;</span></span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Σουπέρ καπ Γαλλίας Παρί Σεν Ζερμέν -Γκινγκάπ', '1406974643', 'thumb.jpg', '<p><span style="color:#FF0000">Με τον αγώνα να διεξάγεται στο Πεκίνο</span> η Παρί Σσεν Ζερμέν θέλει να μπέι με το δεξί στις υποχρεώσεις και να κυνηγήσει τι κάτι παρα πάνω.Για τη Γκινγκάπ απόλυτα επιτυχημένη θεωρείτεη χρονιά καθώς προερχομενη από τη β κατηγορία κατάφερε να σωθεί και φυσικά να κατακτήσει και το κύπελλο!! <span style="color:#0000FF">&nbsp;ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ και OVER</span>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Πιγκουίνου ...', '1406975157', 'pigkouinos_stamp.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">145.</span>&nbsp;Στρόμσγκοντσετ - Σόγκνταλ &nbsp; <span style="color:#0000FF">OVER&nbsp;</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">160</span><span style="color:#0000FF">.&nbsp;</span><span style="background-color:rgb(246, 246, 246); color:rgb(3, 3, 3); font-family:verdana,arial,helvetica,sans-serif">Έρεμπρο - Χάλμσταντ &nbsp;</span><span style="color:#0000FF"><span style="background-color:rgb(246, 246, 246); font-family:verdana,arial,helvetica,sans-serif">2-3 GOAL</span></span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">182.</span> Γκρασχόπερς Σιον &nbsp; &nbsp;<span style="color:#0000FF">Χ2&nbsp;</span></span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('΄Β Γερμανίας ..', '1407056742', 'germany_flag.jpg', '<p><span style="color:#0000FF">210. ΧΑΙΝΤΕΝΧΑΙΜ - ΦΣΦ ΦΡΑΝΚΦΟΥΡΤΗΣ&nbsp;</span>Με το δεξί θέλει&nbsp;να ξεκινήσει της υποχρεώσεις της η Χαιντεχαιμ στη κατηγορία με τα την ανοδό της &nbsp;κίνηθηκε σε μεταγγραφές και δοαθλετει ένα αξιλογο σύνολο.Από την άλλη η ομάδα της Φρανκφούρτης έχασε το καλυτέρο της παίχτη Λέκι ενώ τραυματισμοί ταλαιπωρούν τρείς βασικους της παίχτες. Την ευκαιρία θέλουν να αρπάξουν οι γηπεδούχοι,<span style="color:#FF0000"> ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ. </span><span style="color:#0000FF">217.<span style="color:#FF0000"> </span>ΚΑΡΛΣΡΟΥΗ -ΟΥΝΙΟΝ ΒΕΡΟΛΙΝΟΥ&nbsp;</span>Ενισχυμένη η Καρλσρούη μετά τη περσυνή καλή πορεία και τη πέμπτη θέση ζητά το κάτι παραπάνω.Με νέο προπονητή η Ουνιον μετά απο μία επταετία.<span style="color:#FF0000">ΕΚΤΙΜΗΣΗ &nbsp; ΙΣΟΠΑΛΙΑ. </span><span style="color:#0000FF">218 ΝΤΑΡΜΣΤΑΝΤ- ΣΑΝΤΧΑΟΥΖΕΝ&nbsp;</span>Μ ε απουσίες οι νέοι δύσκολα για τη νίκη , με εμπειρία η Σαντχαουζεν θα πάρει βαθμό <span style="color:#FF0000">. ΕΚΤΙΜΗΣΗ Χ2 . </span><span style="color:#0000FF">219 ΝΥΡΕΜΒΕΡΓΗ -ΑΟΥΕ </span>Ενας και μοναδικός ο στόχος της Νυρεμβέργης να επιστρψει στα σαλόνια της Μπουντεσλιγκας <span style="color:#FF0000">ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ελβετία .. Γκολ και εμπειρία ', '1407057164', 'σημαία ελβετίας.png', '<p><span style="font-size:14px"><span style="color:#FF0000">211. ΑΑΡΑΟΥ- ΒΑΝΤΟΥΖ</span> &nbsp;Με εμπειρία στη κατηγορία η Ααραου και με κακά ψυχολογία η Βαντούζ από τον αποκλεισμό στο Γιουρόπα Λιγκ. <span style="color:#0000FF">ΕΚΙΤΜΗΣΗ ΑΣΣΣΟΣ</span>. <span style="color:#FF0000">212 . ΖΥΡΙΧΗ ΓΙΟΥΝΓ ΜΠΟΙΣ</span> Με εφεση στο γκόλ κυρίως η Ζυρίχη .Σκοράρει και η φιλοξενούμενη . <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ ΓΚΟΛ </span>.<span style="color:#FF0000">221. ΣΕΝ ΓΚΑΛΕΝ -ΛΟΥΚΕΡΝΗ</span> Πολλά τα κενά&nbsp;την άμυνα της Σεν Γκάλεν ενώ δυσκολευονται και οι επιθετικοί της να βρούν δίχτυα .<span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 2&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ο Πιγκουίνος ....', '1407057585', 'pigkouinos_stamp.jpg', '<p><span style="color:#FF0000">214</span>. ΝΤΙΝΑΜΟ ΜΟΣΧΑΣ - ΡΟΣΤΟΦ &nbsp; &nbsp;<span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">216</span>.ΚΑΛΜΑΡ- ΜΠΡΟΜΑΠΟΙΚΑΡΝΑ <span style="color:#0000FF">&nbsp;1</span></p>

<p><span style="color:#FF0000">220.</span> ΟΝΤ- ΣΑΝΤΣΕΣ &nbsp; <span style="color:#0000FF">&nbsp; ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">228</span>. ΣΕΙΝΑΓΙΟΝΕΝ-ΙΝΤΕΡ ΤΟΥΡΚΟΥ <span style="color:#0000FF">&nbsp;2-3 ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">236</span>. ΜΠΡΙΝΕ- ΧΟΝΕΦΟΣ &nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">237</span>. ΝΕΣΤ ΣΟΤΡΑ-ΜΠΑΕΡΟΥΜ <span style="color:#0000FF">OVER&nbsp;</span></p>

<p><span style="color:#FF0000">239</span>.ΤΡΟΜΣΝΤΑΛΕΝ - ΦΕΡΕΝΤΡΙΚΣΤΑΝΤ <span style="color:#0000FF">2</span></p>

<p><span style="color:#FF0000">241</span>. ΧΟΜΠΡΟ- ΜΠΡΟΝΤΜΙ &nbsp;<span style="color:#0000FF">OVER</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πρωτάθλημα Βραζιλίας ', '1407057994', 'αρχείο λήψης.jpg', '<p><span style="color:#FF0000">247</span>. ΚΟΡΙΤΙΜΠΑ- ΚΟΡΙΝΘΙΑΝΣ &nbsp; <span style="color:#0000FF">2</span></p>

<p><span style="color:#FF0000">248</span>. ΠΑΛΜΕΙΡΑΣ-ΜΠΑΙΑ &nbsp;<span style="color:#0000FF"> 1</span></p>

<p><span style="color:#FF0000">249.</span> ΣΑΠΕΚΟΕΝΣΕ-ΦΛΑΜΕΝΓΚΟ <span style="color:#0000FF">&nbsp;ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">250</span>. ΦΙΓΚΕΡΕΝΣΕ- ΣΠΟΡΤ ΡΕΣΙΦΕ <span style="color:#0000FF">UNDER</span></p>

<p><span style="color:#FF0000">254.</span> ΑΤΛΕΤΙΚ ΜΙΝΕΙΡΟ- ΠΑΡΑΝΑΕΝΣΕ &nbsp;<span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">255</span>. ΙΝΤΕΡΝΑΣΙΟΝΑΛ-ΣΑΝΤΟΣ <span style="color:#0000FF">&nbsp; 1</span></p>

<p><span style="color:#FF0000">256</span> ΦΛΟΥΜΙΝΕΝΣΕ- ΓΚΟΙΑΣ <span style="color:#0000FF">ΓΚΟΛ</span>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Γκολ απο Φινλανδία και Νορβηγία ', '1407058374', '48394-532-1(1)-960.jpg', '<p><span style="color:#FF0000">226.</span> ΒΑΑΣΑ -ΛΑΧΤΙ &nbsp;<span style="color:#DAA520"> ΓΚΟΛ&nbsp;</span></p>

<p><span style="color:#FF0000">227</span>.ΡΟΒΑΝΙΕΜΙ - ΚΟΥΟΠΙΟ <span style="color:#DAA520">OVER</span></p>

<p><span style="color:#FF0000">233</span>. ΣΤΑΡ- ΜΟΛΝΤΕ <span style="color:#DAA520">&nbsp;ΓΚΟΛ&nbsp;</span></p>

<p><span style="color:#FF0000">236</span>.ΜΠΡΙΝΕ-ΧΟΝΕΦΟΣ <span style="color:#DAA520">OVER</span></p>

<p><span style="color:#FF0000">238</span>. ΟΥΛΕΝΣΑΚΕΡ-ΧΟΝΤ <span style="color:#DAA520">&nbsp;2-3 ΓΚΟΛ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Μεξικό , όχι οπως τη περιμέναμε η Τολούκα ', '1407078661', 'ΜΕΧ.jpeg', '<p><span style="color:#FF0000"><span style="font-family:verdana,arial,sans-serif; font-size:11px">242. ΤΟΛΟΥΚΑ – ΠΟΥΜΑΣ (20.00)&nbsp;</span></span><span style="font-family:verdana,arial,sans-serif; font-size:11px">Προβληματίζει στο ξεκίνημα η Τολούκα και ο άσσος στο 1.70 δέν προσφέρεται για ποντάρισμα αντιθετως η όχι τοσο καλή βέβαια πούμας θα δικεδηκήσει βαθμό και λόγω αξίας του διπλού η επιλογή του χ2φαντάζει καλύτερη. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ Χ2</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:100%">
	<tbody>
		<tr>
		</tr>
		<tr>
			<td colspan="6"><strong>ΜΕΞΙΚΟ : ΑΠΕΡΤΟΥΡΑ</strong></td>
		</tr>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΚΛΑΜΠ ΑΜΕΡΙΚΑ</td>
			<td><strong>9</strong></td>
			<td>3</td>
			<td>8-2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΑΤΛΑΣ</td>
			<td><strong>7</strong></td>
			<td>3</td>
			<td>6-2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΜΟΝΤΕΡΕΪ</td>
			<td><strong>7</strong></td>
			<td>3</td>
			<td>4-1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΚΕΡΕΤΑΡΟ</td>
			<td><strong>6</strong></td>
			<td>3</td>
			<td>4-3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΤΙΓΚΡΕΣ</td>
			<td><strong>5</strong></td>
			<td>3</td>
			<td>5-3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΣΑΝΤΟΣ ΛΑΓΚΟΥΝΑ</td>
			<td><strong>5</strong></td>
			<td>3</td>
			<td>2-1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΓΟΥΑΔΑΛΑΧΑΡΑ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>2-1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΤΖΑΓΚΟΥΑΡΕΣ ΤΣΙΑΠΑΣ</td>
			<td><strong>4</strong></td>
			<td>3</td>
			<td>5-6</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΠΟΥΕΜΠΛΑ</td>
			<td><strong>4</strong></td>
			<td>3</td>
			<td>1-4</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΛΕΟΝ</td>
			<td><strong>3</strong></td>
			<td>3</td>
			<td>7-6</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td><span style="color:#FF0000">ΠΟΥΜΑΣ</span></td>
			<td><strong>3</strong></td>
			<td>2</td>
			<td>3-2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΠΑΤΣΟΥΚΑ</td>
			<td><strong>3</strong></td>
			<td>3</td>
			<td>1-3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΚΡΟΥΖ ΑΖΟΥΛ</td>
			<td><strong>2</strong></td>
			<td>3</td>
			<td>1-2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΒΕΡΑΚΡΟΥΖ</td>
			<td><strong>2</strong></td>
			<td>3</td>
			<td>0-1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td><span style="color:#FF0000">ΤΟΛΟΥΚΑ</span></td>
			<td><strong>1</strong></td>
			<td>2</td>
			<td>1-2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΤΙΧΟΥΑΝΑ</td>
			<td><strong>1</strong></td>
			<td>3</td>
			<td>2-4</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>17</strong></td>
			<td>ΜΟΝΑΡΚΑΣ</td>
			<td><strong>1</strong></td>
			<td>3</td>
			<td>0-6</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>18</strong></td>
			<td>ΛΕΟΝΕΣ ΝΕΓΚΡΟΣ</td>
			<td><strong>0</strong></td>
			<td>2</td>
			<td>1-4<br />
			&nbsp;</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πρωτάθλημα Χιλής', '1407081009', 'images.jpeg', '<p><span style="color:#FF0000">251. ΝΤΕΠΟΡΤΕΣ ΙΚΙΚΕ – ΚΟΜΠΡΕΣΑΛ (22:30) </span>Από τον Απρίλιο έχει μα κερδίσει σε επίσημο αγώα η Ικίκε και δεν βρισκεται στη καλύτερή της κατάσταση ενώ με την απουσία του επιθετικού της δύσκολα θα έρθει ο άσσος.Ηττήθηε εντός έδρας τη προηγούμενη αγωνιστική και σε κανένα σημείο του παιχνιδίου δεν έδειξε να έχει τη δυνατότητα να γυρίσει το ματς. <span style="color:#0000FF">ΕΚΤΊΜΗΣΗ Χ . </span><span style="color:#FF0000">252. ΟΥΑΤΣΙΠΑΤΟ – ΚΟΛΟ ΚΟΛΟ (22:30) </span>Με την προιστορία κατά της αλλα με σταθερότητα στο παιχνίδι της και καλή αμυντική λειτουργία η Ουτσίπατο παρουσιάζει καλή εικόνα στην αρχή του πρωταθλήματος και με τη ψυχολογία υπέρ της έχει την ευκαιρια για τη νίκη.<span style="color:#0000FF">ΕΚΤΊΜΗΣΗ ΑΣΣΟΣ .</span><span style="color:#FF0000">&nbsp;257.&nbsp;ΑΟΥΝΤΑΞ ΙΤΑΛΙΑΝΟ – ΜΠΑΡΝΕΤΣΕΑ (01:00) </span>Μεγάλη διαφορα ποιότητας των δύο ομάδων<span style="color:#FF0000"> &nbsp;</span><span style="color:#0000FF">ΕΚΤΙΜΗΣΗ &nbsp;Η/Τ 1/1&nbsp;</span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:100%">
	<tbody>
		<tr>
		</tr>
		<tr>
			<td colspan="6"><span style="font-size:14px"><strong>ΧΙΛΗ : ΑΠΕΡΤΟΥΡΑ</strong></span></td>
		</tr>
		<tr>
			<td colspan="2"><span style="font-size:14px"><strong>ΟΜΑΔΑ</strong></span></td>
			<td><span style="font-size:14px"><strong>Β</strong></span></td>
			<td><span style="font-size:14px"><strong>ΑΓ</strong></span></td>
			<td><span style="font-size:14px"><strong>ΓΚΟΛ</strong></span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>1</strong></span></td>
			<td><span style="font-size:14px">ΟΥΝ. ΤΣΙΛΕ</span></td>
			<td><span style="font-size:14px"><strong>9</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">9-4</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>2</strong></span></td>
			<td><span style="font-size:14px">ΟΥΝΙΟΝ ΛΑ ΚΑΛΕΡΑ</span></td>
			<td><span style="font-size:14px"><strong>6</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">7-3</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>3</strong></span></td>
			<td><span style="font-size:14px">ΟΥΝ. ΚΑΤΟΛΙΚΑ</span></td>
			<td><span style="font-size:14px"><strong>6</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">6-2</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>4</strong></span></td>
			<td><span style="font-size:14px">ΟΥΑΤΣΙΠΑΤΟ</span></td>
			<td><span style="font-size:14px"><strong>6</strong></span></td>
			<td><span style="font-size:14px">2</span></td>
			<td><span style="font-size:14px">4-0</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>5</strong></span></td>
			<td><span style="font-size:14px">ΣΑΝΤΙΑΓΚΟ ΓΟΥΟΝΤΕΡΕΡΣ</span></td>
			<td><span style="font-size:14px"><strong>6</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">7-4</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>6</strong></span></td>
			<td><span style="font-size:14px">ΟΥΝΙΟΝ ΕΣΠΑΝΙΟΛΑ</span></td>
			<td><span style="font-size:14px"><strong>6</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">3-2</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>7</strong></span></td>
			<td><span style="font-size:14px">ΚΟΛΟ ΚΟΛΟ</span></td>
			<td><span style="font-size:14px"><strong>4</strong></span></td>
			<td><span style="font-size:14px">2</span></td>
			<td><span style="font-size:14px">3-1</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>8</strong></span></td>
			<td><span style="font-size:14px">ΠΑΛΕΣΤΙΝΟ</span></td>
			<td><span style="font-size:14px"><strong>4</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">4-4</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>9</strong></span></td>
			<td><span style="font-size:14px">ΑΡΙΚΑ</span></td>
			<td><span style="font-size:14px"><strong>4</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">4-4</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>10</strong></span></td>
			<td><span style="font-size:14px">Ο ΧΙΓΚΙΝΣ</span></td>
			<td><span style="font-size:14px"><strong>4</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">5-6</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>11</strong></span></td>
			<td><span style="font-size:14px">ΝΙΟΥΜΠΛΕΝΣΕ</span></td>
			<td><span style="font-size:14px"><strong>4</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">4-6</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>12</strong></span></td>
			<td><span style="font-size:14px">ΚΟΜΠΡΕΛΟΑ</span></td>
			<td><span style="font-size:14px"><strong>3</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">4-8</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>13</strong></span></td>
			<td><span style="font-size:14px">ΟΥΝ. ΚΟΝΣΕΠΣΙΟΝ</span></td>
			<td><span style="font-size:14px"><strong>2</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">3-4</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>14</strong></span></td>
			<td><span style="font-size:14px">ΑΟΥΝΤΑΞ ΙΤΑΛΙΑΝΟ</span></td>
			<td><span style="font-size:14px"><strong>1</strong></span></td>
			<td><span style="font-size:14px">2</span></td>
			<td><span style="font-size:14px">0-1</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>15</strong></span></td>
			<td><span style="font-size:14px">ΙΚΙΚΕ</span></td>
			<td><span style="font-size:14px"><strong>1</strong></span></td>
			<td><span style="font-size:14px">2</span></td>
			<td><span style="font-size:14px">1-3</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>16</strong></span></td>
			<td><span style="font-size:14px">ΑΝΤΟΦΑΓΑΣΤΑ</span></td>
			<td><span style="font-size:14px"><strong>1</strong></span></td>
			<td><span style="font-size:14px">3</span></td>
			<td><span style="font-size:14px">1-4</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>17</strong></span></td>
			<td><span style="font-size:14px">ΚΟΜΠΡΕΣΑΛ</span></td>
			<td><span style="font-size:14px"><strong>0</strong></span></td>
			<td><span style="font-size:14px">2</span></td>
			<td><span style="font-size:14px">1-4</span></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-size:14px"><strong>18</strong></span></td>
			<td><span style="font-size:14px">ΜΠΑΡΝΕΤΣΕΑ</span></td>
			<td><span style="font-size:14px"><strong>0</strong></span></td>
			<td><span style="font-size:14px">2</span></td>
			<td><span style="font-size:14px">0-6</span><br />
			&nbsp;</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('268. ΚΑΙΖΕΡΣΛΑΟΥΤΕΡΝ-ΜΟΝΑΧΟ 1860', '1407167396', 'germany_flag.jpg', '<p><span style="font-size:16px">Αμφότερες ομάδες κάθε χρόνο στοχευουν στην άνοδο χωρις να τα έχουν καταφέρει&nbsp; καταλαμβάνοτας τη 4 5 θέση του βαυμολογικού πίνακα.Η Καιζερλασουτερν πέρυσι αγωνίστηκε στα μπαράζ&nbsp; για την άνοδο και φέτος δινεται ως το μεγάλο φαβορί.Η τιμή του άσσου ωστόσο στοιχιματικά δεν προσε΄φερετια για ρισκο αντιθετως το να πάρει βαθμό η Μοναχο 1860 πληρώνει. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ&nbsp; Χ2</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<table border="0" cellpadding="3" cellspacing="0" style="height:580px; width:592px">
	<tbody>
		<tr>
			<td colspan="6"><strong>ΓΕΡΜΑΝΙΑ : ΜΠΟΥΝΤΕΣΛΙΓΚΑ II</strong></td>
		</tr>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΧΑΪΝΤΕΝΧΑΙΜ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>2-1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΝΤΑΡΜΣΤΑΝΤ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1-0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΝΥΡΕΜΒΕΡΓΗ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1-0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΜΠΡΑΟΥΝΣΒΑΪΓΚ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>2-2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΦΟΡΤΟΥΝΑ ΝΤΙΣΕΛΝΤ.</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>2-2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΜΠΟΧΟΥΜ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>1-1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΓΚΡΟΪΤΕΡ ΦΙΡΤ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>1-1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΙΝΓΚΟΛΣΤΑΝΤ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>1-1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΣΑΝ ΠΑΟΥΛΙ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>1-1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΑΑΛΕΝ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0-0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΚΑΡΛΣΡΟΥΗ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0-0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΛΕΙΨΙΑ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0-0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΟΥΝΙΟΝ ΒΕΡΟΛΙΝΟΥ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0-0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td><span style="color:#FF0000">ΜΟΝΑΧΟ 1860</span></td>
			<td><strong>0</strong></td>
			<td>0</td>
			<td>0-0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td><span style="color:#FF0000">ΚΑΪΖΕΡΣΛΑΟΥΤΕΡΝ</span></td>
			<td><strong>0</strong></td>
			<td>0</td>
			<td>0-0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΦΣΒ ΦΡΑΝΚΦΟΥΡΤΗΣ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>1-2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>17</strong></td>
			<td>ΑΟΥΕ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0-1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>18</strong></td>
			<td>ΣΑΝΤΧΑΟΥΖΕΝ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0-1</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά Τσάμπιονς Λίγκ - Επαναληπτικοί ', '1407230685', 'αρχείο λήψης.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">100. ΜΠΑΤΕ ΜΠΟΡΙΣΟΦ- ΝΤΕΜΠΡΕΤΣΕΝ (20.30)&nbsp;</span>Το 1-0 του πρώτου αγώνα θα προσπαθήσει να εκμεταλευτεί η Ντέμπρετσεν έχοντας προβάδισμα για τη πρόκριση.Χωρις ωστόσο μεγάλη η διαφορά ποιότητας των δύο ομάδων με την Μπάτε να μετρά΄και μία απουσία αυτή του μέσου Μίχελιτς ενώ στο πρωτάθλημα της χώρας της ηττήθηκε από την ΜΤΚ.Κρίσιμο το ματς δύσκολα να γίνει ανοιχτό παιχνίδι.<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ UNDER. </span><span style="color:#FF0000">101. ΜΑΚΑΜΠΙ Τ.Α - ΜΑΡΙΜΠΟΡ (21.00) &nbsp;</span>Το ματς διεξάγεται στη Κύπρο λόγων των πολεμικών συγκρούσεων στη Γάζα. Η Μακαμπι είχε ηητηθέι στο πρώτο μάτς με 1-0 στο τελευταίο λεπτό αλλα υπερέχει σε ποιότητα και έιναι ικανή να νατρέψει το εις βάρος τη 1-0 .Η μάριμπορ μετρά 4 νίκες και 1 ισοπαλία σε &nbsp;επίσημες αναμετρήσεις.<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ.&nbsp;</span><span style="color:#FF0000">102. ΠΑΝΑΘΗΝΑΙΚΟΣ- ΣΤΑΝΤΑΡ ΛΙΕΓΗΣ (21.00)&nbsp;</span>Με σύμμαχο την έδρα και το καμίνι που θα διμιουργήσουν οι φίλαθλοι του Παναθηναικού έχει τη πρόκριση στα χέρια του .Η Στανταρ Λιέγης το σαββατοκυριακο που πέρασε αν και αγωνίστηε με πολλές&nbsp;&nbsp;αλλαγές να προφυλάξει παίχτες πήρε το διπλό με την Κορτραικ.Ενίσχύθηκε με τον φορ Γουατ.<span style="color:#0000FF">ΕΚΤΙΜΗΣΗ UNDER &nbsp;και ΑΣΣΟΣ </span><span style="color:#FF0000">103.&nbsp;ΛΙΛ- ΓΚΡΑΣΧΟΠΕΡΣ (21.30)&nbsp;</span>Φαβορί για τη πρόκριση η Λιλ μετά το 2-0 του πρώτου αγώνα.Σωστη διαχείριση του &nbsp;πρώτου αγώνα πάγωνε ρυθμό και &nbsp;έβγαινε στην αντεπίθεση .Δεν έχεο λόγο να επιτεθεί σε ξέφρενο ρυθό σήμερα ενώ η αμυντική της λειτουργία παουσιάζει σταθερότητα<span style="color:#0000FF">. ΕΚΤΙΜΗΣΗ UNDER&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Στή Κύπρο το  Μακάμπι -Μάριμπορ ', '1407230840', 'αρχείο λήψης.jpg', '<p><span style="color:#FF0000"><span style="font-size:14px">Στο ουδέτερο γήπεδο Ντώνης Παπαδοπουλος θα διεξαχθεί ο &nbsp;αγώνας λόγω των συγκρούσεων ση Γάζα.</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Τι ισχύει για τη Πρόκριση ..', '1407231200', '723B236E60581CC2F912DAE2FC7864FC.jpg', '<p><span style="font-size:18px">Επαναληπτικοί για το τρίτο Προκριματικό γύρο. Ισχύει ο κανόνας του εκτός έδρας γκόλ .Σε περιπτωση ομοίο αποτέλεσμα με το πρώτο μάτς ακολουθέι παραταση και αν χρειστεί πέναλτι.Οι νικητές των ζευγαριών θα προκριθούν στους ομίλους της διοργάνωσης και οι ηττήμενοι στα πλέι οφ του Γιουρόπα Λιγκ .</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ο Πιγκουίνος στο Τσάμπιονς Λίγκ ', '1407231455', 'αρχείο λήψης.jpg', '<p><span style="color:#FF0000">100</span><span style="color:#40E0D0">.</span> ΜΠΑΤΕ ΜΠΟΡΙΣΟΦ- ΝΤΕΜΠΡΕΤΣΕΝ <span style="color:#0000FF">&nbsp;</span><span style="color:#DAA520">ΑΣΣΟΣ</span></p>

<p><span style="color:#FF0000">101.</span> ΜΑΚΑΜΠΙ-ΜΑΡΙΜΠΌΡ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style="color:#DAA520">ΑΣΣΟΣ</span></p>

<p><span style="color:#FF0000">102</span>. ΠΑΝΑΘΗΝΑΙΚΟΣ- ΣΤΑΝΤΑΡ &nbsp; &nbsp; &nbsp;<span style="color:#DAA520">UNDER&nbsp;</span></p>

<p><span style="color:#FF0000">103</span>. ΛΙΛ- ΓΚΡΑΣΧΟΠΕΡΣ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style="color:#DAA520">ΑΣΣΟΣ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Επαναληπτικοί Τσάμπιονς Λίγκ...Προτάσεις', '1407318697', 'images.jpg', '<p><span style="color:#FF0000">109</span>. ΖΕΝΙΤ-ΑΕ ΛΕΜΕΣΟΥ (19.00)<span style="color:#DAA520"> OVER</span></p>

<p><span style="color:#FF0000">110.</span> ΑΠΟΕΛ- ΕΛΣΝΙΚΙ (19.30) &nbsp; <span style="color:#DAA520">ΗΜΙΧΡΟΝΟ Χ&nbsp;</span></p>

<p><span style="color:#FF0000">111</span>.ΜΑΛΜΕ- ΣΠΑΡΤΑ ΠΡΑΓΑΣ(20.00) <span style="color:#DAA520">ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">112. </span>ΣΕΡΟΦ ΣΛΟΒΑΝ ΜΠΡΑΤ (20.00) &nbsp;<span style="color:#DAA520">Χ2&nbsp;</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('109. ΖΕΝΙΤ- ΑΕ ΛΕΜΕΣΟΥ ', '1407319052', 'images.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">Χωρίς αξία ο άσσος ...</span></span></p>

<p><span style="font-size:16px">Με φούλ επίθεση από το πρώτο λεπτό και &nbsp;πίεση θα προσπαθήσει νωρίς να γυρίσει το 1-0 του πρωτου αγώνα η Ζενίτ .Αν θυμιθούμε το πρώτο αγώνα η Ζενίτ κυριαρχούσε στο γήπεδο με 22 τελικές και 65 % κατοχή, Με ρυθμό το μάτς μιας και οι ρώσοι θα επιτεθούν από το πρώτο γκολ. Θα παλέψουμε για τη πρόκριση δήλωσε ο προπονητής της ΑΕ Λεμμεσού .<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ OVER&nbsp;</span></span></p>

<p>&nbsp;</p>

<p><span style="color:#DAA520"><font size="3"><span style="line-height:25.600000381469727px">EXTRA TIP </span></font></span><font size="3"><span style="line-height:25.600000381469727px">Χωρίς νίκη απέναντι σε Κυπριακές ομ΄''αδες η Ζεντί που μετρά 2 ήττες 1 ισοπαλία&nbsp;</span></font></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Πιγκουίνου για σίγουρο χρήμα...', '1407319278', 'αρχείο λήψης.jpg', '<p><span style="color:#FF0000">115. </span>ΚΟΠΕΓΧΑΓΗ- ΝΤΝΙΕΠΡ (21.00) &nbsp;<span style="color:#DAA520">GOAL GOAL&nbsp;</span></p>

<p><span style="color:#FF0000">116.</span> ΣΑΛΤΣΜΟΥΡΓΚ- ΚΑΡΑΜΠΑΓΚ (21.30) <span style="color:#DAA520">&nbsp;2-3 GOAL&nbsp;</span></p>

<p><span style="color:#FF0000">119</span>. ΣΕΛΤΙΚ- ΛΕΓΚΙΑ(21.45) <span style="color:#DAA520">&nbsp;OVER&nbsp;</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('113. ΜΠΕΣΙΚΤΑΣ- ΦΕΓΕΝΟΡΝΤ (20.30) ', '1407319583', 'images.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">Μυρίζει γκολ....</span></span></p>

<p><span style="font-size:16px">Σπουδαία &nbsp;εκτός έδρας για τη Μπεσίκτας στο πρώτο αγώνα που αυτομάτος τη βάζει στη θέση του &nbsp;φαωβορί για τη πρόκριση.Αναγκασμένη να ψάξει το γκόλ η Φέγενορντ η οποία πληρώνει τους παίχτες που αποχώρησαν .Δε θα κλειστέι στα καρέ της η Μπεσίκτας με το κόσμο στο πλευρό της .<span style="color:#0000FF">ΕΚΤΙΜΗΣΗ GOAL GOAL&nbsp;&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('119. ΣΕΛΤΙΚ- ΛΕΓΚΙΑ ΒΑΡ (21.45)', '1407319869', 'images.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">Αλλαγή έδρας...</span></span></p>

<p><span style="font-size:16px"><span style="color:#2F4F4F">Στο Εδιμβόυργο θα αγωνιστεί η Σέλτικ και όχι στη φυσική της έδρα .Απογοητέυουν μέχρι τώρα οι Σκωτσέζοι τόσο στα φιλικά ( 6-1 από τη Τότεναμ) όσο και στα επίσημα.Με τη μέγιστη καλή ψυχολογία η Λέγκια θα προσπαθήσει να κρατήσει το 4-1 .Με επιθετικό σχήμα η Σέλτικ για την Ανατροπή . </span><span style="color:#0000FF">ΕΚΤΙΜΗΣΗ OVER&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('122. ΕΡΜΗΣ ΑΡΔ- ΓΙΟΥΝΓΚ ΜΠΟΙΣ (17.00) ', '1407405368', 'EUROPA-LEAGUE-.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">Θα το παλέψει...</span></span></p>

<p><span style="font-size:16px">Δέυτερη Ευρωπαική εμπειρία για τον Ερμή στην ιστορία του. Στο πρώτο μάτς στην Ελβετία ήρθε δίκαια η νίκη με 1-0 για τους Ελβετούς με τον Ερμή σε κανένα σημείο του αγώνα να δείχνει ότι μπορεί να διεκδηκήσει κάτι καλύτερο .Επιθετικά αναμένεται να ξεκινήσει το μάτσς ο Ερμής απέναντι σε μία ομάδα με αρκετά νέαρούς παίχτες . <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 1Χ&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά Europa League', '1407405866', 'αρχείο λήψης.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">123. ΕΣΜΠΙΕΡΓΚ- ΡΟΥΧ ΧΟΡΖΟΦ</span> (19.00) Μετ΄την ισοπαλία 0-0 στην Πολωνία αμφότερες ομάδες θα παραταχθούν στο αγωνιστικό χώρο με αμυντικούς προσανατολισμούς και θα επιδιωξουν με μισό γκόλ να πάρουν την πρόκριση<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ UNDER</span> <span style="color:#FF0000">.124. ΛΙΜΠΕΡΕΤΣ ΑΣΤΡΑ ΠΛΟΕΣΤΙ</span> (19.00) Με χατ τρικ του νιγηριανού άσσου της Αστρα ηρθε το 3-0 στη Ρουμανία .Αναγκασμένη να ψάξει το γκόλ η Λίμπερετσς που επιθετικά δεν εχει δείξει κατι το ιδαιτερο ενώ και αμυντικά δεν έχει σταθερότητα. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ &nbsp;ΗΜ Χ</span> <span style="color:#FF0000">125. &nbsp;ΜΟΛΝΤΕ-ΖΟΡΙΑ</span> (19.00) <span style="color:#0000FF">ΑΣΣΟΣ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Europa League', '1407406087', 'EUROPA-LEAGUE-.jpg', '<p><span style="color:#FF0000">126.</span> ΤΣΕΡΝΟΜΟΡΕΤΣ- ΣΠΛΙΝΤ ( 19.00) &nbsp;<span style="color:#0000FF">2-3 ΓΚΟΛ&nbsp;</span></p>

<p><span style="color:#FF0000">127</span>.ΑΙΚ ΣΤΟΚΧΟΛΜΗΣ- ΑΣΤΑΝΑ(20.00) <span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">130.</span>ΣΑΚΙΡ-ΝΕΦΣΤΚΙ (20.00) <span style="color:#0000FF">ΓΚΟΛ</span>&nbsp;</p>

<p><span style="color:#FF0000">131</span>.ΣΟΛΙΓΚΟΡΣΚ - ΖΟΥΛΤΕ ΒΑΡΕΓΚΕΜ(20.00) &nbsp;<span style="color:#0000FF">2</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ο Πιγκουίνος....', '1407406474', 'αρχείο λήψης (1).jpg', '<p><span style="color:#FF0000">134</span>.ΚΛΟΥΖ-ΝΤΙΝΑΜΟ ΜΙΝΣΚ (20.30) <span style="color:#0000FF">2-3 ΓΚΟΛ&nbsp;</span></p>

<p><span style="color:#FF0000">136.</span> ΧΑΙΝΤΟΥΚ-ΣΑΧΤΙΟΡ (20.30)<span style="color:#0000FF"> OVER</span>&nbsp;</p>

<p><span style="color:#FF0000">139</span>. ΜΠΡΟΝΤΜΠΙ- &nbsp;ΚΛΑΜΠ ΜΠΡΙΖ (21.00) <span style="color:#0000FF">OVER</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('137. ΑΤΡΟΜΗΤΟΣ- ΣΑΡΑΓΙΕΒΟ (21.00)', '1407406798', 'αρχείο λήψης.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">Παίρνει το εισητήριο....</span></span></p>

<p><span style="font-size:16px">Μετά τη νίκη στο καυτό Σαραγιεβο ο Ατρόμητος θέλει να σφραγίσει τη πρόκριση.Απών ο Ουμπιντες.Παίζοντας απλό συντηρητικό ποδόσφαιρο θα πάρει το αποτέλσμα που θέλει&nbsp;<span style="color:#0000FF">ΕΚΤΙΜΗΣΗ UNDER</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('140.ΑΣΤΕΡΑΣ ΤΡΙΠΟΛΗΣ- ΜΑΙΝΤΖ', '1407407041', 'EUROPA-LEAGUE-.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">Οτι του βγεί....</span></span><br />
&nbsp;</p>

<p>Όλα για όλα για τον Αστέρα με στόχο να ανατρέψει το εις βάρος &nbsp;του 1-0 , αποτέλεσμα που ήρθε ωστόσο μετά από μία εξαιρετική εμφάνιση των Αρκαδων στη Γερμανία.<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ ΗΜ Χ&nbsp;</span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ά  Ρωσίας ', '1407485343', 'rwsia.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">100. ΑΜΚΑΡ-ΟΥΦΑ (17.00)</span> Με ποιότητα και εμπερία η Αμκαρ υποδέχεται στην έδρα της την νεοφώτιστη Ούφα που στο ντεμπόυτο της στην πρέμιερ ηητήθηκε 2-0 από την Κουμπαν παρουσιαζόντας αμυντικές δυσλειτουργίες.Πίο έτοιμη η Ακμαρ .<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ. </span>1<span style="color:#FF0000">05. ΚΟΥΜΠΑΝ-ΡΟΣΤΟΦ (19.30)</span> Η Ροστόφ ακόμα δεν έχει συνέλεθει από την ήττα με 7-3 της πρεμίερας από τη Ντιναμό Μόσχας. Με πολλά κενα στην άμυνα &nbsp;παρουσιάστηκε ασταθής αντιθετως η Κουμπαν έυκολα πήρε τη νίκη με 2-0 επί της Ούφα .Χώρις ήττα η Κουμπαν στις μεταξύ τους αναμετρήσεις.<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ Η/T 1/1</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<table border="0" cellpadding="0" cellspacing="0" style="background-color:rgb(238, 219, 142); color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td>
			<table border="0" cellpadding="3" cellspacing="0" style="width:615px">
				<tbody>
					<tr>
						<td colspan="3">&nbsp;</td>
						<td colspan="5" style="border-color:rgb(217, 217, 217)">ΣΥΝΟΛΟ</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
						<td><strong>Β</strong></td>
						<td><strong>ΑΓ</strong></td>
						<td><strong>Ν</strong></td>
						<td><strong>Ι</strong></td>
						<td><strong>Η</strong></td>
						<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>1</strong></td>
						<td>ΝΤΙΝΑΜΟ ΜΟΣΧΑΣ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">7 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>2</strong></td>
						<td>ΣΠΑΡΤΑΚ ΜΟΣΧΑΣ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>3</strong></td>
						<td>ΤΕΡΕΚ ΓΚΡΟΖΝΥ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>4</strong></td>
						<td>ΖΕΝΙΤ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>5</strong></td>
						<td>ΤΣΣΚΑ ΜΟΣΧΑΣ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>6</strong></td>
						<td>ΚΟΥΜΠΑΝ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>7</strong></td>
						<td>Μ. ΣΑΡΑΝΣΚ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>8</strong></td>
						<td>ΚΡΑΣΝΟΝΤΑΡ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>9</strong></td>
						<td>ΛΟΚΟΜΟΤΙΒ ΜΟΣΧΑΣ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>10</strong></td>
						<td>ΟΥΡΑΛ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>11</strong></td>
						<td>ΟΥΦΑ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>12</strong></td>
						<td>ΤΟΡΠΕΝΤΟ ΜΟΣΧΑΣ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>13</strong></td>
						<td>ΑΜΚΑΡ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>14</strong></td>
						<td>ΑΡΣΕΝΑΛ ΤΟΥΛΑ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>15</strong></td>
						<td>ΡΟΣΤΟΦ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 7</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>16</strong></td>
						<td>ΡΟΥΜΠΙΝ ΚΑΖΑΝ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 4</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('''Β ΣΟΥΗΔΙΑΣ ', '1407485891', 'Σουηδία.png', '<p><span style="font-size:16px"><span style="color:#FF0000">101. ΣΙΡΙΟΥΣ- ΝΤΕΓΚΕΡΦΟΡΣ(19.20)</span> Επιθετικές ομάδες &nbsp;κυνηγουν γκόλ με τα περισσότερα μάτς στο over.Με ενατροπή πήρε τη νίκη η Σίρίους τη πρηγούμενη αγωνιστική &nbsp;εώ η Ντεγκεφορντ ηττήτηκε από τη πολύ καλυτερή της Χάμαρμπι. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ GOAL GOAL</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>΄Β ΣΟΥΗΔΙΑΣ&nbsp;</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
		</tr>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΧΑΜΑΡΜΠΙ</td>
			<td><strong>36</strong></td>
			<td>18</td>
			<td>11</td>
			<td>3</td>
			<td>4</td>
			<td style="border-color:rgb(217, 217, 217)">39 - 18</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΛΙΟΥΝΓΚΣΚΙΛΕ</td>
			<td><strong>36</strong></td>
			<td>18</td>
			<td>10</td>
			<td>6</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">38 - 18</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΣΟΥΝΤΣΒΑΛ</td>
			<td><strong>34</strong></td>
			<td>18</td>
			<td>11</td>
			<td>1</td>
			<td>6</td>
			<td style="border-color:rgb(217, 217, 217)">34 - 21</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΕΣΤΕΡΣΟΥΝΤ</td>
			<td><strong>29</strong></td>
			<td>18</td>
			<td>8</td>
			<td>5</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">25 - 22</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΓΙΟΝΣΕΠΙΝΓΚ</td>
			<td><strong>28</strong></td>
			<td>18</td>
			<td>9</td>
			<td>1</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">32 - 25</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΣΙΡΙΟΥΣ</td>
			<td><strong>27</strong></td>
			<td>18</td>
			<td>7</td>
			<td>6</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">30 - 23</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΒΑΡΜΠΕΡΓΚΣ</td>
			<td><strong>27</strong></td>
			<td>18</td>
			<td>7</td>
			<td>6</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">21 - 23</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΣΥΡΙΑΝΣΚΑ</td>
			<td><strong>26</strong></td>
			<td>18</td>
			<td>8</td>
			<td>2</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">27 - 32</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΒΑΡΝΑΜΟ</td>
			<td><strong>24</strong></td>
			<td>18</td>
			<td>6</td>
			<td>6</td>
			<td>6</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 28</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΑΝΓΚΕΛΧΟΛΜΣ</td>
			<td><strong>22</strong></td>
			<td>18</td>
			<td>6</td>
			<td>4</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">21 - 31</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΕΣΤΕΡ</td>
			<td><strong>21</strong></td>
			<td>18</td>
			<td>5</td>
			<td>6</td>
			<td>7</td>
			<td style="border-color:rgb(217, 217, 217)">24 - 25</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΝΤΕΓΚΕΡΦΟΡΣ</td>
			<td><strong>20</strong></td>
			<td>18</td>
			<td>5</td>
			<td>5</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">25 - 31</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΛΑΝΤΣΚΡΟΝΑ</td>
			<td><strong>18</strong></td>
			<td>18</td>
			<td>5</td>
			<td>3</td>
			<td>10</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 35</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΧΟΥΣΚΒΑΡΝΑ</td>
			<td><strong>18</strong></td>
			<td>18</td>
			<td>5</td>
			<td>3</td>
			<td>10</td>
			<td style="border-color:rgb(217, 217, 217)">18 - 29</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td>ΓΚΑΪΣ</td>
			<td><strong>16</strong></td>
			<td>18</td>
			<td>4</td>
			<td>4</td>
			<td>10</td>
			<td style="border-color:rgb(217, 217, 217)">16 - 27</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΑΣΙΡΙΣΚΑ</td>
			<td><strong>16</strong></td>
			<td>18</td>
			<td>3</td>
			<td>7</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">15 - 29<br />
			&nbsp;</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Β΄ ΓΕΡΜΑΝΙΑΣ ', '1407486697', 'germany_flag.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">102. ΑΑΛΕΝ- ΣΑΝ ΠΑΟΥΛΙ (19.30)</span> Με οδηγό την άμυνα και συντηρητικό παιχνίδι αναδείχθηκαν ισόπαλες με τις αντιπαλους της οι δύο ομάδες τη πρώτη αγωνιστική .Και σήμερα περιμένουμε να δούμε κλειστές αμυνες και μέτριο παιχνίδι.<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ UNDER .</span><span style="color:#FF0000">103. ΦΣΒ ΦΡΑΝΚΦΟΥΡΤΗΣ-ΚΑΡΛΣΡΟΥΗ (19.30)</span> Με απουσίες η Φρνακφούρτη και προερχόμενη από ήττα στη πρεμίερα δε δείχνει έτοιμη.Σε καλή κατάσταση έδειξε η Καρσλούρη που λόγω ατυχίας έχοντας δύο δοκάρια δεν κέρδιδε την Ουνιον. αξία το διπλό.<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ 2 ή ΗΜ Χ</span> <span style="color:#FF0000">125. ΟΥΝΙΟΝ-ΦΟΡΤΟΥΝΑ &nbsp;ΝΤ (21.30) </span>Δυσαρέστησε το κόσμο της η Ουνιον στην πρεμίερα του πωταθλήματος λόγω κυρίως της άμυνας που παρατάχθηκε στο εντός έδρας αγώνα και από τύχη δε γνώρισε την ήττα.Ενώ το βαθμό της ισοπαλίας πήρε και η Φορτούνα η οποία δεν κατάφερα να εκμεταλευτεί το γεγονός ότι προηγήθηκε δύο φορές στο σκορ. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 2&nbsp;</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;Β΄ΓΕΡΜΑΝΙΑΣ&nbsp;</p>

<table border="0" cellpadding="0" cellspacing="0" style="width:615px">
	<tbody>
		<tr>
			<td>
			<table border="0" cellpadding="3" cellspacing="0" style="width:615px">
				<tbody>
					<tr>
						<td colspan="3">&nbsp;</td>
						<td colspan="5" style="border-color:rgb(217, 217, 217)">ΣΥΝΟΛΟ</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
						<td><strong>Β</strong></td>
						<td><strong>ΑΓ</strong></td>
						<td><strong>Ν</strong></td>
						<td><strong>Ι</strong></td>
						<td><strong>Η</strong></td>
						<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>1</strong></td>
						<td>ΚΑΪΖΕΡΣΛΑΟΥΤΕΡΝ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>2</strong></td>
						<td>ΧΑΪΝΤΕΝΧΑΙΜ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>3</strong></td>
						<td>ΝΤΑΡΜΣΤΑΝΤ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>4</strong></td>
						<td>ΝΥΡΕΜΒΕΡΓΗ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>5</strong></td>
						<td>ΜΠΡΑΟΥΝΣΒΑΪΓΚ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>6</strong></td>
						<td>ΦΟΡΤΟΥΝΑ ΝΤΙΣΕΛΝΤ.</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>7</strong></td>
						<td>ΜΠΟΧΟΥΜ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>8</strong></td>
						<td>ΓΚΡΟΪΤΕΡ ΦΙΡΤ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>9</strong></td>
						<td>ΙΝΓΚΟΛΣΤΑΝΤ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>10</strong></td>
						<td>ΣΑΝ ΠΑΟΥΛΙ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>11</strong></td>
						<td>ΑΑΛΕΝ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>12</strong></td>
						<td>ΚΑΡΛΣΡΟΥΗ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>13</strong></td>
						<td>ΛΕΙΨΙΑ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>14</strong></td>
						<td>ΟΥΝΙΟΝ ΒΕΡΟΛΙΝΟΥ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>15</strong></td>
						<td>ΜΟΝΑΧΟ 1860</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>16</strong></td>
						<td>ΦΣΒ ΦΡΑΝΚΦΟΥΡΤΗΣ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>17</strong></td>
						<td>ΑΟΥΕ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>18</strong></td>
						<td>ΣΑΝΤΧΑΟΥΖΕΝ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 1</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Α΄ ΔΑΝΙΑΣ ', '1407487127', 'DA.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">104. ΡΑΝΤΕΡΣ- ΒΕΣΤΣΑΕΛΑΝΤ (19.30)</span> Αδυναμες στην άμυνα αλλα με επιθετικό ρυθμό αγωνίζονται οι δύο ομάδες .Εξαιρετική η Βεστζελαντ στην εντός ΄δρας ισοπαλία με την Κοπεγχαγη 2-2 που θα μπορούσε ν αέχει πάρει και τη ννίκη. Ηττα για Ραντερς με 3-1 από τη Μίντιλαντ. Ψαχνουν το γκολ . <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 2-3 ΓΚΟΛ</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;ΔΑΝΙΑ&nbsp;</p>

<table border="0" cellpadding="0" cellspacing="0" style="width:615px">
	<tbody>
		<tr>
			<td>
			<table border="0" cellpadding="3" cellspacing="0" style="width:615px">
				<tbody>
					<tr>
						<td colspan="3">&nbsp;</td>
						<td colspan="5" style="border-color:rgb(217, 217, 217)">ΣΥΝΟΛΟ</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
						<td><strong>Β</strong></td>
						<td><strong>ΑΓ</strong></td>
						<td><strong>Ν</strong></td>
						<td><strong>Ι</strong></td>
						<td><strong>Η</strong></td>
						<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>1</strong></td>
						<td>ΜΙΝΤΙΛΑΝΤ</td>
						<td><strong>6</strong></td>
						<td>3</td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">6 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>2</strong></td>
						<td>ΧΟΜΠΡΟ</td>
						<td><strong>6</strong></td>
						<td>3</td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">5 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>3</strong></td>
						<td>ΝΟΡΝΤΖΕΛΑΝΤ</td>
						<td><strong>6</strong></td>
						<td>3</td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">7 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>4</strong></td>
						<td>ΡΑΝΤΕΡΣ</td>
						<td><strong>6</strong></td>
						<td>3</td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>5</strong></td>
						<td>ΑΑΛΜΠΟΡΓΚ</td>
						<td><strong>5</strong></td>
						<td>3</td>
						<td>1</td>
						<td>2</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>6</strong></td>
						<td>ΣΟΝΤΕΡΙΣΚΕ</td>
						<td><strong>5</strong></td>
						<td>3</td>
						<td>1</td>
						<td>2</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>7</strong></td>
						<td>ΚΟΠΕΓΧΑΓΗ</td>
						<td><strong>5</strong></td>
						<td>3</td>
						<td>1</td>
						<td>2</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>8</strong></td>
						<td>ΒΕΣΤΣΑΕΛΑΝΤ</td>
						<td><strong>4</strong></td>
						<td>3</td>
						<td>1</td>
						<td>1</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">7 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>9</strong></td>
						<td>ΜΠΡΟΝΤΜΠΙ</td>
						<td><strong>3</strong></td>
						<td>3</td>
						<td>1</td>
						<td>0</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 5</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>10</strong></td>
						<td>ΕΣΜΠΙΕΡΓΚ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 5</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>11</strong></td>
						<td>ΟΝΤΕΝΣΕ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>12</strong></td>
						<td>ΣΙΛΚΕΜΠΟΡΓΚ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 4</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ά ΝΟΡΒΗΓΙΑΣ ', '1407487590', 'norway-flag-1.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">106. ΜΠΡΑΝ-ΑΑΛΕΣΟΥΝΤ ( 20.00)</span> Τελευταία ευκαιρία&nbsp;για την Μπράν να σωθεί .Ανασα για την Ααλεσουντ μετά τη νίκη 2-1 &nbsp;επί της Μπόντο. Όλα γι αόλα η Μπραν .<span style="color:#0000FF">ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>Α΄ΝΟΡΒΗΓΙΑΣ</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΜΟΛΝΤΕ</td>
			<td><strong>43</strong></td>
			<td>18</td>
			<td>13</td>
			<td>4</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">39 - 14</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΟΝΤ</td>
			<td><strong>35</strong></td>
			<td>18</td>
			<td>10</td>
			<td>5</td>
			<td>3</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 16</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΣΤΡΟΜΣΓΚΟΝΤΣΕΤ</td>
			<td><strong>34</strong></td>
			<td>18</td>
			<td>10</td>
			<td>4</td>
			<td>4</td>
			<td style="border-color:rgb(217, 217, 217)">29 - 21</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΒΑΛΕΡΕΝΓΚΑ</td>
			<td><strong>31</strong></td>
			<td>18</td>
			<td>8</td>
			<td>7</td>
			<td>3</td>
			<td style="border-color:rgb(217, 217, 217)">38 - 27</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΡΟΖΕΝΜΠΟΡΓΚ</td>
			<td><strong>30</strong></td>
			<td>18</td>
			<td>8</td>
			<td>6</td>
			<td>4</td>
			<td style="border-color:rgb(217, 217, 217)">36 - 30</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΛΙΛΕΣΤΡΟΜ</td>
			<td><strong>27</strong></td>
			<td>18</td>
			<td>7</td>
			<td>6</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">29 - 21</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΒΙΚΙΝΓΚ</td>
			<td><strong>27</strong></td>
			<td>18</td>
			<td>6</td>
			<td>9</td>
			<td>3</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 20</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΣΑΡΠΣΜΠΟΡΓΚ 08</td>
			<td><strong>24</strong></td>
			<td>18</td>
			<td>6</td>
			<td>6</td>
			<td>6</td>
			<td style="border-color:rgb(217, 217, 217)">25 - 31</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΣΤΑΡΤ</td>
			<td><strong>22</strong></td>
			<td>18</td>
			<td>6</td>
			<td>4</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 33</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΣΤΑΜΠΑΕΚ</td>
			<td><strong>22</strong></td>
			<td>18</td>
			<td>7</td>
			<td>1</td>
			<td>10</td>
			<td style="border-color:rgb(217, 217, 217)">27 - 35</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΧΑΟΥΓΚΕΣΟΥΝΤ</td>
			<td><strong>20</strong></td>
			<td>18</td>
			<td>5</td>
			<td>5</td>
			<td>7</td>
			<td style="border-color:rgb(217, 217, 217)">27 - 26</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΣΟΓΚΝΤΑΛ</td>
			<td><strong>20</strong></td>
			<td>18</td>
			<td>5</td>
			<td>5</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">19 - 27</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΑΑΛΕΣΟΥΝΤ</td>
			<td><strong>18</strong></td>
			<td>18</td>
			<td>4</td>
			<td>6</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">19 - 23</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΜΠΟΝΤΟ ΓΚΛΙΜΤ</td>
			<td><strong>18</strong></td>
			<td>18</td>
			<td>5</td>
			<td>3</td>
			<td>10</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 34</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td>ΜΠΡΑΝ</td>
			<td><strong>12</strong></td>
			<td>18</td>
			<td>3</td>
			<td>3</td>
			<td>12</td>
			<td style="border-color:rgb(217, 217, 217)">21 - 34</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΣΑΝΤΝΕΣ</td>
			<td><strong>10</strong></td>
			<td>18</td>
			<td>2</td>
			<td>4</td>
			<td>12</td>
			<td style="border-color:rgb(217, 217, 217)">14 - 35</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Β΄ΝΟΡΒΗΓΙΑΣ ', '1407487851', 'norway-flag-1.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">107 . ΣΑΝΤΕΦΙΟΡΝΤ-ΜΠΡΙΝΕ (20.00)</span> Δυσκολέυτηκε η Σντερφιορντ στην έδρα της Στρόμεν και το 1-1που απέσπασε τους ικανοποίησε. Βαθιά βαθμολογική ανάσα πήρε η Μπ΄ρινε αφού μετά από δύο σερί ήττες νίκηε τη Χόνεφος 3-2 με το νικητήριο γκόλ στα τελευτία λεπτά του αγώνα.<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ ΓΚΟΛ</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>ΝΟΡΒΗΓΙΑ Β΄</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
		</tr>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΤΡΟΜΣΟ</td>
			<td><strong>37</strong></td>
			<td>17</td>
			<td>11</td>
			<td>4</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">35 - 12</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΣΑΝΤΕΦΙΟΡΝΤ</td>
			<td><strong>37</strong></td>
			<td>18</td>
			<td>10</td>
			<td>7</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">30 - 14</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΡΑΝΧΑΪΜ</td>
			<td><strong>33</strong></td>
			<td>18</td>
			<td>10</td>
			<td>3</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">29 - 16</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΜΙΟΝΤΑΛΕΝ</td>
			<td><strong>32</strong></td>
			<td>17</td>
			<td>9</td>
			<td>5</td>
			<td>3</td>
			<td style="border-color:rgb(217, 217, 217)">33 - 19</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΚΡΙΣΤΙΑΝΣΟΥΝΤ</td>
			<td><strong>31</strong></td>
			<td>18</td>
			<td>9</td>
			<td>4</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">34 - 24</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΦΡΕΝΤΡΙΚΣΤΑΝΤ</td>
			<td><strong>31</strong></td>
			<td>18</td>
			<td>9</td>
			<td>4</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">25 - 16</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΜΠΑΕΡΟΥΜ</td>
			<td><strong>28</strong></td>
			<td>18</td>
			<td>9</td>
			<td>1</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 37</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΧΟΝΤ</td>
			<td><strong>24</strong></td>
			<td>18</td>
			<td>6</td>
			<td>6</td>
			<td>6</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 25</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΣΤΡΟΜΕΝ</td>
			<td><strong>23</strong></td>
			<td>18</td>
			<td>6</td>
			<td>5</td>
			<td>7</td>
			<td style="border-color:rgb(217, 217, 217)">31 - 31</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΝΕΣΤ ΣΟΤΡΑ</td>
			<td><strong>23</strong></td>
			<td>18</td>
			<td>7</td>
			<td>2</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">29 - 29</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΜΠΡΙΝΕ</td>
			<td><strong>21</strong></td>
			<td>18</td>
			<td>6</td>
			<td>3</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 31</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΤΡΟΜΣΝΤΑΛΕΝ</td>
			<td><strong>20</strong></td>
			<td>18</td>
			<td>5</td>
			<td>5</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">23 - 32</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΑΛΤΑ</td>
			<td><strong>20</strong></td>
			<td>18</td>
			<td>5</td>
			<td>5</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">19 - 28</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΧΟΝΕΦΟΣ</td>
			<td><strong>20</strong></td>
			<td>18</td>
			<td>6</td>
			<td>2</td>
			<td>10</td>
			<td style="border-color:rgb(217, 217, 217)">22 - 35</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td>ΟΥΛΕΝΣΑΚΕΡ</td>
			<td><strong>13</strong></td>
			<td>18</td>
			<td>3</td>
			<td>4</td>
			<td>11</td>
			<td style="border-color:rgb(217, 217, 217)">16 - 28</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΧΑΜ ΚΑΜ</td>
			<td><strong>5</strong></td>
			<td>18</td>
			<td>1</td>
			<td>2</td>
			<td>15</td>
			<td style="border-color:rgb(217, 217, 217)">9 - 36<br />
			&nbsp;</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Β΄  ΓΑΛΛΙΑΣ ', '1407489155', 'GALIA.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">108. ΑΝΖΕ- ΑΡΛ (21.00)</span> Αδύναμη εκτός έδρας η Αρλ, μεγάλη η&nbsp;&nbsp;διαφορά δυναμικότητας και δύσκολα να πάρει θετικό αποτέλεσμα στην έδρα της Ανζέ. Τα τελευταία χρόνια χάνει χωρίς να σκοράρει η Αρλ επι της Ανζε. <span style="color:#DAA520">ΕΚΤΙΜΣΗ ΑΣΣΟΣ</span>. <span style="color:#FF0000">109. ΚΛΕΡΜΟΝ-ΟΣΕΡ (21.00)</span> &nbsp;Με δύο πρόσωπα εμφανίστηκε η Κλερμόν καθώς για 70 λεπτά είχε το ρόλο του αμυνόμενου αλλά στο τελευταίο 20 λεπτο επιτέθηκε και διμιουργησε φάσεις. Καλά τα δείγματα και για την Οσερ με δυνατό σύνολο καλούς παίχτες σε όλες τις γραμμές<span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ Χ &nbsp;ΣΚΟΡ 2-2.</span> <span style="color:#FF0000">110 ΚΡΕΤΕΙΓ-ΣΑΤΟΡΟΥ (21.00)</span> Με ήττα ξεκλινησαν τις υποχρεώσεις τους και οι δύο. φανηκε να χρειαζονται χρόνο και να βρούν &nbsp;πατήματα. πιο αδύναμη παροδοσιακά η σατορού <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ</span>.<span style="color:#FF0000"> 111 ΝΙΟΡ -ΜΠΡΕΣΤ(21.00)</span> Η πρεμίερα έδειξε οτι σκοράρουν αμφοτερες<span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ ΓΚΟΛ 2-3 ΓΚΟΛ</span> .<span style="color:#FF0000">112. ΝΤΙΖΟΝ-ΛΑΒΑΛ (21.00)</span> Με όπλο την έδρα της η Ντιζόν τη περινή σεζόν έκανε 11 από τις συνολικά 14 νίκες &nbsp;μπροστά στο κόσμο της .Στην πρεμιέρα έδειξαν καλά στοιχεία και πήρα &nbsp;βαθμό σε μία δύσκολη έδρα .Προμηνύεται δύσκολη σεζόν για τους φιλοξενούμενους. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ</span> . <span style="color:#FF0000">113 ΟΡΛΕΑΝ-ΝΑΝΣΙ (21.00) </span>Πληρώνει το διπλό , πίο ποιοτική η Νασνί<span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ 2</span> <span style="color:#FF0000">114. ΤΡΟΥΑ-ΤΟΥΡ (21.00)</span> Παροδοσιακά οι αναμετρήσεις μεταξύ τους έρχονατι over .Υποψήφια για άνοδο η Τρουά. σκοράρει η Τουρ.<span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ OVER</span> <span style="color:#FF0000">.115. ΧΑΒΡΗ-ΓΚΑΖΕΛΕΚ (21.00)</span> Μέτρια εμφάνιση για τη Χάβρη στη πρεμίερα θα θελήσει να αλλάξει εικόνα με νίκη επιτ ης Γκαζελεκ η οποία παρουσιάζεται αδύναμη μακρία από την έδρα της. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>Β΄ΓΑΛΛΙΑΣ&nbsp;</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
		</tr>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΤΟΥΡ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">4 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΟΣΕΡ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΓΚΑΖΕΛΕΚ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΝΙΜ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΜΠΡΕΣΤ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΟΡΛΕΑΝ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΤΡΟΥΑ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΝΤΙΖΟΝ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΛΑΒΑΛ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΝΑΝΣΙ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΝΙΟΡ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΑΖΑΞΙΟ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΑΡΛ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΛΟΥΖΕΝΑ</td>
			<td><strong>0</strong></td>
			<td>0</td>
			<td>0</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td>ΑΝΖΕ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΚΛΕΡΜΟΝ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>17</strong></td>
			<td>ΣΑΤΟΡΟΥ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>18</strong></td>
			<td>ΣΟΣΟ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>19</strong></td>
			<td>ΚΡΕΤΕΪΓ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 4</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>20</strong></td>
			<td>ΧΑΒΡΗ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>21</strong></td>
			<td>ΒΑΛΕΝΣΙΕΝ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 2<br />
			&nbsp;</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Έναρξη και στην Όλλανδία Τσβόλε-Ουτρέχτη ', '1407489734', 'OLLANDIA.jpg', '<p><span style="font-size:16px">Εντυπωσιακή η Τσβόλε στο Σουπερ καπ , με το επιβλητικό 5-1 επί τουπρωταθλητή Αγιαξ Ενισχυμένη η ουτρέχτη δείχνει ικανή να πάρει βαθμό ενώ στους στόχους της ομάδας για φέτος είναι να διεκδηκήσει την έξοδο στην Ευρώπη. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ Χ&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Β΄ΟΛΛΑΝΔΙΑΣ ΠΡΟΤΑΣΕΙΣ', '1407490036', 'OLLANDIA.jpg', '<p><span style="color:#FF0000">117. </span>ΑΛΜΕΡΙΕ -ΜΑΑΣΤΡΙΧ(21.00) &nbsp;<span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">118</span>.ΕΜΕΝ-ΝΤΕ ΓΚΡΑΑΦΤΣΑΠ (21.00)&nbsp;<span style="color:#0000FF">&nbsp;2</span>&nbsp;</p>

<p><span style="color:#FF0000">119.</span>ΟΣ-ΦΟΛΕΝΤΑΜ(21.00) <span style="color:#0000FF">2</span></p>

<p><span style="color:#FF0000">120</span>.ΡΟΝΤΑ-ΒΑΑΛΒΙΚ(21.00) <span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">121</span>.ΦΕΝΛΟ-ΓΙΟΝΓΚ ΤΒΕΝΤΕ(21.00) <span style="color:#0000FF">OVER</span></p>

<p><span style="color:#FF0000">122</span>.ΧΕΛΜΟΝΤ- ΦΟΡΤ. ΣΙΤΑΡΝΤ (21.00) <span style="color:#0000FF">ΓΚΟΛ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Βελγιο. Γκενκ -Λόκερεν ', '1407490497', 'GRH.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">Εν αναμονή τεχνικού...</span></span></p>

<p><span style="font-size:16px">Σε αναζήτηση τεχνικού η Γκένκ με επικρατέστερο τον Βερκοτέρεν με τον οποίο &nbsp;πήρε το πρωτάθλημα το 2011.Χώρις λυση στην επίθεση η Λόκερεν με την απουία του Ντούτρα. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ&nbsp;</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>Α΄ΒΕΛΓΙΟΥ</p>

<table border="0" cellpadding="0" cellspacing="0" style="background-color:rgb(238, 219, 142); color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td>
			<table border="0" cellpadding="3" cellspacing="0" style="width:615px">
				<tbody>
					<tr>
						<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
						<td><strong>Β</strong></td>
						<td><strong>ΑΓ</strong></td>
						<td><strong>Ν</strong></td>
						<td><strong>Ι</strong></td>
						<td><strong>Η</strong></td>
						<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>1</strong></td>
						<td>ΣΤΑΝΤΑΡ ΛΙΕΓΗΣ</td>
						<td><strong>6</strong></td>
						<td>2</td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">6 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>2</strong></td>
						<td>ΑΝΤΕΡΛΕΧΤ</td>
						<td><strong>6</strong></td>
						<td>2</td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">5 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>3</strong></td>
						<td>ΚΛΑΜΠ ΜΠΡΙΖ</td>
						<td><strong>6</strong></td>
						<td>2</td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>4</strong></td>
						<td>ΒΕΣΤΕΡΛΟ</td>
						<td><strong>6</strong></td>
						<td>2</td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>5</strong></td>
						<td>ΜΑΛΙΝ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>6</strong></td>
						<td>ΖΟΥΛΤΕ ΒΑΡΕΓΚΕΜ</td>
						<td><strong>3</strong></td>
						<td>2</td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>7</strong></td>
						<td>ΛΙΡΣ</td>
						<td><strong>3</strong></td>
						<td>2</td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>8</strong></td>
						<td>ΛΟΚΕΡΕΝ</td>
						<td><strong>3</strong></td>
						<td>2</td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>9</strong></td>
						<td>ΜΟΥΣΚΡΟΝ ΠΕΡΟΥΒΕΛΤΖ</td>
						<td><strong>3</strong></td>
						<td>2</td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>10</strong></td>
						<td>ΣΕΡΚΛ ΜΠΡΙΖ</td>
						<td><strong>2</strong></td>
						<td>2</td>
						<td>0</td>
						<td>2</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>11</strong></td>
						<td>ΓΑΝΔΗ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>12</strong></td>
						<td>ΓΚΕΝΚ</td>
						<td><strong>1</strong></td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>13</strong></td>
						<td>ΚΟΡΤΡΑΪΚ</td>
						<td><strong>0</strong></td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 5</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>14</strong></td>
						<td>ΒΑΑΣΛΑΝΤ ΜΠΕΒΕΡΕΝ</td>
						<td><strong>0</strong></td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>15</strong></td>
						<td>ΣΑΡΛΕΡΟΥΑ</td>
						<td><strong>0</strong></td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>16</strong></td>
						<td>ΟΣΤΑΝΔΗ</td>
						<td><strong>0</strong></td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 4</td>
						<td>&nbsp;</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('124. ΡΕΜΣ- ΠΑΡΙ ΣΕΝ ΖΕΡΜΕΝ (21.30)', '1407490800', 'GALIA.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">Το απόλυτο φαβορί ...</span></span></p>

<p><span style="font-size:16px">Μεγάλη διαφορά δυναμικότητας και ποιότητας για την Παρί .Ηδη πήρε το σουπερ καπ απέναντι στη γκινγκαπ και ξεκινά ως το απόλυτο φαβορί για τη κατάκτηση του τίτλου .Θα αναζητήση και το κάτι παρα πάνω στις ευρωπαικές της υπχρεώσεις μετά και τη προσθήκη των Νταβιντ Λουιζ και Οριέ. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 2&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΑΓΓΛΙΑ: Τσαμπιονσίπ', '1407491057', 'BFB.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">126. ΜΠΛΑΚΠΕΡΝ-ΚΑΡΝΤΙΦ (21.45)</span></span></p>

<p><span style="font-size:16px">Τα δεδομένα των μπούκ δείχνου άνοδο για την κάρντιφ και σαφώς έχεο προβάδισμα για τη νίκη. Η μπλακπερν άργησενα ξυπνήσει τη περσυνή σεζόν με αποτέλσμα να&nbsp;μείνει εκτός πλει οφ.<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ Χ2&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΙΡΛΑΝΔΙΑ . Σημεία και γκολ ', '1407491320', 'BDB.jpg', '<p><span style="color:#FF0000">127.</span> ΓΙΟΥ ΣΙ ΝΤΙ- ΜΠΕΜΙΑΝ ( 21.45) <span style="color:#DAA520">GOAL GOAL</span></p>

<p><span style="color:#FF0000">128</span>.ΚΟΡΚ -ΣΕΜΝΤ ΠΑΤΡΙΚΣ(21.45) <span style="color:#FF8C00">OVER</span></p>

<p><span style="color:#FF0000">129</span>.NTROXENTA-NTANTALK(21.45) <span style="color:#FF8C00">X</span></p>

<p><span style="color:#FF0000">130.</span>ΣΑΜΡΟΚ-ΝΤΕΡΙ(21.45) <span style="color:#FF8C00">2<span style="line-height:1.6">-3 ΓΚΟΛ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('La bombita Ντροχέντα-Ντανταλακ', '1407491624', 'BDB.jpg', '<p><span style="color:#0000FF"><span style="font-size:16px">129. Ντοχέντα-Ντανταλακ (22.00)</span></span></p>

<p><span style="font-size:16px">Ωρα να κάνει της γκέλας της η Ντανταλκ στο μεγάλο ντέρπμι της κομητείας του Λάουθ.Βελτιώθηκαν οι γηπεδούχοι με τη πρόσληψη νέου τεχνικού.<span style="color:#FF0000"> ΕΚΤΙΜΗΣΗ &nbsp;1 &nbsp;( 6.25)</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>ΙΡΛΑΝΔΙΑ</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
		</tr>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΝΤΑΝΤΑΛΚ</td>
			<td><strong>52</strong></td>
			<td>22</td>
			<td>16</td>
			<td>4</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">54 - 18</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΚΟΡΚ</td>
			<td><strong>46</strong></td>
			<td>22</td>
			<td>14</td>
			<td>4</td>
			<td>4</td>
			<td style="border-color:rgb(217, 217, 217)">35 - 18</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΣΕΝΤ ΠΑΤΡΙΚΣ</td>
			<td><strong>43</strong></td>
			<td>22</td>
			<td>12</td>
			<td>7</td>
			<td>3</td>
			<td style="border-color:rgb(217, 217, 217)">46 - 24</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΣΑΜΡΟΚ ΡΟΒΕΡΣ</td>
			<td><strong>40</strong></td>
			<td>22</td>
			<td>12</td>
			<td>4</td>
			<td>6</td>
			<td style="border-color:rgb(217, 217, 217)">30 - 22</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΝΤΕΡΙ</td>
			<td><strong>30</strong></td>
			<td>21</td>
			<td>7</td>
			<td>9</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">32 - 23</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΣΛΙΓΚΟ ΡΟΒΕΡΣ</td>
			<td><strong>29</strong></td>
			<td>21</td>
			<td>8</td>
			<td>5</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">27 - 18</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΛΙΜΕΡΙΚ</td>
			<td><strong>26</strong></td>
			<td>22</td>
			<td>7</td>
			<td>5</td>
			<td>10</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 29</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΜΠΟΕΜΙΑΝ</td>
			<td><strong>24</strong></td>
			<td>21</td>
			<td>5</td>
			<td>9</td>
			<td>7</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 27</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΝΤΡΟΧΕΝΤΑ</td>
			<td><strong>24</strong></td>
			<td>22</td>
			<td>7</td>
			<td>3</td>
			<td>12</td>
			<td style="border-color:rgb(217, 217, 217)">27 - 50</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΜΠΡΕΪ</td>
			<td><strong>18</strong></td>
			<td>23</td>
			<td>4</td>
			<td>6</td>
			<td>13</td>
			<td style="border-color:rgb(217, 217, 217)">18 - 48</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΓΙΟΥ ΣΙ ΝΤΙ</td>
			<td><strong>17</strong></td>
			<td>22</td>
			<td>4</td>
			<td>5</td>
			<td>13</td>
			<td style="border-color:rgb(217, 217, 217)">21 - 49</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΑΘΛΟΟΥΝ ΤΑΟΥΝ</td>
			<td><strong>12</strong></td>
			<td>22</td>
			<td>3</td>
			<td>3</td>
			<td>16</td>
			<td style="border-color:rgb(217, 217, 217)">23 - 39<br />
			&nbsp;</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΑΓΓΛΙΑ 1Η...ΕΝΑΡΞΗ ΣΤΟ ΝΗΣΙ', '1407577720', 'AGGLI.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">150. ΣΕΦΙΛΝΤ ΓΙΟΥΝ-ΜΠΡΙΣΤΟΛ ΣΙΤΙ (14.15)</span> &nbsp;Αμφότερες αποτελούν τα φαβορί για τη άνοδο με τις δύο ομάδες να έχουν το μαγαλύτερο μπάτζετ της κατηγορίας..Αρχη πρωταθλήματος , αναγωριστική αγωνιστική η ισοπαλια παίζει δυνατά. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ Χ</span>. <span style="color:#FF0000">167. ΓΕΟΒΙΛ-ΝΤΟΝΚΑΣΤΕΡ (17.00)</span> Προέρχονται από την Τσαμπιονςσιπ με προβλήματα επιθετικά.<span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ UNDER</span> .<span style="color:#FF0000">168. ΚΟΛΤΣΕΣΤΕΡ-ΟΛΝΤΑΜ (17.00) </span>&nbsp;Καλή στα φιλικά η Ολνταμ μπορεί να πάρει βαθμό. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ Χ</span>.<span style="color:#FF0000"> 169.ΛΕΙΤΟΝ ΟΡΙΕΝΤ-ΤΣΕΣΤΕΡΦΙΛΝΤ(17.00)</span><span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ</span>.<span style="color:#FF0000"> 170( ΜΚ ΝΤΟΝΣ- ΤΣΙΛΙΓΧΑΜ(17.00)</span><span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ </span>. <span style="color:#FF0000">171. ΜΠΑΡΝΣΛΕΙ -ΚΡΟΟΥΛΙ(17.00)</span> Η μία από ις 3 ομάδες που υποβιβάστηκαν από την τσαμπιονσιπ είνια Μπαρνσλει και έχει φυσικά το πρωτο λόγο κόντρα στην Κροόυλι.<span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ. </span><span style="color:#FF0000">172. ΜΠΡΑΝΤΦΟΡΝΤ- ΚΟΒΕΝΤΡΙ (17.00)</span> Ομάδες που χρείζεται να περιμένουμε μερικές αγωνιστικές για να βγάλουμε τα πρώτα συμπεράσματα .<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ NO BET </span>. <span style="color:#FF0000">173. ΠΟΡΤ ΒΕΙΛ- ΓΟΥΟΛΣΟΛ(17.00)</span> Για νειφώτιστη τα πήγε εξαιρετικά πέρυσι η Πρτ Βειλ που διεκδήκησε ακόμα και την είσοδό τη στα πλεί οφ .καταλαμβάνοντας εν τέλει τη 9 θέση. .Για τη Γουόλσολ ο στός παραμένει ιδιος , να είναι στην εξάδα,<span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ UNDER</span>. <span style="color:#FF0000">174. ΠΡΕΣΤΟΝ- ΝΟΤΣ ΚΑΟΥΝΤΙ (17.00)</span> Πίο ποιοτηική η Πρέστον έιναι το φαβορί .<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ</span> <span style="color:#FF0000">175. ΡΟΤΣΝΤΕΙΛ-ΠΙΤΕΡΜΠΟΡΟ(17.00)</span>&nbsp; <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ 2 </span><span style="color:#FF0000">176. ΣΟΥΙΝΤΟΝ-ΣΚΑΝΘΡΟΠ (17.00)</span><span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ Χ </span><span style="color:#FF0000">177.ΦΛΙΓΟΥΝΤ-ΚΡΟΥ(17.00)</span><span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ Χ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Β΄ Γαλλίας με δύο αναμετρήσεις ', '1407578229', 'images.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">151. ΒΑΛΕΝΣΙΕΝ-ΝΙΜ (14,30)</span> Στή πρεμίερα του πρωταθλήματος η Βαλενσιέν δεν έπεισε για την ετοιμότητα της και δεν δείχενει να είναι σην επιθυμητή φυσική κατάσταση.Αντιθέτως η Νλιμ πήρε τη νίκη επι της Ανζέ σε ένα ξεσπασαμα 30 λεπτών με 3-2. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 2 </span>.<span style="color:#FF0000"> 230.ΑΖΑΞΙΟ-ΣΟΣΟ(19.00)</span> Με το βαθμό της ισοπαλίας από τη πρεμίεραη Αζαξιό , με ήταα ξεκίνησε της υποχρεώσει τησ η Σοσό. Δυσκολο ματς .<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ UNDER</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>B΄ ΓΑΛΛΙΑΣ</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
		</tr>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΤΡΟΥΑ</td>
			<td><strong>6</strong></td>
			<td>2</td>
			<td>2</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΟΣΕΡ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΓΚΑΖΕΛΕΚ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΝΤΙΖΟΝ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΝΑΝΣΙ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΜΠΡΕΣΤ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΚΡΕΤΕΪΓ</td>
			<td><strong>3</strong></td>
			<td>2</td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">5 - 4</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΑΝΖΕ</td>
			<td><strong>3</strong></td>
			<td>2</td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">4 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΤΟΥΡ</td>
			<td><strong>3</strong></td>
			<td>2</td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">4 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΝΙΜ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΟΡΛΕΑΝ</td>
			<td><strong>3</strong></td>
			<td>2</td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΝΙΟΡ</td>
			<td><strong>2</strong></td>
			<td>2</td>
			<td>0</td>
			<td>2</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΛΟΥΖΕΝΑ</td>
			<td><strong>0</strong></td>
			<td>0</td>
			<td>0</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΑΖΑΞΙΟ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td>ΚΛΕΡΜΟΝ</td>
			<td><strong>1</strong></td>
			<td>2</td>
			<td>0</td>
			<td>1</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΛΑΒΑΛ</td>
			<td><strong>1</strong></td>
			<td>2</td>
			<td>0</td>
			<td>1</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>17</strong></td>
			<td>ΧΑΒΡΗ</td>
			<td><strong>1</strong></td>
			<td>2</td>
			<td>0</td>
			<td>1</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>18</strong></td>
			<td>ΑΡΛ</td>
			<td><strong>1</strong></td>
			<td>2</td>
			<td>0</td>
			<td>1</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>19</strong></td>
			<td>ΣΟΣΟ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>20</strong></td>
			<td>ΒΑΛΕΝΣΙΕΝ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>21</strong></td>
			<td>ΣΑΤΟΡΟΥ</td>
			<td><strong>0</strong></td>
			<td>2</td>
			<td>0</td>
			<td>0</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 4<br />
			&nbsp;</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις με γκολ από  Τσάμπιονσιπ..', '1407578538', 'AGGLI.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">158.</span> ΓΟΥΙΓΚΑΝ- ΡΕΝΤΙΓΚ &nbsp;(17.00) &nbsp;<span style="color:#DAA520">GOAL GOAL&nbsp;</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">159.</span> ΓΟΥΟΤΦΟΡΝΤ-ΜΠΟΛΤΟΝ(17.00) &nbsp; <span style="color:#DAA520">UNDER 3.5</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">161</span>.ΜΙΝΤΛΕΣΜΠΡΟ-ΜΠΕΡΜΙΓΧΑΜ&nbsp;(17.00) &nbsp; <span style="color:#DAA520">GOAL GOAL</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">165</span>.ΝΤΕΡΜΠΙ-ΡΟΔΕΡΑΜ(17.00) &nbsp; &nbsp; <span style="color:#DAA520">OVER</span></span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('153. ΖΕΝΙΤ-ΤΟΡΠΕΝΤΟ ( 16.00)', '1407578752', 'rwsia oikonomia.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">Σκοράρει η Ζενίτ..</span></span></p>

<p><span style="font-size:16px">Δυσκολέυτηκε αρχικά η Ζενίτ στη Ευρωπαιή της μάχη με την ΑΕ Λεμεσού πήρε όμως τη νίκη πρόκριση με 3-0.Επιθετικό έιναι και το παιχνίδι της Τορπέντο και πιθανό να δούμε ένα ματς ανολιχτό και με αρκετά γκολ <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 4-6 ΓΚΟΛ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('154. ΙΝΤΕΡ ΤΟΥΡΚΟΥ- ΣΕΙΝΑΓΙΟΝΕΝ (16.00)', '1407579025', 'images (1).jpg', '<p><span style="font-size:16px">Την περασμένη εβδομαδα αναμετρήθηκαν οι δύο ομαδες με 2-2 τελικό σκορ, εαν θυμηθομυ και στον α΄γύρο το ματς ήταν στο οβερ με σκορ 2-1</span><span style="color:#DAA520"> .ΕΚΤΙΜΗΣΗ OVER&nbsp;</span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>ΦΙΝΛΑΝΔΙΑ</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΕΛΣΙΝΚΙ</td>
			<td><strong>48</strong></td>
			<td>22</td>
			<td>14</td>
			<td>6</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">39 - 13</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΛΑΧΤΙ</td>
			<td><strong>41</strong></td>
			<td>22</td>
			<td>11</td>
			<td>8</td>
			<td>3</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 11</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΣΕΪΝΑΓΙΟΕΝ</td>
			<td><strong>36</strong></td>
			<td>21</td>
			<td>10</td>
			<td>6</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">24 - 15</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΚΟΥΟΠΙΟ</td>
			<td><strong>30</strong></td>
			<td>22</td>
			<td>8</td>
			<td>6</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">33 - 32</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΓΙΑΡΟ</td>
			<td><strong>29</strong></td>
			<td>22</td>
			<td>8</td>
			<td>5</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">32 - 27</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΒΑΑΣΑ</td>
			<td><strong>29</strong></td>
			<td>21</td>
			<td>8</td>
			<td>5</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">25 - 23</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΜΙΛΙΚΟΣΚΙ</td>
			<td><strong>29</strong></td>
			<td>22</td>
			<td>8</td>
			<td>5</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">31 - 37</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΡΟΒΑΝΙΕΜΙ</td>
			<td><strong>28</strong></td>
			<td>22</td>
			<td>8</td>
			<td>4</td>
			<td>10</td>
			<td style="border-color:rgb(217, 217, 217)">23 - 20</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΙΝΤΕΡ ΤΟΥΡΚΟΥ</td>
			<td><strong>25</strong></td>
			<td>22</td>
			<td>6</td>
			<td>7</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">27 - 34</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΜΑΡΙΕΧΑΜΝ</td>
			<td><strong>25</strong></td>
			<td>22</td>
			<td>7</td>
			<td>4</td>
			<td>11</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 41</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΧΟΝΚΑ</td>
			<td><strong>23</strong></td>
			<td>22</td>
			<td>5</td>
			<td>8</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">23 - 36</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΤΟΥΡΚΟΥ</td>
			<td><strong>16</strong></td>
			<td>22</td>
			<td>4</td>
			<td>4</td>
			<td>14</td>
			<td style="border-color:rgb(217, 217, 217)">17 - 37</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('΄Β ΓΕΡΜΑΝΙΑΣ ..', '1407579972', 'germany_flag.jpg', '<p><span style="font-size:16px"><span style="color:#B22222">155. ΑΟΥΕ-ΜΠΟΧΟΥΜ( 16.30)</span> Με παράδοση στο οβερ οι μεταξύ τους αναμετρήσεις. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ ΓΚΟΛ ΓΚΟΛ. </span><span style="color:#FF0000">156. ΜΠΡΑΟΥΝΣΒΑΙΚ- ΧΑΙΝΤΕΝΧΑΙΜ(16.30)&nbsp;</span>Χωρίς πολλά πολλά θεωρώ τον ασσο έναν απο τους πίο καλοπληρωμένους του κουπονίου<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>Β ΓΕΡΜΑΝΙΑΣ</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
		</tr>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΑΑΛΕΝ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΚΑΡΛΣΡΟΥΗ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΚΑΪΖΕΡΣΛΑΟΥΤΕΡΝ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΧΑΪΝΤΕΝΧΑΙΜ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΝΤΑΡΜΣΤΑΝΤ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΝΥΡΕΜΒΕΡΓΗ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΦΟΡΤΟΥΝΑ ΝΤΙΣΕΛΝΤ.</td>
			<td><strong>2</strong></td>
			<td>2</td>
			<td>0</td>
			<td>2</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΟΥΝΙΟΝ ΒΕΡΟΛΙΝΟΥ</td>
			<td><strong>2</strong></td>
			<td>2</td>
			<td>0</td>
			<td>2</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΜΠΡΑΟΥΝΣΒΑΪΓΚ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΜΠΟΧΟΥΜ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΓΚΡΟΪΤΕΡ ΦΙΡΤ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΙΝΓΚΟΛΣΤΑΝΤ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΛΕΙΨΙΑ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΣΑΝ ΠΑΟΥΛΙ</td>
			<td><strong>1</strong></td>
			<td>2</td>
			<td>0</td>
			<td>1</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td>ΜΟΝΑΧΟ 1860</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΑΟΥΕ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>17</strong></td>
			<td>ΣΑΝΤΧΑΟΥΖΕΝ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>18</strong></td>
			<td>ΦΣΒ ΦΡΑΝΚΦΟΥΡΤΗΣ</td>
			<td><strong>0</strong></td>
			<td>2</td>
			<td>0</td>
			<td>0</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 5<br />
			&nbsp;</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Πιγκουίνου...', '1407580383', 'images (2).jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">157.</span> ΒΑΛΕΡΕΝΓΚΑ- ΣΑΡΠΣΜΠΟΡΓΚ(16.30) &nbsp;<span style="color:#DAA520"> 2-3 ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">185. </span>ΝΟΡΘΑΜΠΤΟΝ-ΜΑΝΣΦΙΛΝΤ(17.00)<span style="color:#DAA520"> ΑΣΣΟΣ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">224.</span>ΝΕΟΥΣΤΑΝΤ-ΑΟΥΣΤΡΙΑ Β (17.30) <span style="color:#DAA520">&nbsp;OVER</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">228.</span> ΣΕΝ ΓΚΑΛΕΝ-ΑΑΡΑΟΥ (18.45)<span style="color:#DAA520"> ΓΚΟΛ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ά ΓΑΛΛΙΑΣ...', '1407581637', 'images.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">246.ΓΚΙΝΓΚΑΠ-ΣΕΝΤ ΕΤΙΕΝ (22.00)</span> Μοναδικός στόχος η παραμονή στη κατηγορία για την περσινή κυπελλλούχο Γαλλίας.Εξοδο στην Ευρώπη θα κυνηγήσει η Σεντ Ειεν και φυσικά θέλει να μπεί με το δεξί στις υποχρεώσεις<span style="color:#DAA520"> .ΕΚΤΙΜΗΣΗ 2.</span> <span style="color:#FF0000">247. ΕΒΙΑΝ-ΚΑΕΝ (22.00)</span> Υποψήφιες για υποβιβασμό οι ομάδες μένει να δούμε αν μπορουν να μας διαψέφσουν. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ UNDER</span>.<span style="color:#FF0000"> 248. ΛΙΛ-ΜΕΤΣ(22.00)</span> Με τον άερα ης ερώπης η Λιλ αναμετράται κόντρα τη νεοφώτιστη Μετς και σαφώς έχει το προβάδισμα για τη νίκη.<span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ ΑΣΣΟΣ.</span> <span style="color:#FF0000">249. ΜΟΝΤΠΕΛΙΕ-ΜΠΟΡΝΤΟ (22.00)</span> Μετρά πληγές η Μπορντό δύσκολη η προετοιμασία για το προπονητή της λόγω των πολλών τραυματισμών δυσκολο το παιχνίδι .<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ&nbsp;&nbsp;ΝΟ BET</span>.<span style="color:#FF0000">250 ΜΠΑΣΤΙΑ-ΜΑΡΣΕΙΓ(22.00) </span>Θέλει ξεκίνημα με το δεξί και μπορεί η Μαρσειγ<span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ 2.</span><span style="color:#FF0000">251 ΝΑΝΤ-ΛΑΝΣ(22.00)</span> Σε ισχύη η απογορευση μεταγγραφών και για τις δύο ομάδες ..στη πράξη και σο χρόνο θα φάνει η δυνατοτητα τους. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ ΝΟ ΒΕΤ</span>. <span style="color:#FF0000">252. ΝΙΣ-ΤΟΥΛΟΥΖ (22.00)</span><span style="color:#DAA520"> ΕΚΤΙΜΗΣΗ 2-3 &nbsp;ΓΚΟΛ&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('΄Β ΓΕΡΜΑΝΙΑΣ ', '1407663022', 'download.jpeg', '<p><span style="font-size:16px"><span style="color:#FF0000">277. ΙΝΚΟΛΣΤΑΝΤ-ΝΤΑΜΣΤΑΝΤ(14.30)</span> Με αρκετές απουσίες οι γηπεδούχοι κόντρα στην νεοφώτιστη και ενθουσιώδη Νταρμσταντ που κατάφερε να ξεκινήσει ο πρωτάθλημα με μία σπουδαία νίκη &nbsp;.Η Διαφορά ποιότητας υπαρχει και έιναι αυτή που δίνει προβάδισμα για νίκησ τους γηπεδούχους.<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ 1</span>.<span style="color:#FF0000"> 291. ΜΟΝΑΧΟ 1860 - ΛΕΙΨΙΑ (16.30)</span> Στη πρεμίερα η Μοναχο κατάφερε να χάσει παρότι προηγήθηκε με 2-0 εκτός έδρας της Λάουτερν, ενώ η Λειψία μοιράστηκε βαθμόυς με το 0-0 και σχετικά μια καλή εικόνα. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ 2-3 ΓΚΟΛ </span>.<span style="color:#FF0000">292. ΣΑΝΤΧΑΟΥΖΖΕΝ-ΚΑΙΖΕΡΣΛΑΟΥΤΕΡΝ(16.30) </span>Με ανατροπή απο 2-0 &nbsp;γύρισε και πήρα τη νίκη η Καιζερσλαουτερν με 3-2 επί της Μόναχο και μπορεί να κάνει το 2χ2&nbsp;στο πρωτάθλημα .<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ 2&nbsp;&nbsp;</span></span></p>

<p>&nbsp;</p>

<p>Β ΓΕΡΜΑΝΙΑΣ</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
		</tr>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΜΠΟΧΟΥΜ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">6 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΜΠΡΑΟΥΝΣΒΑΪΓΚ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">5 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΑΑΛΕΝ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΚΑΡΛΣΡΟΥΗ</td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΚΑΪΖΕΡΣΛΑΟΥΤΕΡΝ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΝΤΑΡΜΣΤΑΝΤ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΝΥΡΕΜΒΕΡΓΗ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΧΑΪΝΤΕΝΧΑΙΜ</td>
			<td><strong>3</strong></td>
			<td>2</td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 4</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΦΟΡΤΟΥΝΑ ΝΤΙΣΕΛΝΤ.</td>
			<td><strong>2</strong></td>
			<td>2</td>
			<td>0</td>
			<td>2</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΟΥΝΙΟΝ ΒΕΡΟΛΙΝΟΥ</td>
			<td><strong>2</strong></td>
			<td>2</td>
			<td>0</td>
			<td>2</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΓΚΡΟΪΤΕΡ ΦΙΡΤ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΙΝΓΚΟΛΣΤΑΝΤ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΛΕΙΨΙΑ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΣΑΝ ΠΑΟΥΛΙ</td>
			<td><strong>1</strong></td>
			<td>2</td>
			<td>0</td>
			<td>1</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td>ΜΟΝΑΧΟ 1860</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΣΑΝΤΧΑΟΥΖΕΝ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>17</strong></td>
			<td>ΦΣΒ ΦΡΑΝΚΦΟΥΡΤΗΣ</td>
			<td><strong>0</strong></td>
			<td>2</td>
			<td>0</td>
			<td>0</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 5</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>18</strong></td>
			<td>ΑΟΥΕ</td>
			<td><strong>0</strong></td>
			<td>2</td>
			<td>0</td>
			<td>0</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 6<br />
			&nbsp;</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ελβετία...', '1407663594', 'images.jpeg', '<p><span style="font-size:16px"><span style="color:#FF0000">278. ΛΟΥΚΕΡΝΗ-ΓΚΡΑΣΧΟΠΕΡΣ(14.45)</span> Ασχημο ξεκίνημα και για τις δύο ομάδες πιο ποιοτική η Γκρασχόπερς.Παρότι προηγήθηκε η Λουκέρνη της Σεν Γκάλεν λύγισε στο φινάλε και γνώρισε την ήττα με 2-1 .Η Γκραχόπερς αποκλείστηκε από τη Λιλ για το Τσαμπιονς Λιγκ και διανύει το χειρότερο ξεκίνημα της δεκαετίας .<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ Χ.</span> <span style="color:#FF0000">279. ΣΙΟΝ- ΒΑΝΤΟΥΖ(14.45)</span> Προερχόμενη από το 0-0 με την Γκρασχόπερς η Σιόν θέλει τη νίκη σήμερα και με δεδόμένη τη κόυραση της Βαντουζ θα τη πάρει. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 1 </span>295. <span style="color:#FF0000">ΓΙΟΥΝΓΚ ΜΠΟΙΣ-ΤΟΥΝ(17.00)</span> <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ OVER</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>ΕΛΒΕΤΙΑ</p>

<table border="0" cellpadding="0" cellspacing="0" style="background-color:rgb(238, 219, 142); color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td>
			<table border="0" cellpadding="3" cellspacing="0" style="width:615px">
				<tbody>
					<tr>
						<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
						<td><strong>Β</strong></td>
						<td><strong>ΑΓ</strong></td>
						<td><strong>Ν</strong></td>
						<td><strong>Ι</strong></td>
						<td><strong>Η</strong></td>
						<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>1</strong></td>
						<td>ΒΑΣΙΛΕΙΑ</td>
						<td><strong>12</strong></td>
						<td>4</td>
						<td>4</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">12 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>2</strong></td>
						<td>ΖΥΡΙΧΗ</td>
						<td><strong>12</strong></td>
						<td>5</td>
						<td>4</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">10 - 7</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>3</strong></td>
						<td>ΤΟΥΝ</td>
						<td><strong>6</strong></td>
						<td>4</td>
						<td>2</td>
						<td>0</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">7 - 7</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>4</strong></td>
						<td>ΑΑΡΑΟΥ</td>
						<td><strong>6</strong></td>
						<td>5</td>
						<td>1</td>
						<td>3</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">6 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>5</strong></td>
						<td>ΣΕΝ ΓΚΑΛΕΝ</td>
						<td><strong>5</strong></td>
						<td>4</td>
						<td>1</td>
						<td>2</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">6 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>6</strong></td>
						<td>ΣΙΟΝ</td>
						<td><strong>5</strong></td>
						<td>4</td>
						<td>1</td>
						<td>2</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>7</strong></td>
						<td>ΓΙΟΥΝΓΚ ΜΠΟΪΣ</td>
						<td><strong>2</strong></td>
						<td>3</td>
						<td>0</td>
						<td>2</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 5</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>8</strong></td>
						<td>ΓΚΡΑΣΧΟΠΕΡΣ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>9</strong></td>
						<td>ΒΑΝΤΟΥΖ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>10</strong></td>
						<td>ΛΟΥΚΕΡΝΗ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 6</td>
						<td>&nbsp;</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις με γκόλ..', '1407664090', 'download (1).jpeg', '<p><span style="font-size:14px"><span style="color:#FF0000">294</span>.&nbsp;ΑΡΣΕΝΑΛ-ΣΙΤΙ &nbsp;(17.00 )<span style="color:#0000FF"> OVER</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">298</span>.ΣΑΛΤΣΖΜΠΟΥΡΓΚ- ΓΚΡΙΝΤΙΓΚ (17.30) &nbsp;<span style="color:#0000FF">4-6 ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">301</span>.ΛΥΩΝ-ΡΕΝ (18.00) <span style="color:#0000FF">ΓΚΟΛ ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">305</span>.ΜΑΛΜΕ-ΓΚΕΤΕΠΟΡΓΚ(18.30) &nbsp;<span style="color:#0000FF">ΓΚΟΛ ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">312.</span> ΡΟΖΕΜΠΟΡΓΚ-ΣΤΑΡΤ(19.00) <span style="color:#0000FF">OVER</span></span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('282. Άγιαξ- Φίτεσε (15.30) ', '1407664491', 'images (1).jpeg', '<p><span style="color:#FF0000"><span style="font-size:14px">Δε χάνει&nbsp;στο πρωτάθλημα..</span></span></p>

<p><span style="font-size:14px">Και τη φετινή σεζόν το παόλυτο φαβορί ο Άγιαξ για την κατάκτηση του τίτλου, παρότι απώλεσε το Σουπερ Καπ. Επιθετικό το στύλ και των δύο ομάδων με τη φίτεσε τα τελευταία χρόνια να ενυσχύεται συνεχώς με νεαρούς παίχτες από τη Τσέλσι. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ ΓΚΟΛ</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<table border="0" cellpadding="0" cellspacing="0" style="background-color:rgb(238, 219, 142); color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td>
			<table border="0" cellpadding="3" cellspacing="0" style="width:615px">
				<tbody>
					<tr>
						<td colspan="2"><strong>ΜΑΔΑ</strong></td>
						<td><strong>Β</strong></td>
						<td><strong>ΑΓ</strong></td>
						<td><strong>Ν</strong></td>
						<td><strong>Ι</strong></td>
						<td><strong>Η</strong></td>
						<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>1</strong></td>
						<td>ΑΛΚΜΑΑΡ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>2</strong></td>
						<td>ΤΣΒΟΛΕ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>3</strong></td>
						<td>ΝΤΟΡΝΤΡΕΧΤ</td>
						<td><strong>3</strong></td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>4</strong></td>
						<td>ΚΑΜΠΟΥΡ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>5</strong></td>
						<td>ΕΞΕΛΣΙΟΡ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>6</strong></td>
						<td>ΤΒΕΝΤΕ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>7</strong></td>
						<td>ΜΠΡΕΝΤΑ</td>
						<td><strong>1</strong></td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>8</strong></td>
						<td>ΝΤΕΝ ΧΑΑΓΚ</td>
						<td><strong>0</strong></td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>9</strong></td>
						<td>ΑΓΙΑΞ</td>
						<td><strong>0</strong></td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>10</strong></td>
						<td>ΓΚΡΟΝΙΝΓΚΕΝ</td>
						<td><strong>0</strong></td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>11</strong></td>
						<td>ΦΕΓΕΝΟΡΝΤ</td>
						<td><strong>0</strong></td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>12</strong></td>
						<td>ΓΚΟΟΥ ΑΧΕΝΤ ΙΓΚΛΣ</td>
						<td><strong>0</strong></td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>13</strong></td>
						<td>ΑΪΝΤΧΟΦΕΝ</td>
						<td><strong>0</strong></td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>14</strong></td>
						<td>ΦΙΤΕΣΕ</td>
						<td><strong>0</strong></td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>15</strong></td>
						<td>ΒΙΛΕΜ</td>
						<td><strong>0</strong></td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>16</strong></td>
						<td>ΧΕΡΕΝΦΕΝ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>17</strong></td>
						<td>ΟΥΤΡΕΧΤΗ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>18</strong></td>
						<td>ΧΕΡΑΚΛΕΣ</td>
						<td><strong>0</strong></td>
						<td>1</td>
						<td>0</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 3</td>
						<td>&nbsp;</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('301. Λυών- Ρέν (18.00) ', '1407665181', 'download (2).jpeg', '<p><span style="font-size:16px"><span style="color:#0000FF">Καλοκάιρι αλλαγών...</span></span></p>

<p><span style="font-size:16px">Με αλλαγές θα παρουσιαστούν οι ομάδες στο φετινό πρωτάθλημα.Στη Λύων έδειξαν εμπιστοσύνη στον νεαρό Φουρνιέ και μένει να δικαιωθούν.Η Ρεν πραγματοποίησε σαρωτικές αλλαγές με πρώτη αυτη του&nbsp;προέδρου και με 12 αποχωρήσεις παιχτών. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ ΓΚΟΛ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Δανία. 344 Εσμπιεργκ-Σιλκεμπόρκ (20.00)', '1407744335', 'download.jpeg', '<p><span style="font-size:14px">Αμφότερες δεν σκοράρουν εύκολα αλλα διμηουργούν ευκαιρίες .Η Εσμπιεργκ μετράει έξι under στα επτα ματς που έχει δώσει σε όλες τις διοργανώσεις και η Σιλκεμποργκ είναι η ομάδα που δεν έχει σκοράρει στις 3 πρώτες αγωνιστικές.Αυτό θα επιδιωξουν να αλλάξουν σήμερα.<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ OVER</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>ΔΑΝΙΑ</p>

<table border="0" cellpadding="0" cellspacing="0" style="background-color:rgb(238, 219, 142); color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td>
			<table border="0" cellpadding="3" cellspacing="0" style="width:615px">
				<tbody>
					<tr>
						<td colspan="2"><strong>ΜΑΔΑ</strong></td>
						<td><strong>Β</strong></td>
						<td><strong>ΑΓ</strong></td>
						<td><strong>Ν</strong></td>
						<td><strong>Ι</strong></td>
						<td><strong>Η</strong></td>
						<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>1</strong></td>
						<td>ΧΟΜΠΡΟ</td>
						<td><strong>9</strong></td>
						<td>4</td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">8 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>2</strong></td>
						<td>ΜΙΝΤΙΛΑΝΤ</td>
						<td><strong>9</strong></td>
						<td>4</td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">9 - 5</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>3</strong></td>
						<td>ΝΟΡΝΤΖΕΛΑΝΤ</td>
						<td><strong>9</strong></td>
						<td>4</td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">9 - 7</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>4</strong></td>
						<td>ΡΑΝΤΕΡΣ</td>
						<td><strong>9</strong></td>
						<td>4</td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">5 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>5</strong></td>
						<td>ΑΑΛΜΠΟΡΓΚ</td>
						<td><strong>5</strong></td>
						<td>4</td>
						<td>1</td>
						<td>2</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>6</strong></td>
						<td>ΣΟΝΤΕΡΙΣΚΕ</td>
						<td><strong>5</strong></td>
						<td>4</td>
						<td>1</td>
						<td>2</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>7</strong></td>
						<td>ΚΟΠΕΓΧΑΓΗ</td>
						<td><strong>5</strong></td>
						<td>4</td>
						<td>1</td>
						<td>2</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>8</strong></td>
						<td>ΒΕΣΤΣΑΕΛΑΝΤ</td>
						<td><strong>4</strong></td>
						<td>4</td>
						<td>1</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">7 - 7</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>9</strong></td>
						<td>ΜΠΡΟΝΤΜΠΙ</td>
						<td><strong>4</strong></td>
						<td>4</td>
						<td>1</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>10</strong></td>
						<td>ΟΝΤΕΝΣΕ</td>
						<td><strong>2</strong></td>
						<td>4</td>
						<td>0</td>
						<td>2</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 7</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>11</strong></td>
						<td>ΕΣΜΠΙΕΡΓΚ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 5</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>12</strong></td>
						<td>ΣΙΛΚΕΜΠΟΡΓΚ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 4</td>
						<td>&nbsp;</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Β΄ Νορβηγίας. 345- Φρέντρικσταντ-Μιοντάλεν (20.00)', '1407744700', 'norway-flag-1.jpg', '<p><span style="font-size:16px">Ομάδες με τις ίδιες σχεδόν δυνατότητες και σε καλή αγωνιστική κατάσταση λόγω έδρας μικρό προβάδισμα στου γηπεδούχους που μετρούν πέντε νίκες και μία ισοπαλία στους έξι τελευταίους αγώνες στην έδρα τους <span style="color:#DAA520">.ΕΚΤΙΜΗΣΗ 1&nbsp;</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>Β΄ ΝΟΡΒΗΓΙΑΣ</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΤΡΟΜΣΟ</td>
			<td><strong>40</strong></td>
			<td>18</td>
			<td>12</td>
			<td>4</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">40 - 13</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΣΑΝΤΕΦΙΟΡΝΤ</td>
			<td><strong>40</strong></td>
			<td>19</td>
			<td>11</td>
			<td>7</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">35 - 14</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΡΑΝΧΑΪΜ</td>
			<td><strong>33</strong></td>
			<td>19</td>
			<td>10</td>
			<td>3</td>
			<td>6</td>
			<td style="border-color:rgb(217, 217, 217)">29 - 17</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΜΙΟΝΤΑΛΕΝ</td>
			<td><strong>32</strong></td>
			<td>17</td>
			<td>9</td>
			<td>5</td>
			<td>3</td>
			<td style="border-color:rgb(217, 217, 217)">33 - 19</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΚΡΙΣΤΙΑΝΣΟΥΝΤ</td>
			<td><strong>31</strong></td>
			<td>19</td>
			<td>9</td>
			<td>4</td>
			<td>6</td>
			<td style="border-color:rgb(217, 217, 217)">34 - 25</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΦΡΕΝΤΡΙΚΣΤΑΝΤ</td>
			<td><strong>31</strong></td>
			<td>18</td>
			<td>9</td>
			<td>4</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">25 - 16</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΜΠΑΕΡΟΥΜ</td>
			<td><strong>31</strong></td>
			<td>19</td>
			<td>10</td>
			<td>1</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">30 - 37</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΝΕΣΤ ΣΟΤΡΑ</td>
			<td><strong>24</strong></td>
			<td>19</td>
			<td>7</td>
			<td>3</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">30 - 30</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΧΟΝΤ</td>
			<td><strong>24</strong></td>
			<td>19</td>
			<td>6</td>
			<td>6</td>
			<td>7</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 29</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΣΤΡΟΜΕΝ</td>
			<td><strong>23</strong></td>
			<td>19</td>
			<td>6</td>
			<td>5</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">31 - 32</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΑΛΤΑ</td>
			<td><strong>23</strong></td>
			<td>19</td>
			<td>6</td>
			<td>5</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">20 - 28</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΧΟΝΕΦΟΣ</td>
			<td><strong>23</strong></td>
			<td>19</td>
			<td>7</td>
			<td>2</td>
			<td>10</td>
			<td style="border-color:rgb(217, 217, 217)">23 - 35</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΜΠΡΙΝΕ</td>
			<td><strong>21</strong></td>
			<td>19</td>
			<td>6</td>
			<td>3</td>
			<td>10</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 36</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΤΡΟΜΣΝΤΑΛΕΝ</td>
			<td><strong>20</strong></td>
			<td>19</td>
			<td>5</td>
			<td>5</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">24 - 37</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td>ΟΥΛΕΝΣΑΚΕΡ</td>
			<td><strong>16</strong></td>
			<td>19</td>
			<td>4</td>
			<td>4</td>
			<td>11</td>
			<td style="border-color:rgb(217, 217, 217)">17 - 28</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΧΑΜ ΚΑΜ</td>
			<td><strong>6</strong></td>
			<td>19</td>
			<td>1</td>
			<td>3</td>
			<td>15</td>
			<td style="border-color:rgb(217, 217, 217)">10 - 37</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ουέφα Σουπέρ Καπ Ρεαλ ΜαδρΙτης-Σεββίλη  21.45', '1407831788', '100px-Supercoppa_d’Europa_logo.png', '<p><span style="font-size:14px">Οι κάτοχοι των Ευρωπαικών κυπέλλων Τσαμπιονς Λιγκ και ουέφα , Ρεαλ Μαδρίτης και Σεββίλη αντίστοιχα κοντραρονται σήμερα στην Αγγλια παρακλώ στο Καρντιφ για το Σουπερ Καπ, με τις δύο ομάδες να μετρούν από μία κατάκτηση του θεσμού.Στόχος της Ρεάλ για τη φετινή χρονιά δεν έιναι άλλος από τη κατάκτηση όλων των διοργανώσεων!! με αρχή το Σουπερ Καπ. Η Σεββίλη πέρυσι κατέκτησε το Γιουρόπα Λιγκ στα πέναλντι νικώντας τη Μπενφίκα αλλα δε κάταφερε να πιάσει τη προνομιουχο 4 θέση στο πρωτάθλημα που πήρε η Ατλετικ οτυ Βαλβέρδε και οδηγεί στο Τσαμπιος Λιγκ.Στόχος της φέτος να τα καταφέρει.Υπερδύναμη η Ρεαλ ευκολα η δύσκολα θα πάρει το Σουπερ Καπ. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ 1&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Λιγκ Καπ Αγγλίας πρώτος γύρος', '1407832299', 'download (1).jpeg', '<p>109. ΓΕΟΒΙΛ- ΤΣΙΛΙΓΧΑΜ (21.45) &nbsp; &nbsp; <span style="color:#0000FF">&nbsp;ΓΚΟΛ</span></p>

<p>111. ΓΟΥΛΒΣ-ΝΟΡΘΑΜΠΤΟΝ (21.45) &nbsp; <span style="color:#0000FF">1</span></p>

<p>129. ΠΟΡΤΒΕΙΛ-ΧΑΡΤΠΟΥΛ(21.45)<span style="color:#0000FF"> ΓΚΟΛ</span></p>

<p>133. ΣΑΟΥΘΕΝΤ-ΓΟΥΟΛΣΟΛ(21.45) <span style="color:#0000FF">2-3 ΓΚΟΛ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Φιλανδία...', '1407935989', 'finlandia-simaia-arxeio.jpg', '<p><span style="font-size:14px">159. ΜΑΡΙΕΧΣΜΝ-ΒΑΑΣΑ(18.30)<span style="color:#DAA520"> Χ2</span></span></p>

<p><span style="font-size:14px">160.ΣΕΙΝΑΓΙΟΕΝ-ΓΙΑΡΟ(18.30) <span style="color:#DAA520">2-3 ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px">161.ΤΟΥΡΚΟΥ-ΧΟΝΚΑ(18.30)<span style="color:#DAA520"> ΓΚΟΛ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις ημέρας για ταμείο ', '1407936254', '44_1.jpg', '<p><span style="color:#FF0000">162</span>.ΝΤΟΡΤΜΟΥΝΤ-ΜΠΑΓΕΡΝ(19.00) <span style="color:#0000FF">OVER</span></p>

<p><span style="color:#FF0000">173</span>.ΑΙΚ-ΤΖΟΥΡΓΚΑΝΤΕΝ(20.05) <span style="color:#0000FF">ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">176</span>.ΓΙΟΥΝΓΚ ΜΠΟΙΣ-ΓΚΡΑΣΧΟΠΕΡΣ(20.45) <span style="color:#0000FF">ΑΣΣΟΣ</span></p>

<p><span style="color:#FF0000">179</span>.ΚΟΒΕΝΤΡΙ-ΚΑΡΝΤΙΦ(21.45) <span style="color:#0000FF">2-3 ΓΚΟΛ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ρωσία με δύο αναμετρήσεις', '1408008632', 'images.jpeg', '<p><span style="font-size:14px"><span style="color:#FF0000">190.ΛΟΚΟΜΟΤΙΒ Μ.-ΡΟΣΤΟΦ (17.30) </span>Προβληματική η Ροστόφ στην άμυνα με τον τερματοφύλακα στους δύο πρώτους αγώνες να μαζέυει τη μπάλα εννέα ! φορές από τα δίχτυα.Η Λοκομοτίβ χωρίς να ιδρώσει νίκησε εκτός εδρας με 2-0 την Αρσεναλ Τούλα.<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ 1.</span> <span style="color:#FF0000">194. ΚΡΑΣΝΤΟΝΤΑΡ-ΣΠΑΡΤΑΚ Μ (20.00)</span> Με νίκη και καλή ψυχολογία θέλει ν πάει η Σπαρτα στο ντέρμπυ της επ''ομενης εβδομάδας στη Μόσχα με τη Τσσκα, κουραμένη η Κρασντονταρ απο τα συνεχη ταξίδια σε πρωτάθλημα και ευρώπη.<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ 2&nbsp;</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<table border="0" cellpadding="0" cellspacing="0" style="background-color:rgb(238, 219, 142); color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td>
			<table border="0" cellpadding="3" cellspacing="0" style="width:615px">
				<tbody>
					<tr>
						<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
						<td><strong>Β</strong></td>
						<td><strong>ΑΓ</strong></td>
						<td><strong>Ν</strong></td>
						<td><strong>Ι</strong></td>
						<td><strong>Η</strong></td>
						<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>1</strong></td>
						<td>ΖΕΝΙΤ</td>
						<td><strong>9</strong></td>
						<td>3</td>
						<td>3</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">14 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>2</strong></td>
						<td>ΤΣΣΚΑ ΜΟΣΧΑΣ</td>
						<td><strong>9</strong></td>
						<td>3</td>
						<td>3</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">6 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>3</strong></td>
						<td>ΝΤΙΝΑΜΟ ΜΟΣΧΑΣ</td>
						<td><strong>6</strong></td>
						<td>3</td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">10 - 5</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>4</strong></td>
						<td>ΣΠΑΡΤΑΚ ΜΟΣΧΑΣ</td>
						<td><strong>6</strong></td>
						<td>2</td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">6 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>5</strong></td>
						<td>ΤΕΡΕΚ ΓΚΡΟΖΝΥ</td>
						<td><strong>4</strong></td>
						<td>3</td>
						<td>1</td>
						<td>1</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">5 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>6</strong></td>
						<td>ΚΟΥΜΠΑΝ</td>
						<td><strong>4</strong></td>
						<td>2</td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>7</strong></td>
						<td>ΛΟΚΟΜΟΤΙΒ ΜΟΣΧΑΣ</td>
						<td><strong>4</strong></td>
						<td>2</td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>8</strong></td>
						<td>Μ. ΣΑΡΑΝΣΚ</td>
						<td><strong>3</strong></td>
						<td>2</td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>9</strong></td>
						<td>ΟΥΦΑ</td>
						<td><strong>3</strong></td>
						<td>3</td>
						<td>1</td>
						<td>0</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>10</strong></td>
						<td>ΚΡΑΣΝΟΝΤΑΡ</td>
						<td><strong>2</strong></td>
						<td>2</td>
						<td>0</td>
						<td>2</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>11</strong></td>
						<td>ΡΟΥΜΠΙΝ ΚΑΖΑΝ</td>
						<td><strong>2</strong></td>
						<td>3</td>
						<td>0</td>
						<td>2</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 5</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>12</strong></td>
						<td>ΟΥΡΑΛ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>13</strong></td>
						<td>ΡΟΣΤΟΦ</td>
						<td><strong>1</strong></td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">5 - 9</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>14</strong></td>
						<td>ΑΜΚΑΡ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>15</strong></td>
						<td>ΑΡΣΕΝΑΛ ΤΟΥΛΑ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 6</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>16</strong></td>
						<td>ΤΟΡΠΕΝΤΟ ΜΟΣΧΑΣ</td>
						<td><strong>1</strong></td>
						<td>3</td>
						<td>0</td>
						<td>1</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 13</td>
						<td>&nbsp;</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Α΄ Σουηδίας...', '1408009001', 'Σουηδία.png', '<p>195. ΚΑΛΜΑΡ-ΦΑΛΚΕΝΜΠΕΡΓΚ (20.00) &nbsp;<span style="color:#0000FF">2-3 ΓΚΟΛ</span></p>

<p>196.ΜΙΑΛΜΠΙ-ΝΟΡΚΕΠΙΝΚΓ(20.00) &nbsp;<span style="color:#0000FF">Χ</span></p>

<p>197.ΧΑΛΜΣΤΑΝΤ-ΧΑΚΕΝ (20.00) <span style="color:#0000FF">UNDER 3.5</span></p>

<p>198.ΧΕΛΣΙΜΠΟΡΓΚ-ΕΛΦΣΜΠΟΡΓΚ(20.05) <span style="color:#0000CD">ΓΚΟΛ </span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<table border="0" cellpadding="0" cellspacing="0" style="background-color:rgb(238, 219, 142); color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td>
			<table border="0" cellpadding="3" cellspacing="0" style="width:615px">
				<tbody>
					<tr>
						<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
						<td><strong>Β</strong></td>
						<td><strong>ΑΓ</strong></td>
						<td><strong>Ν</strong></td>
						<td><strong>Ι</strong></td>
						<td><strong>Η</strong></td>
						<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>1</strong></td>
						<td>ΜΑΛΜΕ</td>
						<td><strong>44</strong></td>
						<td>19</td>
						<td>13</td>
						<td>5</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">40 - 18</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>2</strong></td>
						<td>ΑΪΚ ΣΤΟΚΧΟΛΜΗΣ</td>
						<td><strong>38</strong></td>
						<td>19</td>
						<td>11</td>
						<td>5</td>
						<td>3</td>
						<td style="border-color:rgb(217, 217, 217)">39 - 25</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>3</strong></td>
						<td>ΕΛΦΣΜΠΟΡΓΚ</td>
						<td><strong>34</strong></td>
						<td>18</td>
						<td>10</td>
						<td>4</td>
						<td>4</td>
						<td style="border-color:rgb(217, 217, 217)">29 - 17</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>4</strong></td>
						<td>ΧΑΚΕΝ</td>
						<td><strong>31</strong></td>
						<td>18</td>
						<td>9</td>
						<td>4</td>
						<td>5</td>
						<td style="border-color:rgb(217, 217, 217)">33 - 22</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>5</strong></td>
						<td>ΓΚΕΤΕΜΠΟΡΓΚ</td>
						<td><strong>28</strong></td>
						<td>19</td>
						<td>6</td>
						<td>10</td>
						<td>3</td>
						<td style="border-color:rgb(217, 217, 217)">30 - 23</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>6</strong></td>
						<td>ΚΑΛΜΑΡ</td>
						<td><strong>28</strong></td>
						<td>18</td>
						<td>7</td>
						<td>7</td>
						<td>4</td>
						<td style="border-color:rgb(217, 217, 217)">24 - 22</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>7</strong></td>
						<td>ΤΖΟΥΡΓΚΑΡΝΤΕΝ</td>
						<td><strong>24</strong></td>
						<td>19</td>
						<td>5</td>
						<td>9</td>
						<td>5</td>
						<td style="border-color:rgb(217, 217, 217)">28 - 24</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>8</strong></td>
						<td>ΑΤΒΙΝΤΑΜΠΕΡΓΚ</td>
						<td><strong>24</strong></td>
						<td>19</td>
						<td>6</td>
						<td>6</td>
						<td>7</td>
						<td style="border-color:rgb(217, 217, 217)">23 - 30</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>9</strong></td>
						<td>ΓΚΕΦΛΕ</td>
						<td><strong>22</strong></td>
						<td>19</td>
						<td>5</td>
						<td>7</td>
						<td>7</td>
						<td style="border-color:rgb(217, 217, 217)">23 - 24</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>10</strong></td>
						<td>ΝΟΡΚΕΠΙΝΓΚ</td>
						<td><strong>21</strong></td>
						<td>18</td>
						<td>5</td>
						<td>6</td>
						<td>7</td>
						<td style="border-color:rgb(217, 217, 217)">20 - 29</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>11</strong></td>
						<td>ΦΑΛΚΕΝΜΠΕΡΓΚ</td>
						<td><strong>20</strong></td>
						<td>18</td>
						<td>5</td>
						<td>5</td>
						<td>8</td>
						<td style="border-color:rgb(217, 217, 217)">21 - 28</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>12</strong></td>
						<td>ΧΑΛΜΣΤΑΝΤ</td>
						<td><strong>20</strong></td>
						<td>18</td>
						<td>5</td>
						<td>5</td>
						<td>8</td>
						<td style="border-color:rgb(217, 217, 217)">22 - 31</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>13</strong></td>
						<td>ΧΕΛΣΙΝΓΚΜΠΟΡΓΚ</td>
						<td><strong>19</strong></td>
						<td>18</td>
						<td>4</td>
						<td>7</td>
						<td>7</td>
						<td style="border-color:rgb(217, 217, 217)">19 - 25</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>14</strong></td>
						<td>ΕΡΕΜΠΡΟ</td>
						<td><strong>19</strong></td>
						<td>19</td>
						<td>4</td>
						<td>7</td>
						<td>8</td>
						<td style="border-color:rgb(217, 217, 217)">22 - 29</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>15</strong></td>
						<td>ΜΙΑΛΜΠΙ</td>
						<td><strong>15</strong></td>
						<td>18</td>
						<td>4</td>
						<td>3</td>
						<td>11</td>
						<td style="border-color:rgb(217, 217, 217)">17 - 28</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>16</strong></td>
						<td>ΜΠΡΟΜΑΠΟΪΚΑΡΝΑ</td>
						<td><strong>9</strong></td>
						<td>19</td>
						<td>1</td>
						<td>6</td>
						<td>12</td>
						<td style="border-color:rgb(217, 217, 217)">23 - 38</td>
						<td>&nbsp;</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ά Βελγίου αγώνες παρασκευής ', '1408091012', 'Flag_of_Belgium.svg_.png', '<p><span style="color:#FF0000">2</span><span style="font-size:14px"><span style="color:#FF0000">03. ΜΟΥΣΚΡΟΝ ΠΕΡ - ΣΤΑΝΤΑΡ ΛΙΕΓΗΣ(19.00)</span> Από ήττα προέρχεται η Στανταρ στην έδρα της από ην Γανδη ενω ακολουθεί και το ματς για το Γιουρόπα Λιγκ με τη Ζενίτ. Η Μοσκρόν παρότι αποτελεί το φαβορί για υποβιβασμό ως νεοφώτιστη στη κατηγορία η ισοπαλία που απέσπασε από τη Λιρς μας κανενι να ανεθεωρήσουμε και να δώσουμε χρόνο στην ομάδα καθώς μπορεί να κάνει την εκπληξη. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ Χ.</span> <span style="color:#FF0000">218. ΚΛΑΜΠ ΜΠΡΙΖ-ΣΕΡΚΛ- ΜΠΡΙΖ (21.30)</span> Το τοπικό ντέρμου του Βελγίου με σαφή διαφορά δυναμικότητας η Κλαμπ ωστόσο πραμένει ντέρμπι. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ ΓΚΟΛ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Βελγιο...', '1408091120', 'Flag_of_Belgium.svg_.png', '<p><span style="color:#0000FF">218. ΚΛΑΜΠ ΜΠΡΙΖ-ΣΕΡΚΛ ΜΠΡΙΖ&nbsp;</span></p>

<p>Τοπικό ντέρμπι με μεγάλη αντιπαλότητα ..</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Α΄Ρωσίας 204  Μ. Σαρανσκ- Κουμπάν (19.00 )', '1408091653', 'rwsia-shmaia.jpg', '<p><span style="font-size:14px">Χωρίς ήττα η Κουμπάν στο πρωτάθλημα αλλα παρουσιάσε αδυναμίες στην άμυνα.Η Σαρανσκ πάλεψε στο αγώνα με την Τσσκα και όλα έδειχναν ότι θα &nbsp;έπερνε τον βαθμό της ισοπαλίας αν δεν έκανε το πέναλντι στο 80΄. ενώ ξεκίνησε με νίκη και καλή εμφάνιση με 3-2 επί της Ουράλ. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ Χ1&nbsp;&nbsp;</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
		</tr>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΖΕΝΙΤ</td>
			<td><strong>9</strong></td>
			<td>3</td>
			<td>3</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">14 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΤΣΣΚΑ ΜΟΣΧΑΣ</td>
			<td><strong>9</strong></td>
			<td>3</td>
			<td>3</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">6 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΛΟΚΟΜΟΤΙΒ ΜΟΣΧΑΣ</td>
			<td><strong>7</strong></td>
			<td>3</td>
			<td>2</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">4 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΝΤΙΝΑΜΟ ΜΟΣΧΑΣ</td>
			<td><strong>6</strong></td>
			<td>3</td>
			<td>2</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">10 - 5</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΣΠΑΡΤΑΚ ΜΟΣΧΑΣ</td>
			<td><strong>6</strong></td>
			<td>3</td>
			<td>2</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">6 - 5</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΚΡΑΣΝΟΝΤΑΡ</td>
			<td><strong>5</strong></td>
			<td>3</td>
			<td>1</td>
			<td>2</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">5 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΤΕΡΕΚ ΓΚΡΟΖΝΥ</td>
			<td><strong>4</strong></td>
			<td>3</td>
			<td>1</td>
			<td>1</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">5 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td><span style="color:#FF0000">ΚΟΥΜΠΑΝ</span></td>
			<td><strong>4</strong></td>
			<td>2</td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">4 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td><span style="color:#0000FF">Μ. ΣΑΡΑΝΣΚ</span></td>
			<td><strong>3</strong></td>
			<td>2</td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΟΥΦΑ</td>
			<td><strong>3</strong></td>
			<td>3</td>
			<td>1</td>
			<td>0</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 4</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΡΟΥΜΠΙΝ ΚΑΖΑΝ</td>
			<td><strong>2</strong></td>
			<td>3</td>
			<td>0</td>
			<td>2</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 5</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΟΥΡΑΛ</td>
			<td><strong>1</strong></td>
			<td>3</td>
			<td>0</td>
			<td>1</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">4 - 6</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΑΜΚΑΡ</td>
			<td><strong>1</strong></td>
			<td>3</td>
			<td>0</td>
			<td>1</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 6</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΡΟΣΤΟΦ</td>
			<td><strong>1</strong></td>
			<td>3</td>
			<td>0</td>
			<td>1</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">6 - 11</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td>ΑΡΣΕΝΑΛ ΤΟΥΛΑ</td>
			<td><strong>1</strong></td>
			<td>3</td>
			<td>0</td>
			<td>1</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 6</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΤΟΡΠΕΝΤΟ ΜΟΣΧΑΣ</td>
			<td><strong>1</strong></td>
			<td>3</td>
			<td>0</td>
			<td>1</td>
			<td>2</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 13<br />
			&nbsp;</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Β΄Γαλλίας  προτάσεις με σημεία και γκολ ', '1408092080', 'download (2).jpeg', '<p>209. ΛΑΒΑΛ- ΚΡΕΤΕΙΓ (21.00) <span style="color:#DAA520">1</span></p>

<p>210. ΝΑΝΣΙ-ΑΡΛ(21.00) <span style="color:#DAA520">&nbsp;ΓΚΟΛ</span></p>

<p>211.ΝΙΜ-ΝΤΙΖΟΝ(21.00) &nbsp;<span style="color:#DAA520">2-3 ΓΚΟΛ</span></p>

<p>212.ΝΙΟΡ-ΧΑΒΡΗ (21.00) <span style="color:#DAA520">ΗΜ Χ&nbsp;</span></p>

<p>213. ΟΣΕΡ-ΟΡΛΕΑΝ(21.00) <span style="color:#DAA520">2-3 ΓΚΟΛ</span></p>

<p>214.ΣΑΤΟΡΟΥ-ΚΛΕΡΜΟΝ (21.00) <span style="color:#DAA520">1</span></p>

<p>215.ΤΟΥΡ-ΒΑΛΕΝΣΙΕΝ(21.00) <span style="color:#DAA520">Χ2&nbsp;</span></p>

<p>&nbsp;</p>

<table border="0" cellpadding="0" cellspacing="0" style="background-color:rgb(238, 219, 142); color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td>
			<table border="0" cellpadding="3" cellspacing="0" style="width:615px">
				<tbody>
					<tr>
						<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
						<td><strong>Β</strong></td>
						<td><strong>ΑΓ</strong></td>
						<td><strong>Ν</strong></td>
						<td><strong>Ι</strong></td>
						<td><strong>Η</strong></td>
						<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>1</strong></td>
						<td>ΤΡΟΥΑ</td>
						<td><strong>6</strong></td>
						<td>2</td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>2</strong></td>
						<td>ΟΣΕΡ</td>
						<td><strong>4</strong></td>
						<td>2</td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>3</strong></td>
						<td>ΓΚΑΖΕΛΕΚ</td>
						<td><strong>4</strong></td>
						<td>2</td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">3 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>4</strong></td>
						<td>ΝΙΜ</td>
						<td><strong>4</strong></td>
						<td>2</td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">5 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>5</strong></td>
						<td>ΝΤΙΖΟΝ</td>
						<td><strong>4</strong></td>
						<td>2</td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>6</strong></td>
						<td>ΝΑΝΣΙ</td>
						<td><strong>4</strong></td>
						<td>2</td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>7</strong></td>
						<td>ΜΠΡΕΣΤ</td>
						<td><strong>4</strong></td>
						<td>2</td>
						<td>1</td>
						<td>1</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>8</strong></td>
						<td>ΚΡΕΤΕΪΓ</td>
						<td><strong>3</strong></td>
						<td>2</td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">5 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>9</strong></td>
						<td>ΑΝΖΕ</td>
						<td><strong>3</strong></td>
						<td>2</td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>10</strong></td>
						<td>ΤΟΥΡ</td>
						<td><strong>3</strong></td>
						<td>2</td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">4 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>11</strong></td>
						<td>ΣΟΣΟ</td>
						<td><strong>3</strong></td>
						<td>2</td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>12</strong></td>
						<td>ΟΡΛΕΑΝ</td>
						<td><strong>3</strong></td>
						<td>2</td>
						<td>1</td>
						<td>0</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>13</strong></td>
						<td>ΛΟΥΖΕΝΑ</td>
						<td><strong>0</strong></td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 0</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>14</strong></td>
						<td>ΝΙΟΡ</td>
						<td><strong>2</strong></td>
						<td>2</td>
						<td>0</td>
						<td>2</td>
						<td>0</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>15</strong></td>
						<td>ΚΛΕΡΜΟΝ</td>
						<td><strong>1</strong></td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>16</strong></td>
						<td>ΛΑΒΑΛ</td>
						<td><strong>1</strong></td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>17</strong></td>
						<td>ΒΑΛΕΝΣΙΕΝ</td>
						<td><strong>1</strong></td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">2 - 4</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>18</strong></td>
						<td>ΧΑΒΡΗ</td>
						<td><strong>1</strong></td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">1 - 3</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>19</strong></td>
						<td>ΑΖΑΞΙΟ</td>
						<td><strong>1</strong></td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>20</strong></td>
						<td>ΑΡΛ</td>
						<td><strong>1</strong></td>
						<td>2</td>
						<td>0</td>
						<td>1</td>
						<td>1</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 2</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><strong>21</strong></td>
						<td>ΣΑΤΟΡΟΥ</td>
						<td><strong>0</strong></td>
						<td>2</td>
						<td>0</td>
						<td>0</td>
						<td>2</td>
						<td style="border-color:rgb(217, 217, 217)">0 - 4</td>
						<td>&nbsp;</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις με γκόλ..', '1408092761', 'football-goal-vector_23-2147487288.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">205</span>. ΒΑΡΜΠΕΡΓΚΣ-ΣΙΡΙΟΥΣ ( 19.30) <span style="color:#0000FF">OVER</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">207</span>. ΣΤΑΡΤ- ΣΤΡΟΜΣΓΚΟΝΣΕΤ(20.00) <span style="color:#0000FF">ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">217</span>.ΦΕΓΕΝΟΡΝΤ-ΧΕΡΕΝΦΕΝ (21.00)<span style="color:#0000FF"> ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">219. </span>ΚΑΕΝ-ΛΙΛ (21.30) <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις με γκολ..', '1408265911', 'images.jpg', '<p><span style="color:#FF0000">370.</span> ΧΑΡΤΣ-ΧΙΜΠΕΡΝΙΑΝ(14.30) &nbsp;<span style="color:#0000FF">ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">373</span>.ΜΑΡΣΕΙΓ-ΜΟΝΤΠΕΛΙΕ(18.00) <span style="color:#0000FF">2-3 ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">376</span>.ΛΙΒΕΡΠΟΥΛ-ΣΑΟΥΘΑΜΠΤΟΝ (15.30) <span style="color:#0000FF">OVER</span></p>

<p><span style="color:#FF0000">411.</span>ΡΑΝΤΕΡΣ-ΟΝΤΕΝΣΕ(20.00)<span style="color:#0000FF"> ΓΚΟΛ</span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('UEFA Champions League ', '1408440320', 'champions-league7.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">101. </span>ΚΟΠΕΓΧΑΓΗ-ΛΕΒΕΡΚΟΥΖΕΝ (21.45)<span style="color:#DAA520"> 2</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">102</span>.ΜΠΕΣΙΚΤΑΣ-ΑΡΣΕΝΑΛ(21.45) <span style="color:#DAA520">2</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">103</span>.ΝΑΠΟΛΙ-ΜΠΙΛΜΠΑΟ (21.45)<span style="color:#DAA520"> Χ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">104.</span>ΣΑΛΤΣΜΠΟΥΡΓΚ-ΜΑΛΜΕ(21.45) <span style="color:#DAA520">1</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">105</span>.ΣΤΕΑΟΥΑ-ΛΟΥΝΤΟΓΚΟΡΕΤΣ(21.45) <span style="color:#DAA520">Χ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ο ΠΙγκουίνος...στο Τσαμπιονς Λιγκ', '1408440439', 'champions-league7.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">101</span>.ΚΟΠΕΓΧΑΓΗ-ΛΕΒΕΡΚΟΥΖΕΝ (21.45) <span style="color:#0000FF">ΗΜ Χ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">103</span>.ΝΑΠΟΛΙ-ΜΠΙΛΜΠΑΟ(21.45) <span style="color:#0000FF">ΗΜ Χ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">104</span>.ΣΑΛΤΣΜΠΟΥΡΓΚ-ΜΑΛΜΕ <span style="color:#0000FF">Η/Τ 1/1</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις με γκολ.. απο Αγγλία ', '1408440812', 'england_bmp.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">111.</span>ΝΟΡΓΟΥΙΤΣ-ΜΠΛΑΚΜΠΕΡΝ (21.45) &nbsp;<span style="color:#DAA520">OVER</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">128.</span>ΛΟΥΤΟΝ-ΜΠΕΡΙ (21.45) <span style="color:#DAA520">2-3 ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">139</span>.ΡΕΝΤΙΓΚ-ΧΑΝΤΕΡΣΦΙΛΝΤ(22.00) <span style="color:#DAA520">OVER</span></span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('162. Άαλμποργκ-Αποέλ (21.45) ', '1408524097', 'champions-league7.jpg', '<p><span style="color:#FF0000"><span style="font-size:14px">Μαχητής ο Αποέλ...</span></span></p>

<p><span style="font-size:16px">Το εμπόδιο της Κροατικής Ντιναμό ξεπέρασαν οι Δανοί για να βρεθούν στο δρόμο του Αποέλ, κρατόντας μάλιστα τομηδέν στην άμυνα.0 Αποέλ καθάρισε σε ένα ημίχρονο την Ελσίνκι και θα δικεδηκήσει τη πρόκριση στα ισα.<span style="color:#0000FF">ΕΚΤΙΜΗΣΗ &nbsp;Χ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Τσάμπιονς Λίγκ', '1408524459', 'champions-league7.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">163</span>. ΛΙΛ-ΠΟΡΤΟ (21.45) <span style="color:#0000FF">2-3 ΓΚΟΛ&nbsp;</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">164</span>. ΜΑΡΙΜΠΟΡ-ΣΕΛΤΙΚ (21.45) <span style="color:#0000FF">ΗΜ Χ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">165.&nbsp;</span>ΣΛΟΒΑΝ ΜΠΡΑΤ. ΜΠΑΤΕ (21.45) <span style="color:#0000FF">&nbsp;1</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">166.</span> ΣΤΑΝΤΑΡ Λ - ΖΕΝΙΤ (21.45)<span style="color:#0000FF"> 2-3 ΓΚΟΛ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Βήμα πρόκρισης για τις Ελληνικές ομάδες.....', '1408611488', 'uefa-europa-league-hymne-officiel.jpg', '<p><span style="color:#FF0000">1<span style="font-size:14px">86. </span></span><span style="color:#006400"><span style="font-size:14px">ΠΑΝΑΘΗΝΑΙΚΟΣ</span></span><span style="color:#FF0000"><span style="font-size:14px">-ΜΙΝΤΙΛΑΝΤ (21.00) </span></span><span style="font-size:14px">Ο Παναθηναικός πλήρωσε τα αμυντικά λάθη στον αγώνα με τη Στανταρ Λιέγης εντός έδρας και έχασε τη π΄ροκριση στους ομίλους του Τσαμπιονς Λίγκ, σήμερα καλέιται να ξεπεράσει τα όποια προβλήματα στην άμυνα και να παρει καθαρό πρόβάδοσμα πρόκρισης.Η Μίντιλαντ μπορεί να σκοράρει στη λεοφώρο ,ενώ στη Δανία παραμένει στη πρώτη θέση της βαθμπλογίας μετά και τη νίκη με 2-1 επι της Κοπεγχαγης .<span style="color:#DAA520">ΕΚΤΙΜΗΣΗ ΓΚΟΛ.</span><span style="color:#FF0000">189.ΖΙΜΠΡΟΥ- ΠΑΟΚ ( 21.05)</span> Η άγνωστη Ζιμπρου από τη Μολδαβία δεν αποτελεί φυσικά όμαδα φόβητρο για το Παοκ που στα εκτός έδρας μάτς στην Ευρώπη αγωνιζεται με σοβαρότητα και μπορεί ν απάρει βάθμο η και βαθμούς που θα τον βαλουν από σήμερα στο κόλπο πρόκρισης.Στην πρωτέυουσα Κισιναου θα διεξαχθεί ο αγώνας και σύμφωνα με τις προτιμήσεις του προποητή της η Ζμπρόυ θα κατέβει με σχήμα 4-4-2 στο οποίο και αρέσκεται ο Λευκορώσος προπονητής Κουμπαρεφ. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ Χ.</span><span style="color:#FF0000">190.ΑΣΤΕΡΑΣ ΤΡΙΠΟΛΗΣ- ΜΑΚΑΜΠΙ Τ.Α (21.15)</span> Ο Αστέρας μας έχεο ήδη δείξει ότι είνια ικανός να μπέι στους ομίλους αλλα και να κάνει μια ικανοποιητική πορεία και παραμένει αήττητός στην έδρα του με ψυχολογία στα ύψη έχονας κάνει την υπέρβαση και επικρατόντας της Μαιντζ με 3-1 .Η πρωταθλήτρια Ισραήλ Μακάμπι φυσικά και δεν έιναι&nbsp;ευκολός αντίπαλος &nbsp;αν και τα βρήκε δύσκολα με τη μάριμπορ. <span style="color:#DAA520">ΕΚΤΙΜΗΣΗ &nbsp;2-3 ΓΚΟΛ&nbsp;</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ά Σουδίας  105. Μίαλμπι-Χέλσινμποργκ (20.00)', '1408697176', 'Σουηδία (1).png', '<p><span style="font-size:14px">Καθοριστικό το μάτς και για του δύο με τη Μίαλμπι να δέιχενι σημάδια ανάκαμψης στη πίο κρίσημη στιγμή καθώς βρίσκεται στη ζώνη του υποβιβασμού από την άλλη η Χελσινμποργκ μετρά μόνο μία νίκη εκτός έδρας.<span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 1&nbsp;</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΜΑΛΜΕ</td>
			<td><strong>45</strong></td>
			<td>20</td>
			<td>13</td>
			<td>6</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">40 - 18</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΑΪΚ ΣΤΟΚΧΟΛΜΗΣ</td>
			<td><strong>38</strong></td>
			<td>20</td>
			<td>11</td>
			<td>5</td>
			<td>4</td>
			<td style="border-color:rgb(217, 217, 217)">41 - 29</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td>ΕΛΦΣΜΠΟΡΓΚ</td>
			<td><strong>37</strong></td>
			<td>20</td>
			<td>11</td>
			<td>4</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">32 - 21</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΧΑΚΕΝ</td>
			<td><strong>35</strong></td>
			<td>20</td>
			<td>10</td>
			<td>5</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">38 - 24</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΓΚΕΤΕΜΠΟΡΓΚ</td>
			<td><strong>31</strong></td>
			<td>20</td>
			<td>7</td>
			<td>10</td>
			<td>3</td>
			<td style="border-color:rgb(217, 217, 217)">33 - 23</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΚΑΛΜΑΡ</td>
			<td><strong>31</strong></td>
			<td>20</td>
			<td>8</td>
			<td>7</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">27 - 25</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΤΖΟΥΡΓΚΑΡΝΤΕΝ</td>
			<td><strong>27</strong></td>
			<td>20</td>
			<td>6</td>
			<td>9</td>
			<td>5</td>
			<td style="border-color:rgb(217, 217, 217)">32 - 24</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΑΤΒΙΝΤΑΜΠΕΡΓΚ</td>
			<td><strong>24</strong></td>
			<td>20</td>
			<td>6</td>
			<td>6</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">23 - 33</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΓΚΕΦΛΕ</td>
			<td><strong>23</strong></td>
			<td>20</td>
			<td>5</td>
			<td>8</td>
			<td>7</td>
			<td style="border-color:rgb(217, 217, 217)">23 - 24</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td><span style="color:#FF0000">ΧΕΛΣΙΝΓΚΜΠΟΡΓΚ</span></td>
			<td><strong>23</strong></td>
			<td>20</td>
			<td>5</td>
			<td>8</td>
			<td>7</td>
			<td style="border-color:rgb(217, 217, 217)">24 - 27</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΦΑΛΚΕΝΜΠΕΡΓΚ</td>
			<td><strong>23</strong></td>
			<td>20</td>
			<td>6</td>
			<td>5</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">25 - 31</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΧΑΛΜΣΤΑΝΤ</td>
			<td><strong>23</strong></td>
			<td>20</td>
			<td>6</td>
			<td>5</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">25 - 36</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΕΡΕΜΠΡΟ</td>
			<td><strong>22</strong></td>
			<td>20</td>
			<td>5</td>
			<td>7</td>
			<td>8</td>
			<td style="border-color:rgb(217, 217, 217)">26 - 31</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td>ΝΟΡΚΕΠΙΝΓΚ</td>
			<td><strong>21</strong></td>
			<td>20</td>
			<td>5</td>
			<td>6</td>
			<td>9</td>
			<td style="border-color:rgb(217, 217, 217)">22 - 34</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td><span style="color:#0000FF">ΜΙΑΛΜΠΙ</span></td>
			<td><strong>18</strong></td>
			<td>20</td>
			<td>5</td>
			<td>3</td>
			<td>12</td>
			<td style="border-color:rgb(217, 217, 217)">20 - 33</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΜΠΡΟΜΑΠΟΪΚΑΡΝΑ</td>
			<td><strong>9</strong></td>
			<td>20</td>
			<td>1</td>
			<td>6</td>
			<td>13</td>
			<td style="border-color:rgb(217, 217, 217)">23 - 41</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πορτογαλία:    132.  Γκιμαράες - Πενιαφέλ (22.00) ', '1408697926', 'portogalia.gif', '<p><span style="font-size:16px">Ιδανικό ξεκίνημα για τη Γκιμαράες με νίκη 3-1 μέσα στη Ζιλ Βιθέντε και με τους νεαρούς της ομάδας να αποκτούν αυτοπεποίθηση και ενθουσιασμό. Αντιθέτως αρνητικά ξεκίνησε&nbsp;τις υποχρεώσεις η Πενιαφέλ που ηττήθηκε 1-3 στην έδρα της. Δεν έχει αξία&nbsp;ο άσσος αλλά είναι επικρατέστερος.<span style="color:#0000FF"> ΕΚΤΙΜΗΣΗ 1&nbsp;</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<table border="0" cellpadding="3" cellspacing="0" style="color:rgb(41, 41, 41); font-family:verdana,arial,sans-serif; font-size:11px; width:615px">
	<tbody>
		<tr>
			<td colspan="2"><strong>ΟΜΑΔΑ</strong></td>
			<td><strong>Β</strong></td>
			<td><strong>ΑΓ</strong></td>
			<td><strong>Ν</strong></td>
			<td><strong>Ι</strong></td>
			<td><strong>Η</strong></td>
			<td style="border-color:rgb(217, 217, 217)"><strong>ΓΚΟΛ</strong></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>1</strong></td>
			<td>ΜΠΡΑΓΚΑ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>2</strong></td>
			<td>ΜΠΕΛΕΝΕΝΣΕΣ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>3</strong></td>
			<td><span style="color:#FF0000">ΓΚΙΜΑΡΑΕΣ</span></td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">3 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>4</strong></td>
			<td>ΜΠΕΝΦΙΚΑ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>5</strong></td>
			<td>ΠΟΡΤΟ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>6</strong></td>
			<td>ΡΙΟ ΑΒΕ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">2 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>7</strong></td>
			<td>ΜΟΡΕΪΡΕΝΣΕ</td>
			<td><strong>3</strong></td>
			<td>1</td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 0</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>8</strong></td>
			<td>ΑΚΑΔΕΜΙΚΑ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>9</strong></td>
			<td>ΑΡΟΥΚΑ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>10</strong></td>
			<td>ΕΣΤΟΡΙΛ</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>11</strong></td>
			<td>ΣΠΟΡΤΙΝΓΚ ΛΙΣ.</td>
			<td><strong>1</strong></td>
			<td>1</td>
			<td>0</td>
			<td>1</td>
			<td>0</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>12</strong></td>
			<td>ΝΑΣΙΟΝΑΛ ΜΑΔΕΪΡΑ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 1</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>13</strong></td>
			<td>ΖΙΛ ΒΙΘΕΝΤΕ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>14</strong></td>
			<td><span style="color:#0000FF">ΠΕΝΑΦΙΕΛ</span></td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">1 - 3</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>15</strong></td>
			<td>ΜΑΡΙΤΙΜΟ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>16</strong></td>
			<td>ΠΑΚΟΣ ΦΕΡΕΪΡΑ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>17</strong></td>
			<td>ΣΕΤΟΥΜΠΑΛ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 2</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><strong>18</strong></td>
			<td>ΜΠΟΑΒΙΣΤΑ</td>
			<td><strong>0</strong></td>
			<td>1</td>
			<td>0</td>
			<td>0</td>
			<td>1</td>
			<td style="border-color:rgb(217, 217, 217)">0 - 3</td>
		</tr>
	</tbody>
</table>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Β Γαλλίας Προτάσεις γκολ', '1408698558', 'download.jpeg', '<p><span style="font-size:14px"><span style="color:#FF0000">106.</span> ΑΖΑΞΙΟ- ΤΟΥΡ (21.00) <span style="color:#DAA520">ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">111.</span> ΚΡΕΤΕΙΓ-ΝΙΟΡ (21.00) &nbsp;<span style="color:#DAA520">ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">112. </span>ΝΑΝΣΙ-ΝΙΜ (21.00) &nbsp;<span style="color:#DAA520">&nbsp;2-3 ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">114</span>.ΤΡΟΥΑ-ΛΑΒΑΛ (21.00) &nbsp;<span style="color:#DAA520">ΓΚΟΛ&nbsp;</span></span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Σουπερ καπ Ισπανίας.....', '1408699324', 'download (1).jpeg', '<p><span style="font-size:14px">Επαναληπτικός αγώνας του 1-1 της Τρίτης για το Σούπερ Καπ. Από το 1999 έχει να κερδίσει η Ατλέτικο τη Ρεάλ μέσα στο γήπεδό της. Τα κατάφερε όμως σε ορισμένες περιπτώσεις είτε σε ουδέτερη έδρα, είτε στο Σαντιάγκο Μπερναμπέου. Οι δύο ομάδες είχαν έρθει ξανά 1-1 στο 90λεπτο του τελικού του Τσάμπιονς Λιγκ τον Μάιο, όμως στην παράταση η Ρεάλ κέρδισε με 4-1 αφού πρώτα είχε ισοφαρίσει στις καθυστερήσεις.<br />
<br />
<span style="color:#FF0000">ΑΤΛΕΤΙΚΟ ΜΑΔΡΙΤΗΣ</span> -&nbsp;<span style="font-family:tahoma,arial,helvetica,sans-serif">Έ</span><span style="font-family:tahoma,arial,helvetica,sans-serif">χει αποκτήσει χαρακτήρα μετά την εκπληκτική περσινή πορεία της και την κατάκτηση του πρωταθλήματος Ισπανίας. Το απέδειξε στον αγώνα της Τρίτης, όπου παρότι βρέθηκε πίσω στο σκορ στο 81ο λεπτό, κατάφερε να ισοφαρίσει στο 88ο. Ο Μάντζουκιτς δείχνει πως μπορεί να αντικαταστήσει επάξια τον Ντιέγκο Κόστα και ας είναι αρχή ακόμα. Το ίδιο συμβαίνει με τον Σικέιρα για τη θέση του Φελίπε Λουίς στο αριστερό άκρο της άμυνας, ενώ ο Γκριζμάν δίνει ποιότητα στα άκρα της επιθετικής γραμμής. Αποκτήθηκε και ο Χεσούς Γκάμεθ της Μάλαγα, που μπορεί να δώσει λύσεις σε αρκετές θέσεις της άμυνας. Απουσιάζει ο πολύτιμος Τουράν (Μ) και ο νεοαποκτηθείς Κορέα (Ε).</span><br />
<br />
<span style="color:#0000FF">ΡΕΑΛ ΜΑΔΡΙΤΗΣ&nbsp;</span><span style="background-color:rgb(206, 212, 222); font-family:tahoma,arial,helvetica,sans-serif">- </span><span style="font-family:tahoma,arial,helvetica,sans-serif">Δεν ξέρουμε τί βαθμό είχε ο Αντσελότι στη χημεία, όμως το... μείγμα που έχει δημιουργηθεί στη Ρεάλ μοιάζει όχι μόνο... εκρητικό (με την καλή έννοια), αλλά και επικίνδυνο (με την κακή). Ο Χάμες Ροντρίγκες πάντως άνοιξε λογαριασμό με το καλημέρα, σκοράροντας στον πρώτο αγώνα ερχόμενος από τον πάγκο. Ο νεαρός Κολομβιανός δε θα έχει προσωρινά πρόβλημα αν συμβαίνει κάτι τέτοιο, όμως ρίχνοντας μια ματιά στον πάγκο της Ρεάλ σε... real time του πρώτου αγώνα, καταλαβαίνει κανείς από τις αντιδράσεις πως υπάρχει θέμα. Ο Ντι Μαρία βρίσκεται στην αποστολή, αλλά βλέπει προς την έξοδο, ενώ κάτι αντίστοιχο συμβαίνει πιθανότατα και με τον Κεντίρα. Εκτός μάχης παραμένει ο φορ Ροντρίγκεθ.</span></span></p>

<p><span style="color:#DAA520"><span style="font-size:14px"><span style="font-family:tahoma,arial,helvetica,sans-serif">ΕΚΤΙΜΗΣΗ 2-3 ΓΚΟΛ</span></span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Γερμανία.....', '1408787287', 'germany_flag.jpg', '<p><span style="color:#FF0000">163.</span> ΑΙΝΤΡΑΧΤ ΦΡ - ΦΡΑΙΜΠΟΥΡΓΚ (16.30) <span style="color:#DAA520">&nbsp;ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">164</span>.ΑΝΝΟΒΕΡΟ- ΣΑΛΚΕ (16.30)<span style="color:#DAA520"> 2-3 ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">165. </span>ΚΟΛΩΝΙΑ-ΑΜΒΟΥΡΓΟ (16.30)<span style="color:#DAA520"> ΗΜ Χ</span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις ταμείου..', '1408787674', 'στοιχημα-παμε-ταμειο.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">170.</span> ΣΑΟΥΘΑΜΠΤΟΝ- ΓΟΥΕΣΤ ΜΠΡΟΜ (17.00) &nbsp; <span style="color:#0000FF">1</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">239.</span> ΜΑΛΜΕ- ΝΟΡΚΕΠΙΝΓΚ (17.00) <span style="color:#0000FF">&nbsp; 1</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">249.</span> ΕΒΕΡΤΟΝ-ΑΡΣΕΝΑΛ (19.30) &nbsp;<span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">250.</span> ΝΤΟΡΤΜΟΥΝΤ-ΛΕΒΕΡΚΟΥΖΕΝ (19.30) <span style="color:#0000FF">1</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">273</span>.ΠΑΛΕΡΜΟ-ΜΟΝΤΕΝΑ (21.45) &nbsp;<span style="color:#0000FF">1</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('370. ΛΕΒΑΔΕΙΑΚΟΣ-ΠΑΝΑΘΗΝΑΙΚΟΣ (21.30) ', '1408871533', 'SUPERLEAGUE - ΣΟΥΠΕΡ ΛΙΓΚΑ.jpg', '<p><span style="font-size:14px"><strong>&nbsp;Ο αγώνας διεξάγεται στο ουδέτερο ΟΑΚΑ λόγω ακαταλληλότητας της φυσικής έδρας των γηπεδούχων στη Λιβαδειά. Ο Παναθηναϊκός μετράει 5 διπλά στις 6 τελευταίες επισκέψεις στην έδρα του αντιπάλου του. Στην περσινή σεζόν έπαιξε ως φιλοξενούμενος στο ΟΑΚΑ με την Καλλονή και την κέρδισε με 4-0.&nbsp;&nbsp;</strong><br />
<br />
<span style="color:#008080"><strong>ΛΕΒΑΔΕΙΑΚΟΣ</strong></span><span style="color:#FF0000"><strong>&nbsp;</strong></span><span style="font-family:tahoma,arial,helvetica,sans-serif"><span style="color:#FF0000">-</span> Έχοντας εντός έδρας ρεκόρ... πρωταθλητισμού (13-2-2) κατάφερε να σωθεί. Τερμάτισε στην 8η θέση του περσινού πρωταθλήματος, αλλά η απόστασή του από τα μπαράζ υποβιβασμού ήταν μόλις 4 βαθμοί. Γενικά οι Βοιωτοί αποτελούν μία έμπειρη αγωνιστικά και διοικητικά ομάδα. Στόχος είναι για μία ακόμη σεζόν η παραμονή. Οι υποχρεώσεις ξεκινούν με δύσκολη αναμέτρηση αφού ο Παναθηναϊκός είναι μία από τις πιο έτοιμες ομάδες του πρωταθλήματος λόγω των ευρωπαϊκών αγώνων του. Η ουδετερότητα της έδρας ανεβάζει ακόμη περισσότερο τον βαθμό δυσκολίας, όμως η ομάδα έχει ενισχυθεί και ο προπονητής Παντελίδης πιστεύει πως μπορεί να ξεκινήσει με θετικό αποτέλεσμα. Στη Λιβαδειά μετακόμισαν οι Τομάς, Πιντέρ, Πρόγιτς, Γεωργιάδης (Α), Ζιτό και Γκόμες (Μ). Έφυγαν οι Μουλόπουλος, Λυκογιάννης, Γεωργίου, Ιντζίδης, Χαραλάμπους, Πετράτσι και Βαρέλα. Εκ των νεοαποκτηθέντων, πρόβλημα αντιμετωπίζουν οι Γεωργιάδης και Πίντερ, όμως το μεγάλο αγκάθι συνιστά ο τραυματισμός του Βαγγέλη Μάντζιου, που αποτελεί τον βασικό φορ της ομάδας.</span><br />
<br />
<strong><span style="color:#008000">ΠΑΝΑΘΗΝΑΪΚΟΣ</span>&nbsp;</strong><span style="font-family:tahoma,arial,helvetica,sans-serif">- Έχει ήδη δώσει τρεις ευρωπαϊκές αναμετρήσεις και είναι φυσιολογικά να βρίσκεται πιο... μπροστά από τον Λεβαδειακό σε επίπεδο ετοιμότητας. Οι Πράσινοι δεν τα κατάφεραν με τη Σταντάρ Λιέγης, έβαλαν όμως γερές βάσεις κόντρα στη Μίντιλαντ την Πέμπτη, κερδίζοντας 4-1 στη Λεωφόρο. Ακολουθεί επαναληπτικός στη Δανία, όμως το σκορ του πρώτου αγώνα επιτρέπει αφοσίωση στην πρεμιέρα του πρωταθλήματος με την απαραίτητη ψυχραιμία. Στο Τριφύλλι όλοι περιμένουν μια σεζόν ανάλογη με το δεύτερο μισό της περσινής, όπου και το καλύτερο ποδόσφαιρο έπαιξε και τα επιθυμητά αποτελέσματα σημείωσε. Θα είναι συνολικά καλύτερη από την περσινή, που πήρε τη 2η θέση μέσω των μπαράζ και κατέκτησε το Κύπελλο; Θα φανεί στην πορεία, όμως το βέβαιο είναι πως για να κλείσει η ψαλίδα με τον Ολυμπιακό και να μπει στη διαδικασία διεκδίκησης του τίτλου, ο Παναθηναϊκός δε... δικαιούται να χάνει βαθμούς σε αγώνες όπως ο σημερινός. Ο Μπεργκ σκόραρε 4 φορές με τη Μίντιλαντ και δύσκολα θα μείνει άσφαιρος στο... ανοιχτό ΟΑΚΑ. Εκτός οι Λαγός, Κουτρουμπής και Κλωναρίδης.</span></span></p>

<p><span style="font-size:14px"><span style="font-family:tahoma,arial,helvetica,sans-serif">ΕΚΤΙΜΗΣΗ: <span style="color:#DAA520">2-3 ΓΚΟΛ</span></span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('379. ΝΑΝΤ-ΜΟΝΑΚΟ (22.00)', '1408871808', 'download (2).jpeg', '<p><span style="font-size:16px"><span style="font-family:arial,helvetica,sans-serif">&nbsp;Με άδικο τρόπο και σπρώξιμο απο τον διαιτητή, έχασε την προηγούμενη αγωνιστική η <span style="color:#FF0000">Μονακό </span>η οποία έλεγχε απόλυτα το πρώτο ημίχρονο και δίκαια προηγήθηκε με 0-1. Στην επανάληψη η Μπορντό πίεσε και ισοφάρισε σε 1-1. Απο εκεί πέρα ανέλαβε δράση ο διαιτητής σφυρίζοντας 2 ανύπαρκτα πέναλτι και καταλογίζοντας άλλο 1 γκόλ το οποίο ήταν καθαρό οφσάιντ.Ο Ζαρντίμ ασχετώς αν αδικήθηκε ή όχι η ομάδα, βρίσκεται σε πολύ δύσκολη θέση με τους οπαδούς κυρίως να είναι απογοητευμένοι αφού για φέτος έλπιζαν η ομάδα να είναι πιο ανταγωνιστική σε σχέση με πέρυσι.Η Νάντ στην έδρα της είναι απο τις πιο δύσκολες ομάδες, αλλά η διαφορά ποιότητας σύν το γεγονός ότι το παιχνίδι είναι πολύ κρίσημο για τον Ζαρντίμ αλλά γενικά και για την Μονακό καθιστούν το διπλό σαν το πιο λογικό σημείο σε αυτή την αναμέτρηση. Στο ίδιο γήπεδο και πέρυσι οι φιλοξενούμενοι κέρδισαν με 0-1 οπότε δεν νομίζω να είναι δύσκολο να το επαναλάβουν.&nbsp;</span></span></p>

<p><span style="color:#0000FF"><span style="font-size:14px">ΕΚΤΙΜΗΣΗ 2&nbsp;</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;
<p>&nbsp;</p>
</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις ημέρας για ταμείο ', '1408872378', 'στοιχημα-παμε-ταμειο.jpg', '<p><span style="color:#FF0000">328.</span> ΣΑΝΤΕΡΛΑΝΤ-ΜΑΝΤΣΕΣΤΕΡ Γ (18.00) <span style="color:#DAA520">OVER&nbsp;</span></p>

<p><span style="color:#FF0000">353.</span> ΑΤΡΟΜΗΤΟΣ-ΠΛΑΤΑΝΙΑΣ (19.15) &nbsp;<span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">370.</span>ΛΕΒΑΔΕΙΑΚΟΣ-ΠΑΝΑΘΗΝΑΙΚΟΣ (21.30) <span style="color:#0000FF">2</span></p>

<p><span style="color:#FF0000">379</span>.NANT-MONAKO (22.00) <span style="color:#0000FF">&nbsp;2</span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις με γκολ.. απο Αγγλία και Ολλανδία', '1408964446', 'GOAL11.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">408.</span> ΤΟΡΚΙ - ΟΛΝΤΕΡΣΟΤ (17.00) &nbsp;<span style="color:#DAA520">ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">426.</span> ΟΣ- ΦΕΝΛΟ (21.00) &nbsp;<span style="color:#DAA520">ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">429</span>. ΦΟΛΕΝΤΑΜ-ΡΟΝΤΑ(21.00) <span style="color:#DAA520">2-3 ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">433. </span>ΜΑΝ ΣΙΤΙ -ΛΙΒΕΡΠΟΥΛ (22.00) <span style="color:#DAA520">&nbsp;ΓΚΟΛ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις ημέρας για ταμείο ', '1409062264', 'images.jpeg', '<p><span style="font-size:14px">107. ΤΡΟΥΑ- ΑΖΑΞΙΟ (21.00) <span style="color:#DAA520">ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px">112.ΜΠΑΤΕ ΜΠΟΡΙΣΟΦ-ΣΛΟΒΑΝ ΜΠΡΑΤ (21.45) <span style="color:#0000FF">Η/Τ &nbsp;Χ/1</span></span></p>

<p><span style="font-size:14px">113. ΠΟΡΤΟ-ΛΙΛΙ (21.45) &nbsp; <span style="color:#0000FF">1</span></span></p>

<p><span style="font-size:14px">130. ΣΟΥΟΝΣΙ-ΡΟΔΕΡΑΜ (21.45) <span style="color:#0000FF">1</span></span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Champions league...', '1409150249', 'champions1.jpg', '<p><span style="color:#FF0000">150. </span>ΑΘΛΕΤΙΚ ΜΠΙΛΜΠΑΟ- ΝΑΠΟΛΙ (21.45) &nbsp; <span style="color:#0000FF">ΗΜ Χ</span></p>

<p><span style="color:#FF0000">151</span>.ΑΡΣΕΝΑΛ-ΜΠΕΣΙΚΤΑΣ (21.45)<span style="color:#0000FF"> 1</span></p>

<p><span style="color:#FF0000">152.</span>ΛΕΒΕΡΚΟΥΖΕΝ-ΚΟΠΕΓΧΑΓΗ (21.45) <span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">153.</span>ΛΟΥΝΤΟΓΚΟΡΕΤΣ-ΣΤΕΑΟΥΑ (21.45)<span style="color:#0000FF"> 1</span></p>

<p><span style="color:#FF0000">154</span>.ΜΑΛΜΕ -ΣΑΛΤΣΜΠΟΥΡΓΚ (21.45)<span style="color:#DAA520"> ΓΚΟΛ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΟΥΕΦΑ Γιουρόπα Λιγκ', '1409217812', 'GL.jpg', '<p><span style="color:#FF0000">189</span>. ΛΟΚΟΜΟΤΙΒ ΜΟΣΧΑΣ - ΑΠΟΛΛΩΝ ΛΕΜΕΣΟΥ (18.00)<span style="color:#0000FF"> 1</span></p>

<p><span style="color:#FF0000">170.</span> ΚΡΑΣΝΤΟΝΤΑΡ-ΣΟΣΙΕΔΑΔ (19.00) <span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">171.</span>ΝΕΦΤΣΙ-ΠΑΡΤΙΖΑΝ (19.00)<span style="color:#0000FF"> Χ</span></p>

<p><span style="color:#FF0000">172</span>.ΟΜΟΝΟΙΑ-ΝΤΙΝΑΜΟ ΜΟΣΧΑΣ (19.00) <span style="color:#DAA520">ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">191</span>.ΜΕΤΑΛΙΣΤ-ΡΟΥΧ(19.00) <span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">173.</span>ΠΑΟΚ-ΖΙΜΠΡΟΥ (19.15) <span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">184</span>. ΑΣΤΡΑ-ΛΥΩΝ (19.45) <span style="color:#0000FF">2</span></p>

<p><span style="color:#FF0000">174.</span>ΡΟΣΤΟΦ-ΤΡΑΜΠΖΟΣΠΟΡ (20.00) <span style="color:#DAA520">UNDER</span></p>

<p><span style="color:#FF0000">175</span>.ΣΕΡΙΦ- ΡΙΕΚΑ(20.00) <span style="color:#DAA520">ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">176</span>.ΣΟΛΙΓΚΟΡΣΚ-ΑΙΝΤΧΟΒΕΝ (20.00) <span style="color:#0000FF">2</span></p>

<p><span style="color:#FF0000">178</span>.ΤΒΕΝΕΤΕ -ΚΑΡΑΜΠΑΓΚ(20.30) <span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">190</span>.ΜΑΚΑΜΠΙ-ΑΣΤΕΡΑΣ ΤΡΙΠΟΛΗΣ (20.00 1</p>

<p><span style="color:#FF0000">187.</span>ΙΝΤΕΡ-ΣΤΙΑΝΑΡΤ- (21.45)1</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις ημέρας για ταμείο ', '1409327454', 'images_2.jpeg', '<p><span style="font-size:14px"><span style="color:#FF0000">108.</span> ΛΑΒΑΛ-ΑΖΑΞΙΟ (21.00) <span style="color:#DAA520">ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">112.</span> ΣΑΤΟΡΟΥ-ΟΡΛΕΑΝ (21.00) <span style="color:#DAA520">ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">128</span>. ΜΑΡΣΕΙΓ-ΝΙΣ (21.30) <span style="color:#0000FF">1</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">134</span>.ΝΤΕΡΙ-ΣΕΝΤ ΠΑΤΡΙΚΣ (21.45) <span style="color:#0000FF">2</span></span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις ημέρας για ταμείο ', '1409393393', 'images_2_0.jpeg', '<p><span style="font-size:14px"><span style="color:#FF0000">164.</span> ΛΕΒΕΡΚΟΥΖΕΝ-ΧΕΡΤΑ (16.30) <span style="color:#0000FF">1</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">249</span>.ΜΟΝΑΚΟ-ΛΙΛ (18.00) <span style="color:#0000FF">1</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">261</span>.ΣΑΛΚΕ-ΜΠΑΓΕΡΝ (19.30) <span style="color:#0000FF">2</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">266</span>.ΑΘΛΕΤΙΚ ΜΠΙΛΜΠΑΟ- ΛΕΒΑΝΤΕ&nbsp;(20.00) <span style="color:#0000FF">1</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Μουντομπάσκετ 2014-Προτάσεις', '1409669858', 'download.jpeg', '<p><span style="color:#DAA520">734</span>. Ν ΚΟΡΕΑ -ΣΛΟΒΕΝΙΑ (21.00) &nbsp;<span style="color:#FF0000">ΟΒΕΡ</span></p>

<p><span style="color:#DAA520">735.&nbsp;</span>ΦΙΝΛΑΝΔΙΑ- ΔΟΜΙΝΙΚΑΝΗ ΔΗΜ. (22.30) &nbsp;<span style="color:#0000FF">1</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Διεθνής φιλικά ..', '1409755255', 'Friendly-Match.jpg', '<p><span style="color:#FF0000">130</span>. ΛΕΤΟΝΙΑ- ΑΡΜΕΝΙΑ (20.45) <span style="color:#DAA520">2-3 ΓΚΟΛ&nbsp;</span></p>

<p><span style="color:#FF0000">131.</span>ΔΑΝΙΑ-ΤΟΥΡΚΙΑ (21.00) <span style="color:#DAA520">UNDER 3.5&nbsp;</span></p>

<p><span style="color:#FF0000">132.</span> ΤΣΕΧΙΑ-ΗΠΑ(21.15)<span style="color:#DAA520"> 2-3 ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">133</span>. ΓΕΡΜΑΝΙΑ-ΑΡΓΕΝΤΙΝΗ (21.45) <span style="color:#0000FF">1</span></p>

<p><span style="color:#FF0000">134.</span>ΑΓΓΛΙΑ-ΝΟΡΒΗΓΙΑ(22.00) <span style="color:#0000FF">Χ2</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Τριάδα ταμείου', '1415641093', 'images_173.jpg', '<p><span style="color:#FF0000">375.</span> ΜΟΝΑΧΟ 1860 - ΦΟΡΤΟΥΝΑ ΝΤΥΣ. <span style="color:#DAA520">Χ2</span></p>

<p><span style="color:#FF0000">376. </span>ΝΑΝΣΙ-ΚΡΕΤΕΙΓ&nbsp;&nbsp;<span style="color:#DAA520">&nbsp; ΓΚΟΛ ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">378. </span>ΡΙΟ ΑΒΕ - ΑΚΑΔΕΜΙΚΑ&nbsp;&nbsp; <span style="color:#DAA520">1</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Απίστευτη νέα 2winbet.gr', '1415961457', '10600572_806422662729634_2481527007611437590_n.jpg', '<p>ΜΠΟΝΟΥΣ ΠΡΩΤΗΣ ΚΑΤΑΘΕΣΗΣ 50% ΕΩΣ 200 ΕΥΡΩ Για να διεκδικήσετε το μπόνους Επιστροφής, στείλτε ένα e-mail για να support@2winbet.gr με θέμα “Επιστροφή” και “ταυτότητα και το όνομα χρήστη σας» σε αυτό. Το μπόνους θα προστεθεί μέσα σε 24 ώρες! ΕΞΠΡΕΣ ΜΠΟΝΟΥΣ Το μπόνους είναι μόνο για Παρολί στοιχήματα. Το Bonus υπολογίζεται με βάση τη νίκη σε όλα τα γεγονότα που περιλαμβάνονται στο στοίχημα. Για παράδειγμα, ένα στοίχημα με 3 εκδηλώσεις σας δίνει ένα μπόνους 3%, ένα στοίχημα με 4 εκδηλώσεις – μπόνους 4%, κ.λπ. Rakeback Bonus H <a href="http://2winbet.gr/?btag=1013" target="_blank">http://2winbet.gr/?btag=1013</a>&nbsp;είναι στην ευχάριστη θέση να ανακοινώσει ότι έως και το 50% των rakes από παίκτες που έφεραν σε τραπέζια μετρητών θα δοθεί πίσω σε αυτούς. Τι είναι το rakeback? Υπέροχη ερώτηση! Rake είναι η υπολογιζόμενη αμοιβή που η 2winbet παίρνει για τα τραπέζια μετρητών. Bonus Επιστροφής Χρημάτων Cashback είναι η προώθηση μας για τους παίκτες του καζίνο. Στο Cashback συμμετέχει κάθε πελάτης που έχει χάσει σε παιχνίδια Καζίνο ένα ποσό ίσο προς 2 EUR και άνω. Αυτή η προσφορά ισχύει για όλα τα παιχνίδια, τα οποία διατίθενται στην εκτός Poker και Backgammon. Όροι και προϋποθέσεις: Κάθε Μέρα στις 12:00 (GMT + 4) πελάτης θα πάρει το Cashback. Cashback υπολογίζεται με βάση το 5% της απώλειας ποσού σε όλα τα παιχνίδια (εκτός Gaminator) και το Live Ντίλερ παιχνίδια και το 5% της παραγόμενης γκανιότας σε Παιχνίδια επιδεξιότητας (Τάβλι, κλπ).</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά Ευρωπαικού πρωταθλήματος', '1415962513', '21173419b620eb0221d640b287864b1b_xl.jpg', '<p><span style="color:#FF0000">134.</span> ΓΕΩΡΓΙΑ- ΠΟΛΩΝΙΑ (19.00) &nbsp;<span style="color:#FF8C00"> Χ</span></p>

<p><span style="color:#FF0000">137.</span> ΕΛΛΑΔΑ-ΝΗΣΟΙ ΦΕΡΟΕΣ (21.45)<span style="color:#FF8C00"> ΗΜ ΟΒΕΡ 1.5</span></p>

<p><span style="color:#FF0000">142</span>. ΣΚΩΤΙΑ - ΙΡΛΑΝΔΙΑ (21.45) <span style="color:#FF8C00">1</span></p>

<script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=PNG-logo-90x60&id=49''></script>
<div id=''vivaswfid49''></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά Ευρωπαικού πρωταθλήματος', '1416074810', '21173419b620eb0221d640b287864b1b_xl.jpg', '<p>149.ΕΛΒΕΤΙΑ-ΛΙΘΟΥΑΝΙΑ (21.45) &nbsp;ΗΜ/Τ 1-1</p>

<p>150.ΙΣΠΑΝΙΑ-ΛΕΥΚΟΡΩΣΙΑ (21.45) ΗΜ/Τ 1-1</p>

<p>151.ΜΑΥΡΟΒΟΥΝΙΟ-ΣΟΥΗΔΙΑ (21.45) ΗΜ /Τ Χ/2</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Μπάσκετ euroleague', '1416477795', '1.jpg', '<p><span style="color:#FF0000">ΟΛΥΜΠΙΑΚΟΣ - ΒΑΛΕΝΘΙΑ (19.45) </span>&nbsp; <span style="color:#DAA520">ΠΟΝΤΟΙ ΟΜΑΔΑΣ 1 ΟΒΕΡ 77,5&nbsp;</span></p>

<p><span style="color:#FF0000">ΜΠΑΓΕΡΝ- ΜΟΝΑΧΟΥ -ΜΠΑΡΤΣΕΛΟΝΑ &nbsp;(21.15)</span><span style="color:#DAA520"> ΣΥΝΟΛΟ ΠΟΝΤΩΝ ΟΒΕΡ 157.5</span></p>

<p>&nbsp;</p>

<p><span style="color:#0000CD">Στις καλύτερες αποδόσεις στην :</span></p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>







');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Επίσκεψη στο promo shop της 2winbet.gr ', '1416480593', '10408927_808661925839041_9016780712920805191_n.jpg', '<p>Προτότυπο &nbsp;χρήσιμο και πολύ εξυπηρετικό το περίπτερο της&nbsp; &nbsp;&nbsp;</p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>στη Πλάτεία Ελευθερίας στο Κορυδαλλό.Η επισκεψή σας θα σας αποφέρει ενθουσιασμό για τις προσφορές και τα bonus και πλήρη ενημέρωση από το εξειδικευμένο προσωπικό. Σας το συστήνουμε ανεπιφυλαχτα!!! ');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Aναβολή όλων των πρωταθλημάτων                     ', '1416513495', 'superleague_logo_2_0.jpg', '<p>Η ΕΠΟ με ανακοίνωσή της ξεκαθαρίζει ότι δεν συντρέχει λόγος για αναίρεση της απόφασης για αναβολή όλων των πρωταθλημάτων και ως εκ τούτου δεν θα διεξαχθεί κανένα πρωτάθλημα ποδοσφαίρου στην Ελλάδα το προσεχές σαββατοκύριακο.</p>

<p>Το αίτημα της ομοσπονδίας για υπογραφές στο έγγραφο που απέστειλε σε όλες τις ομάδες δεν ικανοποιήθηκε και ως εκ τούτου, η ΚΕΔ δεν θα ορίσει διαιτητές για τα δύο επαγγελματικά πρωταθλήματα, ώστε να διεξαχθούν η 11η αγωνιστική της Super League και η 6η της Football League το προσεχές Σαββατοκύριακο.</p>

<p><strong>Αναλυτικά η ανακοίνωση:</strong></p>

<p><em>“Από την Ελληνική Ποδοσφαιρική Ομοσπονδία ανακοινώνεται ότι μετά τις εξελίξεις των τελευταίων ημερών δεν συντρέχει κανένας απολύτως λόγος αναίρεσης της απόφασης που έλαβε το διοικητικό συμβούλιο στην έκτακτη συνεδρίασή του στις 14/11/2014, για μη ορισμό διαιτητών από την ΚΕΔ/ΕΠΟ σε όλους τους αγώνες των εθνικών πρωταθλημάτων (Super League, Football League, Γ’ Εθνική, Πρωταθλήματα Γυναικών, Πρωτάθλημα προεπιλογής Εθνικών Ομάδων, Πρωταθλήματα Νέων ΠΑΕ).</em></p>

<p><em>Η ΕΠΟ έλαβε τη συγκεκριμένη απόφαση με μοναδικό γνώμονα την προστασία των εμπλεκομένων, με οποιαδήποτε ιδιότητα, στο ελληνικό ποδόσφαιρο, ωστόσο τα απαιτούμενα πρώτα βήματα δεν έγιναν, ούτε από την πλευρά της πολιτείας, ούτε και από αυτή των ΠΑΕ, άρα δεν προκύπτει και ο λόγος διαφοροποίησης της θέσης της Ομοσπονδίας”.</em></p>

<p>&nbsp;</p>

<p>Πηγή: contra.gr</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('B'' Γαλλίας Προτάσεις', '1416559483', '600_400_auto_100_france.png', '<p><span style="color:#FF0000">104.</span> ΑΖΑΞΙΟ-ΑΝΖΕ <span style="color:#0000CD">(21.45)</span><span style="color:#DAA520"> goal goal&nbsp;</span></p>

<p><span style="color:#FF0000">109</span>. ΝΙΟΡ- ΤΟΥΡ<span style="color:#0000CD"> (21.45)</span><span style="color:#DAA520"> 2-3 goal</span></p>

<p><span style="color:#FF0000">111.</span>ΟΣΕΡ-ΣΑΤΟΡΟΥ<span style="color:#0000CD"> (21.45)</span> <span style="color:#DAA520">goal goal&nbsp;</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πάμε ταμείο με το κουπόνι Παρασκευής', '1416560286', 'stoihima_3.jpg', '<p><span style="color:#FF0000">101</span>. ΜΠΟΧΟΥΜ-ΑΑΛΕΝ <span style="color:#0000CD">(19.30)</span> <span style="color:#DAA520">ΓΚΟΛ ΓΚΟΛ&nbsp;</span></p>

<p><span style="color:#FF0000">119.</span>ΚΑΙΖΕΡΣΛΑΟΥΤΕΡΝ-ΝΤΑΡΜΣΤΑΝΤ<span style="color:#0000CD"> (21.30</span>) <span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">123</span>.ΑΘΛΕΤΙΚ ΜΠΙΛΜΠΑΟ- ΕΣΠΑΝΙΟΛ<span style="color:#0000CD"> (21.45)</span> <span style="color:#DAA520">1</span></p>

<p>&nbsp;</p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σαββάτου', '1416649142', 'stoihima_3.jpg', '<p><span style="color:#FF0000">145. </span>ΧΑΝΤΕΡΣΦΙΛΝΤ-ΣΕΦΙΛΝΤ ΓΟΥΕΝ <span style="color:#0000CD">(14.15)</span> <span style="color:#DAA520">ΓΚΟΛ ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">164</span>. ΓΚΛΑΝΤΜΠΑΧ-ΑΙΝΤ. ΦΡΑΝΚ <span style="color:#0000CD">(16.00) </span><span style="color:#DAA520">ΑΣΣΟΣ</span></p>

<p><span style="color:#FF0000">170.</span> ΛΕΣΤΕΡ- ΣΑΑΝΤΕΡΛΑΝΤ <span style="color:#0000CD">(17.00)</span> <span style="color:#DAA520">ΑΣΣΟΣ</span></p>

<p><span style="color:#FF0000">243.</span> ΜΠΑΣΤΙΑ-ΛΥΩΝ<span style="color:#0000CD"> (18.00) </span><span style="color:#DAA520">&nbsp;ΙΧ ΔΕ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Αρσενάλ-Μάντσεστερ Γιουνάϊτεντ (19.30)', '1416649443', 'arsenal-man-united.jpg', '<p><span style="color:#0000CD"><strong>Η Άρσεναλ είναι αήττητη στα 23 τελευταία ματς εντός έδρας για το πρωτάθλημα*</strong></span></p>

<p><span style="color:#0000CD"><strong>*Η Γιουνάϊτεντ αγνοεί τη νίκη εκτός έδρας στο φετινό πρωτάθλημα έπειτα από 5 αγώνες</strong></span></p>

<p><strong><span style="color:#FF0000">Άρσεναλ:</span>&nbsp;</strong>Πολύ κακή εμφάνιση για την Άρσεναλ στο εκτός έδρας παιχνίδι με τη Σουόνσι όπου ηττήθηκε με 2-1. Το ματς δεν είχε και τόσο καλό ρυθμό στο πρώτο ημίχρονο με τις δύο ομάδες να μη μπορούν να δημιουργήσουν ιδιαίτερες φάσεις. Στην επανάληψη, η Άρσεναλ κατάφερε και πήρε προβάδισμα με τον μόνιμο φετινό της σκόρερ Σάντσεζ (63’) και στη συνέχεια «χαλάρωσε» αρκετά, κάτι που η Σουόνσι το εκμεταλλεύτηκε και έκανε την ανατροπή με τους Σίγκουρντσον (75’) και Γκομίς (78’) και άφησε την Άρσεναλ στα «κρύα του λουτρού».</p>

<p>«Ο Γουέλμπεκ χρειαζόταν μια ευκαιρία απ’ τη Γιουνάϊτεντ και δείχνει με τις τελευταίες του εμφανίσεις ότι είναι φοβερό παίχτης» δήλωσε ο Βενγκέρ θέλοντας να δώσει ώθηση στον επιθετικό του ο οποίος αντιμετωπίζει την πρώην του ομάδα.</p>

<p>Η Άρσεναλ πάντως, βρίσκεται στην 6η&nbsp;θέση με 17 βαθμούς έπειτα από 11 αγωνιστικές με τα παράπονα για τον Βενγκέρ και την ομάδα του να έχουν ήδη αρχίσει και να ακούγονται σενάρια για αλλαγή στον πάγκο των «Κανονιέρηδων». Η Άρσεναλ πάντως υποδέχεται την Τετάρτη τη Ντόρτμουντ για την πέμπτη αγωνιστική του Τσάμπιονς Λιγκ.</p>

<p><strong>Bet&nbsp;</strong><strong>info:&nbsp;</strong>Έχει 4/5 over2.5 εντός έδρας στο πρωτάθλημα</p>

<p><strong>Απουσίες:&nbsp;</strong>Τραυματίες είναι οι Ντεμπουσί, Οζίλ, Κοσιελνί, Οσπίνα και Ντιαμπί.</p>

<p><strong>Πιθανή ενδεκάδα (4-2-3-1):&nbsp;</strong>Σέζνι – Τσέϊμπερς, Μερτεζάκερ, Μονρεάλ, Γκιμπς – Ράμσεϊ, Φλαμινί – Τσάμπερλεϊν, Σάντσεζ, Καθόρλα – Γουέλμπεκ</p>

<p><span style="color:#FF0000"><strong>Μάντσεστερ Γιουνάϊτεντ:</strong>&nbsp;</span>Πήρε την «αγχωτική» νίκη κόντρα στην Κρίσταλ Πάλας εντός έδρας με 1-0. Η Γιουνάϊτεντ είχε τον έλεγχο του αγώνα απ’ την αρχή του παιχνιδιού, έχασε ευκαιρίες αλλά δεν κατάφερε κάτι στο πρώτο ημίχρονο. Στην επανάληψη, το παιχνίδι συνεχίστηκε στον ίδιο ρυθμό με τον Μάτα (67’) να κάνει το 1-0 το οποίο ήταν και το τελικό αποτέλεσμα ενώ η Γιουνάϊτεντ δεν απειλήθηκε σχεδόν καθόλου.</p>

<p>«Είναι το πρώτο μου ματς εναντίων της Άρσεναλ σαν προπονητής της Μάντσεστερ ενώ την είχα αντιμετωπίσει ως προπονητής της Μπαρτσελόνα το 1999 όπου και τότε ήταν προπονητής ο Βενγκέρ. Θαυμάζω τον τρόπο παιχνιδιού του» είπε μεταξύ άλλων ο Φαν Χαλ με την ομάδα του να ψάχνει τη νίκη για να πλησιάσει στις ψηλές θέσεις και να προσπεράσει τη σημερινή της αντίπαλο.</p>

<p><strong>Bet&nbsp;</strong><strong>info:&nbsp;</strong>Έχει 3 συνεχόμενα under2.5</p>

<p><strong>Απουσίες:&nbsp;</strong>Αρκετά προβλήματα αφού τραυματίες είναι οι Ρόχο, Μπλιντ, Έβανς και Τζόουνς. Κανονικά προλαβαίνουν οι Ντε Χέα, Ντι Μαρία και Κάρικ. Αμφίβολοι είναι οι Φαλκάο και Ράφαελ.</p>

<p><strong>Πιθανή ενδεκάδα (4-2-3-1):&nbsp;</strong>Ντε Χέα – Βαλένσια, Σμόλινγκ, Μπλάκετ, Σο – Κάρικ, Φελαϊνι – Γιανουζάϊ, Ρούνεϊ, Ντι Μαρία – Φαν Πέρσι</p>

<p><strong><span style="color:#DAA520">Εκτίμηση:</span>&nbsp;</strong><span style="background-color:rgb(255, 255, 255); color:rgb(68, 68, 68); font-family:helvetica,arial,sans-serif; font-size:14px">Το ντέρμπι της αγωνιστικής διεξάγεται στο «Έμιρεϊτς» με τις δύο ομάδες να ψάχνουν τη νίκη για να πλησιάσουν στην κορυφή. Πολλά προβλήματα και στις δύο ομάδες αλλά η Άρσεναλ δείχνει να επηρεάζεται περισσότερο από αυτά. Πολλά γκολ περιμένω από το ματς με τις δύο ομάδες να παίζουν επιθετικό ποδόσφαιρο</span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακής για την Serie A ', '1416735425', 'serie-a-e1412376403246.png', '<p><span style="color:#FF0000">302.</span> ΤΟΡΙΝΟ-ΣΑΣΟΥΟΛΟ<span style="color:#0000FF"> (13.30) </span>&nbsp; <span style="color:#DAA520">ΓΚΟΛ ΓΚΟΛ&nbsp;</span></p>

<p><span style="color:#FF0000">321</span>. ΒΕΡΟΝΑ-ΦΙΟΡΕΝΤΙΝΑ<span style="color:#0000FF"> (16.00)</span> &nbsp;<span style="color:#DAA520">ΝΟ ΓΚΟΛ</span>&nbsp;</p>

<p><span style="color:#FF0000">322.</span> ΝΑΠΟΛΙ- ΚΑΛΙΑΡΙ <span style="color:#0000FF">(16.00)</span> <span style="color:#DAA520">ΟΒΕΡ 2.5&nbsp;</span></p>

<p><span style="color:#FF0000">323</span>. ΟΥΝΤΙΝΕΖΕ- ΚΙΕΒΟ <span style="color:#0000FF">(16.00)</span> <span style="color:#DAA520">2-3 ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">324</span>. ΠΑΡΜΑ-ΕΜΠΟΛΙ <span style="color:#0000FF">(16.00)</span> <span style="color:#DAA520">ΟΒΕΡ 2.5&nbsp;</span></p>

<p><span style="color:#FF0000">325</span>.ΤΣΕΖΕΝΑ-ΣΑΜΠΤΟΡΙΑ<span style="color:#0000FF"> (16.00) </span>&nbsp;<span style="color:#DAA520">2</span></p>

<p><span style="color:#FF0000">359</span>. ΜΙΛΑΝ-ΙΝΤΕΡ <span style="color:#0000FF">(21.45)</span> <span style="color:#DAA520">ΙΧ ΔΕ</span></p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Δευτέρα με φτωχό κουπόνι ..', '1416844877', 'stoihima_3.jpg', '<p><span style="color:#FF0000">374.</span> ΜΠΟΥΡΣΑΡΣΠΟΡ-ΦΕΝΕΡΜΠΑΧΤΣΕ <span style="color:#0000FF">(20.00)</span> <span style="color:#DAA520">1Χ ΔΕ</span></p>

<p><span style="color:#FF0000">377</span>.ΦΟΡΤΟΥΝΑ ΝΤΙΣΕΛΝΤ.-ΓΚΡΟΪΤΕΡ ΦΙΡΤ<span style="color:#0000FF"> (21.15)</span><span style="color:#DAA520"> ΓΚΟΛ ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">378.</span>ΤΡΟΥΑ-ΝΑΝΣΙ <span style="color:#0000FF">(21.30)</span> <span style="color:#DAA520">2-3 ΓΚΟΛ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('21:45 ΜΑΝΤΣΕΣΤΕΡ ΣΙΤΙ – ΜΠΑΓΕΡΝ', '1416904881', 'bayern-city-720x350.jpg', '<p>Προϊστορία: 2-0-3<br />
Α’ γύρος: ΜΠΑΓΕΡΝ-ΜΑΝΤΣΕΣΤΕΡ ΣΙΤΙ 1-0</p>

<p><span style="color:#FF0000"><strong>ΜΑΝΤΣΕΣΤΕΡ ΣΙΤΙ</strong></span>: Απέδειξε για ακόμα ένα παιχνίδι ότι δεν είναι σε καλή κατάσταση, αφού χρειάστηκε να ανατρέψει το ματς με τη Σουόνσι στο Έτιχαντ, για να επιστρέψει στις νίκες. Ο Αγουέρο δεν ήταν αυτός που έδωσε πάλι τις λύσεις, αλλά επιτέλους σκόραρε ο Γιόβετιτς (19’), κάτι που είχε να κάνει από τις 25 Αυγούστου, ενώ την ανατροπή ολοκλήρωσε ο Τουρέ, ο οποίος επίσης χρειαζόταν ένα γκολ, μετά την κριτική που είχε δεχτεί. Παρέμεινε αήττητη για 3η αγωνιστική (2-1-0) και διατηρήθηκε στο -8 από την Τσέλσι. Δεν είναι πάντως στα καλύτερά της, αφού αυτή ήταν μόλις η 2η νίκη της σε όλες τις διοργανώσεις στα 7 τελευταία, για την οποία επίσης ίδρωσε, όπως είχε γίνει και στην άλλη, στη νίκη στο ντέρμπι με τη Γιουνάιτεντ. Σε αυτό το κλίμα πηγαίνει στον «τελικό» με τη Μπάγερν, αφού με ήττα σήμερα μένει οριστικά εκτός συνέχεια στο Τσάμπιονς Λιγκ, ενώ θα είναι πλέον πολύ δύσκολη ακόμα και η 3η θέση. Είναι αντιμέτωπη για δεύτερη σερί χρονιά κόντρα στη Μπάγερν σε φάση ομίλων και τρίτη τα τελευταία 4 χρόνια. Την πρώτη φορά (2012) επικράτησε εντός έδρας με 2-0, ενώ πέρυσι έχασε με 2-3, με το σκορ να την κολακεύει βάση εμφάνισης. Στον πρώτο πρώτο γύρο έχασε με 0-1 στο Μόναχο. Εκτός ο αριστερός μπακ Κολάροφ (7 συμμ./1 ασίστ).</p>

<p>Τελευταία 5: 2-1-2</p>

<p><span style="color:#FF0000"><strong>ΜΠΑΓΕΡΝ</strong>:</span> Δεν μπορούμε να πούμε ότι κάνει περίπατο ακόμα, αλλά δε θα αργήσει να γίνει. Τρίτη σερί νίκη και αήττητο 12 αγωνιστικών για τους Βαυαρούς (9-3-0), με την εύκολη εντός έδρας νίκη επί της Χόφενχαϊμ με 4-0 (Γκέτσε 23’, Λεβαντόφσκι 40’, Ρόμπεν, Ρόντε 86’). Στην Ευρώπη πηγαίνει εξίσου καλά, έχοντας κάνει το 4 στα 4 και είναι ήδη στην επόμενη φάση. Μοναδικό μελανό σημείο φέτος η απώλεια του Σούπερ Καπ Γερμανίας το καλοκαίρι, μετρώντας από τότε αήττητο 17 αγώνων σε όλες τις διοργανώσεις (14-3-0), με 45 γκολ υπέρ και μόλις 6 κατά. Εκτός οι κίπερ Σταρκ, Ρέινα, ο αρχηγός Λαμ (11 συμμ./2 γκ./2 ασίστ), ο αριστερός μπακ Αλάμπα (10 συμμ./1 ασίστ), ο κεντρικός αμυντικός Μπαντστούμπερ (3 συμμ.), ο κεντρικός μέσος Τιάγκο Αλκάνταρα, ο αμυντικός μέσος Χάβι Μαρτίνεθ και ο επιθετικός Πιζάρο (5 συμμ.).</p>

<p>Τελευταία 5: 5-0-0</p>

<p><strong>Προγνωστικά</strong>: Δε δείχνει ικανή να κοντράρει τη Μπάγερν αυτή τη στιγμή η Σίτι, αλλά δεν μπορεί να κάνει κι αλλιώς. Εξαιρετική η αμυντική γραμμή των Βαυαρών, αλλά η παρέα του Αγουέρο είναι ικανή να προκαλέσει ζημιές.&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('21:45 ΣΑΛΚΕ – ΤΣΕΛΣΙ', '1416905117', 'chelsea-schalke-720x350.jpg', '<p>Προϊστορία: 0-2-3<br />
Α’ γύρος: ΤΣΕΛΣΙ-ΣΑΛΚΕ 1-1</p>

<p><strong>ΣΑΛΚΕ</strong>: Επέστρεψε στις νίκες και έκοψε τη φόρα της 2ης Βόλφσμπουργκ, επικρατώντας εντός έδρας με 3-2. Πολύ δυνατό ξεκίνημα στο παιχνίδι για τους βασιλικούς μπλε, που προηγήθηκαν με 3-0, χάρη σε δύο προσωπικά γκολ του Τσούπο-Μοτίνγκ (10’, 22’) και με ένα απευθείας φάουλ του Φουκς στο 25’ από το κέντρο του γηπέδου, που ξεγέλασε τον αντίπαλο κίπερ. Οι φιλοξενούμενοι όμως πήραν τον έλεγχο του παιχνιδιού, μείωσαν στο 36’ και στο 73’ και η Σάλκε θα πρέπει να αισθάνεται τυχερή που δεν ισοφαρίστηκε. Ανέβηκε έτσι στην 7η θέση και πλησίασε στον πόντο τις προνομιούχες θέσεις, με τον με τον Ντι Ματέο όμως να μην έχει φέρει τις μεγάλες αλλαγές στην ομάδα, μετρώντας 4 νίκες και 3 ήττες σε όλες τις διοργανώσεις από τη στιγμή που ανέλαβε. «Εκδίκηση» πάντως ψάχνει ο Ιταλός από την Τσέλσι, στην οποία εκτός από παίχτης για 6 χρόνια (1996-2002), βρέθηκε και στον πάγκο της για 8 μήνες. Ανέλαβε την ομάδα τον Μάρτιο του 2012, μετά την απομάκρυνση του Βίλλας-Μπόας και την οδήγησε στην μεγαλύτερη στιγμή στην ιστορία της, κατακτώντας το Τσάμπιονς Λιγκ δύο μήνες αργότερα, ενώ δύο εβδομάδες πριν είχε κατακτήσει και το κύπελλο. Απολύθηκε όμως μετά από 6 μήνες και τον αποκλεισμό της ομάδας από το Τσάμπιονς Λιγκ. Εκτός ο κίπερ Γκίφερ, ο κεντρικός αμυντικός Κολάτσινατς (1 συμμ.), ο κεντρικός αμυντικός Γκορέτσκα και οι μεσοεπιθετικοί Ντράξλερ (8 συμμ./2 γκ./1 ασίστ), Φαρφάν.</p>

<p>Τελευταία 5: 2-0-3</p>

<p><strong>ΤΣΕΛΣΙ</strong>: Πάτησε γκάζι μόνο για 25’ λεπτά, διάστημα στο οποίο πήρε εύκολα το προβάδισμα κόντρα στη Γουέστ Μπρομ. Το ματς ουσιαστικά τελείωσε στο 29’, όταν οι φιλοξενούμενοι έμειναν με 10’ και παρά τις ευκαιρίες που είχε, το σκορ δεν άλλαξε ως το τέλος. Παρέμεινε έτσι μόνη πρώτη και αύξησε τη διαφορά από τη 2η θέση στους 7 βαθμούς, μετά την ισοπαλία της Σαουθάμπτον χθες βράδυ. Ο Μουρίνιο πάντως έκρουσε τον κώδωνα του κινδύνου, αφού φοβάται τον εφησυχασμό και δε θέλει να χάσει τη διαφορά που έχει χτίσει από τους μεγάλους αντιπάλους της. Στο Τσάμπιονς Λιγκ παραμένει αήττητη μετά από 4 αγωνιστικές (2-2-0) και θέλει μόνο ένα βαθμό σήμερα για να εξασφαλίσει την πρώτη θέση. Έχει αναμετρηθεί συνολικά άλλες 5 φορές με τη Σάλκε, με την οποία βρέθηκε και στην περσινή φάση των ομίλων. Και στις δύο αναμετρήσεις πέρυσι επικράτησε με 3-0. Συνολικά είναι αήττητη και στις 5 αναμετρήσεις (3-2-0). Εκτός ο αριστερός μπακ Ακέ.</p>

<p>Τελευταία 5: 4-1-0</p>

<p><strong>Πρόταση Πάμε Στοίχημα</strong>: Ιδιαίτερο ματς για τον Ντι Ματέο το σημερινό, που δε θέλει με τίποτα να χάσει από την Τσέλσι. Η ομάδα του Μουρίνιο είναι το φαβορί, αλλά έχει χάσει τη φρεσκάδα της και μία μεσοβέζικη ισοπαλία δε θα είναι έκπληξη</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('champions league', '1416905825', 'arheio_lipsis.jpg', '<p><span style="color:#FF0000"><strong>ΤΣΣΚΑ ΜΟΣΧΑΣ (3η - 4β)&nbsp;</strong></span>- Με την ευχή η ομάδα του να έχει αποβάλει όποια ελαττώματα παρουσίασε στη Ρώμη έκλεισε τη συνέντευξη Τύπου ο Σλούτσκι, ο οποίος αναγνώρισε τη βελτίωση της ομάδας του και την υποψηφιότητα που θέτει για τη 2η θέση του ομίλου. Στο τελευταίο παιχνίδι της βέβαια πρέπει να πάει στο Μόναχο οπότε ακόμα και μια νίκη επί της Ρώμη δεν επιτρέπει... φοβερούς πανηγυρισμούς. Εκτός και αν κερδίσει με 4-0 ή μεγαλύτερη διαφορά τερμάτων. Η ΤΣΣΚΑ ηττήθηκε από την Κράσνονταρ (1-2 εκτός) για το ρωσικό πρωτάθλημα. Δέχτηκε δύο γκολ από τα αποδυτήρια (4ο και 6ο λεπτό), μείωσε νωρίς (14ο), αλλά το σκορ παρέμεινε έτσι μέχρι το τέλος. Γνωστή ήταν η απουσία του Ελμ (Ε), όχι όμως και του πολύτιμου μέσου Νάτσο, που αποτελεί πολύ σημαντική απώλεια της τελευταίας στιγμής.</p>

<p><strong><span style="color:#0000FF">ΡΟΜΑ (2η - 4β) </span>-&nbsp;</strong>Προηγείται των Ρώσων χάρη στο 5-1 της πρεμιέρας. Το συγκεκριμένο σκορ της δίνει προβάδισμα αν αποσπάσει ισοπαλία και την πρόκριση αν κερδίσει απόψε στη Μόσχα. Απαιτείται δηλαδή μια δεύτερη απόδειξη για την υπεροχή των Ιταλών, αλλά αυτή φορά καλούνται να το πετύχουν απέναντι σε μια βελτιωμένη και πιο διαβασμένη ομάδα. Συν ότι οι ίδιοι προέρχονται από δύο σερί ήττες από την Μπάγερν, όπου συνειδητοποίησαν πόσο μακριά βρίσκονται από την ελίτ του ευρωπαϊκού ποδοσφαίρου. Αν καταφέρουν και αποβάλλουν τη συγκεκριμένη σκέψη, τότε η ψυχολογία της ανωτερότητας θα επικρατήσει. Σημασία βέβαια έχει το αγωνιστικό κομμάτι και εκεί ο Γκαρσιά αντιμετωπίζει πολλά προβλήματα. Εκτός μάχης είναι οι Καστάν, Μαϊκόν, Τοροσίδης και Μπιβά από την άμυνα, όπως επίσης ο μέσος Στρούτμαν και ο φορ Μποριέλο.</p>

<p>&nbsp;</p>

<p><strong>ΕΚΤΙΜΗΣΗ / ΣΤΟΙΧΗΜΑ - Αν και δε συνηθίζουμε να ποντάρουμε στους αγώνες που διεξάγονται σε ουκρανικό ή ρωσικό έδαφος νωρίτερα από τους υπόλοιπους, ο τρέχων αποτελεί εξαίρεση. Πιστεύουμε στη Ρόμα και στην επικράτησή της. Η ΤΣΣΚΑ ίσως αγχωθεί με την ιδέα ότι θέλει τη νίκη και η Ρόμα έχει την ικανότητα να το εκμεταλλευτεί. Καθοριστική η απουσία του Νάτσο</strong></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES (' ΑΠΟΕΛ - ΜΠΑΡΤΣΕΛΟΝΑ', '1416905958', 'arheio_lipsis.jpg', '<p><strong><span style="color:#FF0000">ΑΠΟΕΛ (4ος - 1β)</span>&nbsp;</strong><span style="background-color:rgb(206, 212, 222); font-family:tahoma,arial,helvetica,sans-serif; font-size:11px">-</span><span style="font-family:tahoma,arial,helvetica,sans-serif; font-size:11px"> Δεν έχει κερδίσει ακόμα στη φάση των ομίλων, όμως η πορεία του είναι από... μόνη της επιτυχημένη αν αναλογιστεί κανείς την πορεία του στα προκριματικά, αλλά και τις εμφανίσεις του ως τώρα. Δεν είναι τυχαίο ότι ηττήθηκε και στα τρία ματς με Μπαρτσελόνα και Παρί Σεν Ζερμέν (2) με το ίδιο σκορ, 0-1. Δε βρίσκει εύκολα δίχτυα, το έκανε όμως όταν ο αντίπαλος ήταν πιο βατός. Το 1-1 μάλιστα με τον Άγιαξ στο ΓΣΠ τον αδικεί. Με τους Ολλανδούς θα παιχτεί πιθανότατα η 3η θέση στο ταξίδι του Άμστερνταμ την τελευταία αγωνιστική, όμως μία ισοπαλία με την Μπαρτσελόνα ίσως άλλαζε πλήρως την κατάσταση (αν συνδυαστεί με ήττα του Άγιαξ από την Παρί). Ο Χαραλαμπίδης είναι τραυματίας, ενώ αμφίβολη είναι η συμμετοχή του Βινίσιους. Ο ΑΠΟΕΛ έφερε 0-0 με τον Απόλλωνα στη Λεμεσό για στο ντέρμπι κορυφής του πρωταθλήματος, διατηρώντας το προβάδισμα στην κορυφή. Πιστεύετε ότι ο ΑΠΟΕΛ θα πετύχει το θαύμα;</span></p>

<p><span style="color:#FF0000"><strong>ΜΠΑΡΤΣΕΛΟΝΑ (2η - 9β)</strong></span><span style="background-color:rgb(206, 212, 222); font-family:tahoma,arial,helvetica,sans-serif; font-size:11px">&nbsp;</span><span style="font-family:tahoma,arial,helvetica,sans-serif; font-size:11px">- Έχει προκριθεί ήδη, θέλει όμως να πάρει και την πρωτιά του ομίλου από την Παρί Σεν Ζερμέν (10β). Οι Καταλανοί ασχολούνται με τα ρεκόρ του Μέσι, αλλά παίρνουν ταυτόχρονα τον ΑΠΟΕΛ πολύ σοβαρά. Τους άγχωσε εξάλλου στο ματς του Καμπ Νου, άρα δεν είναι δυνατό να τον υποτιμήσουν τώρα. Ο Ενρίκε άλλωστε δήλωσε θαυμασμό για την πειθαρχία που έχει στο παιχνίδι του ο πρωταθλητής Κύπρου και ζήτησε από τους παίκτες του μεγάλη προσπάθεια για να ξεπεράσουν το τρέχον εμπόδιο. Η Μπαρτσελόνα κέρδισε 5-1 τη Σεβίλλη για το πρωτάθλημα, αλλά παρέμεινε στην 3η θέση της βαθμολογίας. Απουσιάζει απόψε ο Ινιέστα, ενώ χωρίς συμμετοχή παραμένει ο επίσης τραυματίας Βερμάλεν</span></p>

<p><strong><span style="color:#DAA520">ΕΚΤΙΜΗΣΗ / ΣΤΟΙΧΗΜΑ -</span> Αξιόλογη η πορεία του ΑΠΟΕΛ ως τώρα. Με αμυντική προσέγγιση θα προσπαθήσει να κερδίσει... χρόνο και να αγχώσει την Μπαρτσελόνα. Δύσκολα θα καταφέρει να αποτρέψει την ήττα. Ποντάρουμε όμως στα 2-3 γκολ, θεωρώντας ως πιθανά αποτελέσματα κάτι μεταξύ 0-2, 1-2 και 0-3</strong></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES (' 124. ΑΤΛΕΤΙΚΟ ΜΑΔΡ. - ΟΛΥΜΠΙΑΚΟΣ ', '1417001342', 'arheio_lipsis.jpg', '<p><span style="color:#FF0000"><strong>ΑΤΛΕΤΙΚΟ ΜΑΔΡΙΤΗΣ (1η - 9β<span style="font-size:14px">)</span></strong></span><span style="font-size:14px"><span style="font-family:tahoma,arial,helvetica,sans-serif">&nbsp;- Παρά την ήττα της πρεμιέρας από τον Ολυμπιακό, βρήκε τη δύναμη να αντιδράσει και με τρεις σερί νίκες, μία επί της Γιουβέντους και δύο επί της Μάλμε, ανέβηκε στην κορυφή της βαθμολογίας. Με νίκη σήμερα εξασφαλίζει την πρόκριση στην επόμενη φάση, ενώ σε άλλο αποτέλεσμα θα ταξιδέψει στο Τορίνο με άγχος την τελευταία αγωνιστική. Ο Σιμεόνε έδειξε μεγάλο σεβασμό προς τον Ολυμπιακό και τον Μίτσελ. Δε θα μπορούσε να κάνει διαφορετικά μετά την ήττα με 3-2 στο Καραϊσκάκης. Το Σάββατο, η Ατλέτικο κέρδισε 3-1 τη Μάλαγα για το πρωτάθλημα, επιστρέφοντας στις νίκες και παραμένοντας σε απόσταση 4β. και 2β. από Ρεάλ και Μπάρτσα αντίστοιχα, οι οποίες προηγούνται στη βαθμολογία. Οι Ροχιμπλάνκος θέλουν να μπουν ξανά σφήνα ανάμεσα στα δύο μεγαθήρια, όμως οι δυσκολίες είναι ευνόητες. Τον Μάιο ολοκλήρωσαν ένα θαύμα κατακτώντας τη Λα Λίγκα, όμως τώρα τα πράγματα έχουν αλλάξει τόσο στην ίδια, όσο και στις δύο πρωτοπόρους. Η Ευρώπη όμως παραμένει πιο... βατή. Στο Βιθέντε Καλντερόν έχει δύο νίκες επί Γιουβέντους (1-0 και Μάλμε (5-0), όπου δε δέχτηκε γκολ. Απουσιάζει ο Μιράντα (Α), όχι όμως και ο Μάντζουκιτς που βρίσκεται στην αποστολή και ο Σιμεόνε ανέφερε ότι&nbsp;</span><em>είναι πολύ δύσκολο να του πει να μην αγωνιστεί</em><span style="font-family:tahoma,arial,helvetica,sans-serif">. Σε χαμηλά επίπεδα προσφέρεται ο άσος (1,35 - 1,40), όμως με χάντικαπ ενός γκολ ανεβαίνει σε ικανοποιητικά επίπεδα.</span></span></p>

<p><span style="color:#FF0000"><strong>ΟΛΥΜΠΙΑΚΟΣ (2ος - 6β)&nbsp;</strong></span><span style="font-size:14px"><span style="font-family:tahoma,arial,helvetica,sans-serif">- Όλοι παίρνουν σαν δεδομένο πως η Γιουβέντους θα κερδίσει στη Μάλμε, άρα ο <span style="color:#DAA520">Ολυμπιακός... χρειάζεται βαθμό στη Μαδρίτη</span>. Δεν αποκλείεται να είναι αυτό το αποψινό σενάριο. Σε καμία περίπτωση όμως δεν μπορεί να αποτελέσει τη βάση της ψυχολογίας με την οποία οι Ερυθρόλευκοι θα αγωνιστούν στην κρίσιμη αναμέτρηση. Οι πρωταθλητές Ελλάδας δικαιούνται να ελπίζουν ανεξαρτήτως αποτελέσματος απόψε. Έχουν άλλωστε προβάδισμα έναντι της Γιουβέντους σε πιθανή ισοβαθμία, χάρη στην απόκρουση πέναλτι του Ρομπέρτο στο 3-2 του Τορίνο.&nbsp;</span><a href="http://www.novibet.com/Handlers/AffiliateLanding.ashx?aff=hllsbt&amp;goto=el/Promotions/roberto" style="color: rgb(11, 66, 133); text-decoration: none;" target="_blank"><strong>Θα ξαναπιάσει ο Ισπανός γίγαντας πέναλτι</strong></a><span style="font-family:tahoma,arial,helvetica,sans-serif">; Αν ναι, μπορείς να πάρεις ένα δωρεάν στοίχημα αξίας 25 ευρώ. Ο Μίτσελ ετοιμάζει τα αγωνιστικά πλάνα του για να αιφνιδιάσει αν μπορεί την Ατλέτικο. Η προσέγγιση βέβαια που περιμένουμε είναι αμυντική. Διαφύλαξη των μετόπισθεν και στη αντεπιθέσεις με Αφελάι, Ντομίνγκες, Μήτρογλου, αλλά και από τους γρήγορους ακραίους μπακ. Ο Ολυμπιακός σκοράρει εύκολα και από στημένες φάσεις. Το έκανε και με τη Γιουβέντους, αλλά πλήρωσε την αμυντική αδυναμία του. Τα τρία τελευταία χρόνια σημειώνει τουλάχιστον μία νίκη εκτός έδρας, αλλά φέτος δείχνει πιο αδύναμος (το αποδεικνύει ο αγώνας στο Μάλμε). Απουσιάζουν <span style="color:#DAA520">οι Γιαννούλης και Ντουρμάζ</span></span></span></p>

<p><span style="color:#DAA520"><strong>ΕΚΤΙΜΗΣΗ &nbsp;ΓΚΟΛ ΓΚΟΛ&nbsp;</strong></span></p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('127.ΛΟΥΝΤΟΓΚΟΡΕΤΣ - ΛΙΒΕΡΠΟΥΛ ', '1417001525', 'arheio_lipsis.jpg', '<p><strong><span style="color:#FF0000">Η Λίβερπουλ </span>δεν έχει απογοητεύσει μόνο τους φίλους της, αλλά και... εμάς σε αρκετές περιπτώσεις φέτος. Το ίδιο συνέβη την Κυριακή, όταν προτείναμε το διπλό της ως Match of the Day. Σήμερα δε θα... τραβήξουμε τόσο μακριά το σχοινί, αλλά πιστεύουμε ότι θα φύγει νικήτρια από τη Σόφια.</strong></p>

<p><strong><span style="color:#DAA520">EKTIMHΣΗ &nbsp;2/2</span> με τη καλύτερη απόδοση στην </strong></p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('126. ΛΕΒΕΡΚΟΥΖΕΝ - ΜΟΝΑΚΟ', '1417001752', 'arheio_lipsis.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000"><strong>ΛΕΒΕΡΚΟΥΖΕΝ (1η - 9β)</strong></span><span style="font-family:tahoma,arial,helvetica,sans-serif"><span style="color:#FF0000">&nbsp;</span>- Μετά την ήττα στην πρεμιέρα από τη Μονακό (0-1) και τη νίκη επί της Μπενφίκα (3-1 εντός), σημείωσε... διπλή νίκη επί της Ζενίτ (2-0 εντός, 2-1 εκτός) με αποτέλεσμα να βρεθεί στην κορυφή του ομίλου. Απέχει πλέον 1β. από την πρόκριση. Αυτό όμως πριν την έναρξη του αγώνα της Ρωσίας που διεξάγεται νωρίτερα. Άρα υπάρχει σοβαρή περίπτωση η Λεβερκούζεν να έχει προκριθεί ανεξάρτητα από το τί θα κάνει απόψε η ίδια. Ο Σμιντ επανέλαβε πως θα παίξει επιθετικά, κάτι που του έχει βγει ως ένα μεγάλο βαθμό στη σεζόν. Στην Ευρώπη υπάρχει μια πιο... μαζεμένη προσέγγιση και προσφέρονται λιγότεροι χώροι στον αντίπαλο, πράγμα που φαίνεται και από τα λίγα γκολ που έχει δεχτεί σε αναλογία με τα μεγάλα σκορ της Μπουντεσλίγκα. Το Σάββατο κέρδισε με 3-1 στο Αννόβερο και ανέβηκε στην 4η θέση της βαθμολογίας, 3β. πίσω από τη 2η Βόλφσμπουργκ. Ο Κυριάκος Παπαδόπουλος είναι τραυματίας, όπως και ο Ράιναρτζ (Μ)</span></span></p>

<p><span style="font-size:14px"><strong><span style="color:#B22222">ΜΟΝΑΚΟ (2η - 5β)</span>&nbsp;</strong><span style="font-family:tahoma,arial,helvetica,sans-serif">- Αν κάποιος σκεφτεί πως το καλοκαίρι... ξεπούλησε, η μέχρι τώρα πορεία της στην Ευρώπη μάλλον επιτυχημένη χαρακτηρίζεται. Το πιο τρανταχτό στατιστικό στοιχείο είναι τα συνολικά... 1-1 γκολ στα 4 παιχνίδια της. Ξεκίνησε με νίκη επί της Λεβερκούζεν (1-0), συνέχισε με δύο λευκές ισοπαλίες με Ζενίτ και Μπενφίκα , ενώ στο πιο πρόσφατο ματς ηττήθηκε με 1-0 από την Μπενφίκα στην Πορτογαλία. Στο αντίστοιχο ματς του πρώτου γύρου που κέρδισε, η Λεβερκούζεν είχε πολλές ευκαιρίες για να πάρει ακόμα και μια... εύκολη νίκη. Η ίδια χτύπησε μία φορά σε καθοριστικό σημείο και πήρε τους βαθμούς. Στο τελευταίο της ματς για τη Λιγκ 1 πήγε καλά επιθετικά, έμεινε όμως στο 2-2 με την Καέν (εντός), που την περιόρισε στην 8η θέση. Ο Μπερμπάτοφ επιστρέφει στην ομάδα που αγάπησε περισσότερο από κάθε άλλη και δεν το έκρυψε στις δηλώσεις του. Η Μονακό γνωρίζει πως η πρόκριση θα κριθεί την τελευταία αγωνιστική, αλλά θέλει το καλύτερο δυνατό αποτέλεσμα απόψε ώστε να εξαρτάται μόνο από τη δική της απόδοση. Απών είναι ο Κουρζάβα (Α). Εκτός από την αρχή της σεζόν ο Λόπεζ (Α).&nbsp;</span></span></p>

<p><span style="font-size:14px"><strong><span style="color:#DAA520">ΕΚΤΙΜΗΣΗ</span> Το ματς που προηγείται (Ζενίτ - Μπενφίκα) ίσως επηρεάσει, όμως καθαρά αγωνιστικά πιστεύουμε ότι η Λεβερκούζεν μπορεί να εκμεταλλευτεί την ισχυρή έδρα της, να κάνει το 3 στα 3 εκεί και να θριαμβεύσει κατακτώντας την κορυφή του ομίλου πριν την τελευταία αγωνιστική. Αξιόμαχη η Μονακό, αλλά μόνο με άμυνα δεν μπορείς να αντέξεις κόντρα στη Λεβερκούζεν.</strong></span></p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('123.ΑΡΣΕΝΑΛ - ΝΤΟΡΤΜΟΥΝΤ ', '1417001900', 'arheio_lipsis.jpg', '<p><span style="font-size:14px"><strong><span style="color:#FF0000">ΑΡΣΕΝΑΛ (2η - 7β)</span>&nbsp;</strong><span style="font-family:tahoma,arial,helvetica,sans-serif">- Χρειάζεται ένα βαθμό για να πάρει σίγουρα την πρόκριση χωρίς να περιμένει το αποτέλεσμά της στην Τουρκία την τελευταία αγωνιστική. Μπορεί να μη χρειαστεί ούτε ο βαθμός αν η Άντερλεχτ δεν κερδίσει τη Γαλατασαράι στο άλλο παιχνίδι. Η ομάδα του Βενγκέρ αδυνατεί πάντως να κερδίσει στους μεγάλους αγώνες παρά την ενίσχυσή της το καλοκαίρι. Υπάρχουν κάποιες φωνές εναντίον του Αλσατού, που έχει όμως αποδείξει στο παρελθόν πως δεν... καταλαβαίνει τίποτα. Συνήθως μάλιστα απαντάει με αποτελέσματα και όχι με λόγια. Αυτή τη φορά αναγκάστηκε να κάνει και το δεύτερο λόγω της κριτικής που δέχτηκε μέσω του Τύπου από τον ισχυρό μέτοχο της ομάδας Ουζμάνοφ, λέγοντας πως αν έχει κάτι να πει ο Ουζμπέκος να του το πει ευθέως. Στο αγωνιστικό κομμάτι, η Άρσεναλ προέρχεται από το&nbsp;</span><a href="http://hellasbet.com/hb2/football.php?idfind=20855" style="font-family: Tahoma, Arial, Helvetica, sans-serif; font-size: 11px; color: rgb(11, 66, 133); text-decoration: none; background-color: rgb(206, 212, 222);" target="_blank">1-2 κόντρα στη Μάντσεστερ Γιουνάιτεντ</a><span style="font-family:tahoma,arial,helvetica,sans-serif">, ένα παιχνίδι που φερόταν ως φαβορί. Απόψε είναι ξα΄νά φαβορί, αλλά οριακά. Παραμένουν τραυματίες οι τερματοφύλακες Όσπινα και Σέζνι, ο μπακ Ντεμπισί, ο εξτρέμ Γουόλκοτ και ο πολύτιμος μέσος Οζίλ. Ο Γουέλμπεκ δίνεται ως αμφίβολος, όμως επέστρεψε ο Ζιρού. Ανέβηκαν οι αποδόσεις του άσου, που προσφέρεται στο πολύ κοντά στο 2,55 στις περισσότερες εταιρίες.</span><br />
<br />
<span style="color:#FF0000"><strong>ΝΤΟΡΤΜΟΥΝΤ (1η - 12β)&nbsp;</strong></span><span style="font-family:tahoma,arial,helvetica,sans-serif">- Θέλει, αλλά δεν μπορεί στην Μπουντεσλίγκα (16η - στη θέση των πλέι άουτ υποβιβασμού), την ώρα που στην Ευρώπη και να... θέλει δε χάνει. Στον πιο πρόσφατο αγώνα με την Πάντερμπορν προηγήθηκε με 2-0, αλλά τελικά παραχώρησε 2-2. Τραυματίστηκε για μία ακόμη φορά ο Ρόις και μένει εκτός για αρκετό διάστημα. Η Ντόρτμουντ εξασφαλίζει την πρωτιά στον όμιλό της με ισοπαλία απόψε, αλλά ο Κλοπ προμήνυσε το... φυσιολογικό, πως η ομάδα του θα παίξει για τη νίκη και για το 6 στα 6. Η Ευρώπη συνήθως μπορεί να δώσει ψυχολογία, αλλά παρατηρούμε πως δεν ισχύει κάτι τέτοιο όσον αφορά την Μπουντεσλίγκα, όπου η Μπορούσια υποφέρει. Εκτός του Ρόις, απουσιάζουν οι Χούμελς και Παπασταθόπουλος που κανονικά απαρτίζουν το αμυντικό κεντρικό δίδυμο. Εκτός και οι Σαχίν (Μ), Μπλαστσικόφσκι από το ξεκίνημα της σεζόν</span></span></p>

<p><strong><span style="color:#DAA520">ΕΚΤΙΜΗΣΗ &nbsp;</span>Δε θα μπλέξουμε με σημείο τύπου 1Χ2. Ποντάρουμε στο <span style="color:#DAA520">Goal/Goal</span> αναγνωρίζοντας τις επιθετικές αρετές των δύο ομάδων. Η Άρσεναλ παίζει στην έδρα της και δύσκολα θα μείνει στο μηδέν, έχει όμως πολλά αμυντικά κενά και οι ταχύτατοι Ομπαμεγιάνγκ, Ιμόμπιλε (και όχι μόνο) μπορούν να τα εκμεταλλευτούν.</strong></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ειδικες επιλογές από Τσάμπιονς Λιγκ', '1417002686', 'arheio_lipsis.jpg', '<p><span style="color:#FF0000">124. ΑΤΛΕΤΚΟ ΜΑΔΡΙΤΗΣ-ΟΛΥΜΠΙΚΟΣ (21.45)&nbsp;</span></p>

<p>Να σκοράρει οποιδήποτε στιγμή &nbsp;Diego Godin. απόδοση 4.20 στην &nbsp;</p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Τσάμπιονς Λιγκ ', '1417003016', 'arheio_lipsis.jpg', '<p><span style="color:#FF0000">119.</span> <span style="color:#0000FF">ΖΕΝΙΤ-ΜΠΕΝΦΙΚΑ (19.00)</span> : <span style="color:#DAA520">Μπενφίκα over 2 οφσαιντ</span>. απόδοση 2.10 στην&nbsp;</p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>

');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ο πιγκουίνος στο Τσάμπιονς Λιγκ', '1417003551', 'arheio_lipsis.jpg', '<p><span style="color:#FF0000">119</span>. ΖΕΝΙΤ-ΜΠΕΝΦΙΚΑ (19.00) &nbsp;<span style="color:#DAA520"> 1</span></p>

<p><span style="color:#FF0000">123.</span> ΑΡΣΕΝΑΛ-ΝΤΟΡΤΜΟΥΝΤ (21.45) &nbsp;<span style="color:#DAA520"> 1</span></p>

<p><span style="color:#FF0000">127</span>. ΛΟΥΝΤΟΓΚΟΡΕΤ-ΛΙΒΕΡΠΟΥΛ (21.45) &nbsp; <span style="color:#DAA520">2</span></p>

<p>Κάντε εγγρααφή και στοιχηματιστε τη τριάδα λαμβάνοντας μπόνους και επιστροφή χρημάτων στην&nbsp;</p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Uefa Europa League', '1417090193', 'europa-league.jpeg', '<p><span style="color:#FF0000">137.</span>&nbsp;<span style="font-size:14px"><span style="font-family:arial,tahoma,helvetica">ΒΟΛΦΣΜΠΟΥΡΓΚ-ΕΒΕΡΤΟΝ<span style="color:#0000FF"> (20.00)</span> <span style="color:#DAA520">1</span></span></span></p>

<p><span style="font-size:14px"><span style="font-family:arial,tahoma,helvetica"><span style="color:#FF0000">138.</span>ΓΚΙΝΓΚΑΜΠ - ΦΙΟΡΕΝΤΙΝΑ <span style="color:#0000FF">(20.00)</span> <span style="color:#DAA520">1Χ ΔΕ</span></span></span></p>

<p><span style="font-size:14px"><span style="font-family:arial,tahoma,helvetica"><span style="color:#FF0000">155.</span> ΣΕΛΤΙΚ-ΣΑΛΤΣΜΠΟΥΡΓΚ <span style="color:#0000FF">(22.05)</span> <span style="color:#DAA520">ΓΚΟΛ ΓΚΟΛ</span></span></span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Παρασκευής..', '1417195800', '24121a4eeaa45711e6a89d9faed6ed3c.jpg', '<p><span style="color:#FF0000">109</span>, ΛΑΒΑΛ-ΟΣΕΡ <span style="color:#DAA520">ΓΚΟΛ ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">114.</span> ΣΟΣΟ-ΚΛΕΡΜΟΝ <span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">128</span>.ΜΑΡΣΕΙΓ-ΝΑΝΤ <span style="color:#DAA520">2-3 ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">133.</span> ΣΟΣΙΕΔΑΔ-ΕΛΤΣΕ <span style="color:#DAA520">ΓΚΟΛ ΓΚΟΛ</span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακής ', '1417346772', '24121a4eeaa45711e6a89d9faed6ed3c.jpg', '<p><span style="color:#FF0000">302</span>. ΣΑΝ ΠΑΟΥΛΙ -ΚΑΪΖΕΡΣΛΑΟΥΤΕΡΝ (14.30) <span style="color:#DAA520">ΓΚΟΛ ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">310</span>.ΣΑΟΥΘΑΜΠΤΟΝ- ΜΑΝΤΣΕΣΤΕΡ ΣΙΤ (15.30) <span style="color:#DAA520">&nbsp;2/2</span></p>

<p><span style="color:#FF0000">311.</span>ΑΝΤΕΡΛΕΧΤ-ΚΛΑΜΠ ΠΡΙΖ (15.30) <span style="color:#DAA520">2-3 ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">405</span>.ΠΑΝΙΩΝΙΟΣ-ΝΙΚΗ ΒΟΛΟΥ (17.15) <span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">330.</span>ΣΕΒΙΛΛΗ-ΓΡΑΝΑΔΑ.(18.00) <span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">335</span>.ΑΪΝΤΡΑΧΤ ΦΡΑΝΚΦΟΥΡΤΗΣ-ΝΤΟΡΤΜΟΥΝΤ (18.00) <span style="color:#DAA520">2</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Η Τριάδα της Δευτέρας', '1417442717', 'deite-poses-xiliades-evro-evgale-enas-25xronos-apo-ta-giannitsa-sto-st_2.jpg', '<p><span style="color:#FF0000">373.</span> <strong>ΒΑΛΒΙΚ-ΜΑΑΣΤΡΙΧΤ</strong> <span style="color:#0000CD">(21.00) </span><span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">383</span>.<strong>ΑΛΜΕΡΙΑ-ΒΑΓΙΕΚΑΝΟ </strong><span style="color:#0000CD">(21.45)</span> <span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">384</span>.<strong>ΣΑΜΠΤΟΡΙΑ-ΝΑΠΟΛΙ </strong><span style="color:#0000CD">(22.00)</span> <span style="color:#DAA520">1Χ ΔΕ</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Euroleague Basketball', '1417714304', '1.jpg', '<p><span style="color:#FF0000">ΦΕΝΕΡ. ΟΥΛΚΕΡ - ΠΑΝΑΘΗΝΑΙΚΟΣ (20.00)</span>&nbsp; <span style="color:#DAA520">Πόντοι ομάδας 2 under 73.5 στήν&nbsp;</span></p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σαββάτου', '1417876095', 'deite-poses-xiliades-evro-evgale-enas-25xronos-apo-ta-giannitsa-sto-st_2.jpg', '<p><span style="color:#FF0000">150.</span> ΛΙΒΕΡΠΟΥΛ-ΣΑΝΤΕΡΛΑΝΤ <span style="color:#0000CD">(17.ΟΟ)</span> <span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">194.</span>ΧΑΡΤΣ-ΚΟΥΙΝ ΟΦ ΣΑΟΥΘ<span style="color:#0000CD"> (17.00)</span> <span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">215</span>.ΑΘΛΕΤΙΚ ΜΠΙΜΠΑΟ -ΚΟΡΔΟΒΑ <span style="color:#0000CD">(19.00)</span> <span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">320</span>.ΜΑΝΣ. ΣΙΤΙ -ΕΒΕΡΤΟΝ &nbsp;<span style="color:#0000CD">(19.30)</span> <span style="color:#DAA520">1</span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακής', '1417960257', 'deite-poses-xiliades-evro-evgale-enas-25xronos-apo-ta-giannitsa-sto-st_2.jpg', '<p><span style="color:#FF0000">298.</span> ΟΦΗ - ΛΕΒΑΔΕΙΑΚΟΣ <span style="color:#0000CD">&nbsp;(17.15) </span><span style="color:#DAA520">ΗΜ. Χ</span></p>

<p><span style="color:#FF0000">304</span>. &nbsp;ΡΕΜΣ-ΓΚΙΝΚΑΜΠ <span style="color:#0000CD">(18.00)</span> &nbsp;<span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">316</span>. ΑΣΤΕΡΑΣ ΤΡΙΠΟΛΗΣ-ΠΑΝΑΘΗΝΑΙΚΟΣ <span style="color:#0000CD">(19.30)</span> &nbsp;<span style="color:#DAA520">1Χ ΔΕ</span></p>

<p><span style="color:#FF0000">336</span>. ΓΡΑΝΑΔΑ-ΒΑΛΕΝΘΙΑ <span style="color:#0000CD">(22.00) </span><span style="color:#DAA520">2</span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES (' ΓΙΟΥΒΕΝΤΟΥΣ - ΑΤΛΕΤΙΚΟ ΜΑΔΡΙΤΗΣ ', '1418125462', 'champions-league-generic-general_2849932.jpg', '<p><span style="font-size:14px"><strong><span style="color:#FF0000">ΓΙΟΥΒΕΝΤΟΥΣ (2η - 9β)</span>&nbsp;</strong>- Χρειάζεται ισοπαλία για να προκριθεί έναντι του Ολυμπιακού, ενώ μπορεί να το πράξει και με ήττα στην περίπτωση που η ελληνική ομάδα δεν κερδίσει τη Μάλμε. Στην ισοβαθμία πάντως με τον Ολυμπιακό υστερεί και ουσιαστικά αυτό θέλει να αποφύγει. Με νίκη από την άλλη με δύο γκολ διαφορά κατακτά την πρώτη θέση. Η Γιουβέντους δεν είχε κάνει ούτε σουτ στο τέρμα στο αντίστοιχο ματς της Μαδρίτης, όπου ηττήθηκε με 1-0. Ο Αλέκγρι αναγνώρισε πόσο δύσκολο είναι να κερδίσει η ομάδα του με δύο γκολ διαφορά, ξεκινώντας τη... διπλωματία. Είναι ουσιαστικά σαν να λέει ότι&nbsp;<em>εμείς δε θα πάμε για την πρωτιά, δεύτεροι θέλουμε να βγούμε</em>. Η Γιουβέντους παίρνει δύναμη από το εντός έδρας σερί της (25 νίκες στη Serie A, 2 φέτος στο Τσάμπιονς Λιγκ), αλλά αντιμετωπίζει προβλήματα σε τακτά χρονικά σημεία. Δε βρίσκεται σε φουλ φόρμα και το αποδεικνύουν τα τελευταία παιχνίδια της. Με την Τορίνο έσωσε 2β. με ένα γκολ του Πίρλο στην... εκπνοή (2-1), ενώ με τη Φιορεντίνα μοιράστηκε το Σάββατο τους βαθμούς (0-0 εντός). Για καλή της τύχη η Ρόμα παραχώρησε ισοπαλία στη Σασσουόλο και η διαφορά των 3β. υπέρ της διατηρήθηκε. Εκτός μάχης είναι απόψε οι Ασαμόα, Μπαρτσάλι, Κάσερες, Ρόμουλο, αλλά και ο νεαρός Κομάν, που τραυματίστηκε στο τελευταίο ματς.</span></p>

<p><span style="font-size:14px"><strong><span style="color:#FF0000">ΑΤΛΕΤΙΚΟ ΜΑΔΡΙΤΗΣ (1η - 12β)</span>&nbsp;</strong>- Έχει προκριθεί ήδη, αλλά θέλει να διατηρήσει την πρώτη θέση, κάτι που θα πετύχει ακόμη και με ήττα μέχρι ένα γκολ διαφορά. Η Ατλέτικο ηττήθηκε μόνο στον Πειραιά από τον Ολυμπιακό στην πρεμιέρα, αλλά απάντησε με 4 σερί νίκες, αποδεικνύοντας πως είναι το φαβορί του ομίλου. Ο Ντιέγκο Σιμεόνε γνωρίζει καλά ποιά θα είναι η ατμόσφαιρα στο γήπεδο, υπενθυμίζοντας πως η Γιουβέντους αποκλείστηκε πέρσι παρά την... ανάγκη για βαθμούς που είχε με τη Ρεάλ Μαδρίτης (εντός έδρας, προτελευταία αγωνιστική). Έστειλε μήνυμα ή θόλωσε τα νερά; Το βέβαιο είναι πως η Ατλέτικο θα παραταχθεί με την καλύτερη δυνατή 11άδα της. Είναι σαφώς καλύτερο να παίζεις για να διαφυλάξεις την 1η θέση από το να προσπαθείς να την κατακτήσεις υπό την πίεση ενός πιθανού αποκλεισμού. Στο εγχώριο πρωτάθλημα, η Ατλέτικο έχει βρει τα... πατήματά της και παραμένει κοντά στην κούρσα του τίτλου (3η - 4β. από την κορυφή). Τραυματίες για τον αγώνα του Τορίνο είναι οι αμυντικοί Μιράντα και Ανσάλντι.</span></p>

<p><span style="font-size:14px"><strong><span style="color:#DAA520">ΕΚΤΙΜΗΣΗ / ΣΤΟΙΧΗΜΑ </span>- Θα μείνουμε στην αρχική εκτίμησή μας από το τέλος της 5ης αγωνιστικής, περιμένοντας ισοπαλία στο συγκεκριμένο ματς. Αυτή είναι η πρόβλεψή μας πριν οποιαδήποτε σκέψη περί... διπλωματίας στην αναμέτρηση. Προκύπτει και αγωνιστικά, αφού η Γιουβέντους είναι πολύ ισχυρή εντός έδρας και η Ατλέτικο δεν αφήνει πολλά επιθετικά περιθώρια στις αντιπάλους της. Με Χ θα είναι όλοι χαρούμενοι στο φινάλε, άρα αν το σημείο αυτό διατηρείται, τότε δύσκολα θα αλλάξει κάτι στα τελευταία λεπτά.</strong></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES (' ΜΟΝΑΚΟ - ΖΕΝΙΤ', '1418125582', 'champions-league-generic-general_2849932.jpg', '<p><span style="font-size:14px"><strong><span style="color:#FF0000">ΜΟΝΑΚΟ (2η - 8β)</span>&nbsp;</strong><span style="font-family:tahoma,arial,helvetica,sans-serif">- Θέλει νίκη ή ισοπαλία για να ακολουθήσει τη Λεβερκούζεν στην επόμενη φάση του Τσάμπιονς Λιγκ. Σε περίτπωση ήττας μένει στην 3η θέση. Ο Ζαρντίμ κατάφερε να περάσει τη νοοτροπία του στην ομάδα. Μετά την απώλεια των περισσότερων επιθετικών όπλων του, δημιούργησε ένα σύνολο που τουλάχιστον δέχεται δύσκολα γκολ και το να παίζει την πρόκριση την τελευταία αγωνιστική μάλλον αποτελεί σπουδαία επιτυχία. Μην ξεχνάμε ότι η Μονακό αγωνιζόταν στη 2η Γαλλίας μέχρι πριν από δύο χρόνια. Ότι το χρήμα ρέει άφθονο φυσικά βοηθάει, αλλά αυτό δε δίνει προκρίσεις. Προκρίσεις δίνει η οργάνωση, οι προπονητές, οι προσωπικότητες των παικτών. Θα τα καταφέρει όμως η δευτεραθλήτρια Γαλλίας; Αν κερδίσει έχει τη δυνατότητα να τερματίσει ακόμη και πρώτη, στην περίπτωση που η Λεβερκούζεν δεν κερδίσει την Μπενφίκα. Στο εγχώριο πρωτάθλημα παραμένει στην 7η θέση, αλλά προέρχεται από σημαντική νίκη στην έδρα της Τουλούζ με 2-0. Οι Καρβάλιο (τιμωρημένος), Κοντόγκμπια και Κουρζάβα είναι εκτός μάχης.&nbsp;</span><br />
<strong><span style="color:#0000FF">ΖΕΝΙΤ (3η - 7β)</span>&nbsp;</strong><span style="font-family:tahoma,arial,helvetica,sans-serif">- Θέλει μόνο νίκη για να προκριθεί, ενώ σε περίπτωση ταυτόχρονης ήττας της Λεβερκούζεν στην Πορτογαλία θα τερματίσει στην πρώτη θέση. Η φιλοξενούμενη εντυπωσιάζει στο εγχώριο πρωτάθλημα, έχοντας προβάδισμα 7β. επί της 2ης ΤΣΣΚΑ Μόσχας, όμως στην Ευρώπη δεν τα κατάφερε ανάλογα και καλείται να διορθώσει την κατάσταση απόψε. Με τη Μονακό έμεινε στο 0-0 στη Μόσχα για τη 2η αγωνιστική. Ακολούθησαν δύο ήττες από τη Λεβερκούζεν, αλλά το 1-0 επί της Μπενφίκα αναπτέρωσε τις ελπίδες της. Προέρχεται από το 4-0 επί της Κράσνονταρ (εντός) για τη ρώσικη Πρέμιερ Λιγκ, όμως τα είπαμε, άλλο Ευρώπη και άλλο Ρωσία. Απόψε θα ψάξει μια εμφάνιση αντίστοιχη της πρεμιέρας, όταν κέρδισε με 2-0 την Μπενφίκα στην Πορτογαλία. Μπορεί να το κάνει η ομάδα του Βίλας Μπόας. Ο Κερζακόφ (Ε) αποτελεί τη μοναδική απώλεια για τους Ρώσους.&nbsp;</span><br />
<br />
<strong><span style="color:#DAA520">ΕΚΤΙΜΗΣΗ / ΣΤΟΙΧΗΜΑ -</span> Θα ποντάρουμε στην έκπληξη θεωρώντας πως η πορεία της Μονακό έχει ξεπεράσει τις δυνατότητές της. Σαφώς και έχει παίκτες όπως ο Μουτίνιο ή ο Μπερμπάτοφ, που μπορούν να αλλάξουν την... ιστορία ενός αγώνα, όμως η Ζενίτ φαντάζει στα μάτια μας πιο... ομάδα και πιο έτοιμη για έναν τόσο κρίσιμο αγώνα, έχοντας την εμπειρία του Τσάμπιονς Λιγκ από τα προηγούμενα χρόνια. Στοίχημα στο διπλό.</strong></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES (' ΡΟΜΑ - ΜΑΝΤΣΕΣΤΕΡ ΣΙΤΙ', '1418221404', 'deite-poses-xiliades-evro-evgale-enas-25xronos-apo-ta-giannitsa-sto-st_2.jpg', '<p><span style="font-size:14px"><strong><span style="color:#FF0000">ΡΟΜΑ (2η - 5β)</span>&nbsp;</strong><span style="font-family:tahoma,arial,helvetica,sans-serif">- Η Ρόμα θέλει νίκη ή έστω ισοπαλία στην περίπτωση που η ΤΣΣΚΑ αποσπάσει ισοπαλία στο Μόναχο (ώστε να παραμείνει η τρέχουσα βαθμολογία). Αν η ΤΣΣΚΑ ηττηθεί, τότε η Ρόμα προκρίνεται με 0-0, αλλά αποκλείεται με οποιαδήποτε άλλη ισοπαλία με γκολ. Η ομάδα του Ρούντι Γκαρσιά απώλεσε μεγάλη ευκαιρία στη Μόσχα, όταν δέχτηκε την ισοφάριση στην τελευταία φάση του αγώνα (1-1) και έχασε έτσι το προβάδισμα έναντι των δύο αντιπάλων της. Στο Καμπιονάτο παρέμεινε 3β. πίσω από τη Γιουβέντους μετά την αγωνιστική των ισοπαλιών. Η ίδια έφερε 2-2 με τη Σασσουόλο εντός έδρας μία μέρα μετά το 0-0 της Γιουβέντους στη Φλωρεντία. Οι Καστάν, Τοροσίδης είναι τραυματίες και χάνουν την αναμέτρηση, ενώ εκτός πιθανότατα θα μείνει και ο αναπληρωματικός πορτιέρο Σκορούπσκι. Ως τελικό χαρακτήρισε τον αγώνα ο Γάλλος τεχνικός των γηπεδούχων, κάτι στο οποίο συμφώνησε και ο Πελεγκρίνι.&nbsp;</span><br />
<br />
<strong><span style="color:#FF0000">ΜΑΝΤΣΕΣΤΕΡ ΣΙΤΙ (3η - 5β)</span>&nbsp;</strong><span style="font-family:tahoma,arial,helvetica,sans-serif">- Τα πάνω - κάτω ήρθαν τελικά κατά... παραγγελία. Η Ρόμα έφερε ισοπαλία στη Μόσχα και στη συνέχεια η ίδια επικράτησε της Μπάγερν χάρη σε ένα χατ-τρικ του Αγουέρο (και πολλά τραγικά λάθη της άμυνας της Μπάγερν). Η Σίτι θέλει νίκη και ταυτόχρονα 1 ή Χ στο Μόναχο, ενώ προκρίνεται και στην περίπτωση ισοπαλίας με γκολ, αρκεί να ηττηθεί η ΤΣΣΚΑ. Αν οι Πολίτες ηττηθούν, τότε μένουν εκτός Ευρώπης τερματίζοντας 4οι. Μεγάλος απών από το κρίσιμο ματς είναι ο Αγουέρο, ενώ τιμωρημένος παραμένει ο Τουρέ και τραυματίας ο Νάσταζιτς. Αντιθέτως, οι Κομπανί, Φερναντίνιο, Σίλβα και Γιόβετιτς ξεπέρασαν τα προβλήματά τους και είναι διαθέσιμοι. Η Μάντσεστερ Σίτι μείωσε τη διαφορά από την Τσέλσι στην Πρέμιερ Λιγκ, κερδίζοντας με 1-0 την Έβερτον με αρκετό... σπρώξιμο (δύο αποβολές που δεν της δόθηκαν, ένα αυστηρό πέναλτι). Στο -3 πλέον από την κορυφή. Τα αποτελέσματα έρχονται, η απόδοση όμως της ομάδας δεν είναι για... ύμνους. Μένει να τη δούμε με την πλάτη στον τοίχο απόψε χωρίς όμως τα δύο μεγαλύτερα αστέρια της.</span><br />
<br />
<strong><span style="color:#DAA520">ΕΚΤΙΜΗΣΗ / ΣΤΟΙΧΗΜΑ </span>- Ο άσος δέχεται πιέσεις μετά την επιβεβαίωση της απουσίας του Αγουέρο, αλλά η Μάντσεστερ Σίτι έχει ποιότητα και χαρακτήρα για να κερδίσει στη Ρώμη. Είναι πολύ λεπτές οι ισορροπίες σε ένα τέτοιο παιχνίδι και η πρότασή μας είναι η ισοπαλία. Αν θα είναι με γκολ ή αν θα δώσει την πρόκριση θα το δούμε.</strong></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΠΑΝΑΘΗΝΑΪΚΟΣ - ΕΣΤΟΡΙΛ', '1418299700', 'opw.jpg', '<p><span style="font-size:14px"><span style="color:#008000"><strong>ΠΑΝΑΘΗΝΑΪΚΟΣ (4ος - 1β)&nbsp;</strong></span><span style="font-family:tahoma,arial,helvetica,sans-serif">- Κινδυνεύει να κάνει αρνητικό ρεκόρ (συλλογικό) στο Γιουρόπα Λιγκ αν δεν κερδίσει την Εστορίλ. Οι Πράσινοι είχαν κάκιστη πορεία στη διοργάνωση αφού φάνηκαν ανέτοιμοι να διεκδικήσουν κάτι καλύτερο από τη συμμετοχή τους στους ομίλους. Σε κάποια παιχνίδια έπαιξαν καλά, όμως δεν πήραν τα αποτελέσματα που θα μπορούσαν κι έτσι έφτασαν στην τελευταία αγωνιστική να διεκδικούν μια νίκη γοήτρου επί της Εστορίλ. Η ομάδα του Αναστασίου προέρχεται από ένα καλό σερί στο ελληνικό πρωτάθλημα με 4 νίκες και 1 ισοπαλία, αυτή της Κυριακής με τον Αστέρα στην Τρίπολη (1-1). Μείωσαν τη διαφορά από τον ΠΑΟΚ (-5), ενώ παρέμειναν στο (-1) από τον Ολυμπιακό, έχοντας κατά γενική ομολογία το δυσκολότερο παιχνίδι εκ των τριών. Με το ενδιαφέρον στραμμένο στο πρωτάθλημα και την περαιτέρω αναρρίχηση στη βαθμολογία, αναμένονται αλλαγές στην Ευρώπη. Οι Σίλντενφελντ, Νάνο και Πέτριτς έμειναν εκτός για να πάρουν ανάσες, ενώ τραυματίας είναι ο Κοτσόλης, που λογικά θα έπαιρνε φανέλα βασικού. Όποιο και αν είναι το σχήμα του Αναστασίου, λίγο αλλάζει το σύστημα της ομάδας, ενώ το κίνητρο των αναπληρωματικών (όσων αγωνιστούν) είναι σαφώς μεγάλο.&nbsp;</span><br />
<br />
<strong>ΕΣΤΟΡΙΛ (3η - 4β)&nbsp;</strong><span style="font-family:tahoma,arial,helvetica,sans-serif">- Ο αποκλεισμός ήρθε την 6η αγωνιστική για τους Πορτογάλους, που ολοκληρώνουν μια αξιοπρεπή πορεία στο Γιουρόπα Λιγκ. Πήραν τους 4 βαθμούς στην έδρα τους, κερδίζοντας 2-0 τον Παναθηναϊκό και φέρνοντας 3-3 με την Αϊντχόφεν. Στο τελευταίο ματς, που έγινε σε... δύο δόσεις (Πέμπτη και Παρασκευή), έχασαν το μομέντουμ λόγω της διακοπής και ισοφαρίστηκαν, χάνοντας την ευκαιρία να διεκδικήσουν στη Λεωφόρο την πρόκριση. Οι Πορτογάλοι θέλουν να αποφύγουν την τελευταία θέση και το τόνισαν στις δηλώσεις τους. Στο εγχώριο πρωτάθλημά&nbsp; τους ανέβηκαν τις τελευταίες εβδομάδες με ένα επί μέρους 2-2-0. Την Κυριακή κέρδισαν με 1-0 την Εστορίλ, ενώ είχαν προηγηθεί οι ισοπαλίες με Πόρτο (2-2 εντός) και Πάσος Φερέιρα (1-1 εκτός), που απέδειξαν ότι βρίσκεται σε ανοδική πορεία. Ακολουθούν δύσκολες αναμετρήσεις και η ομάδα του Κουσέιρο θέλει να συνεχίσει με επιτυχίες. Ίσως λοιπόν παίξει κι αυτός με κάποιες αλλαγές στο ματς της Αθήνας. Απουσίες πάντως σοβαρές δεν υπάρχουν.&nbsp;</span></span></p>

<p><br />
<span style="font-size:14px"><strong>ΕΚΤΙΜΗΣΗ / ΣΤΟΙΧΗΜΑ - Ο Παναθηναϊκός έπαιξε καλά στις εντός έδρας αναμετρήσεις με Ντιναμό Μόσχας (1-2) και Αϊντχόφεν (2-3) κι ας μην πήρε αποτέλεσμα. Η Εστορίλ δεν έχει ουδεμία σχέση με τη δυναμικότητα Ρώσων και Ολλανδών και προσφέρεται για τη νίκη - γόητρο που επιθυμεί το Τριφύλλι. Στο 2,20 ο άσος, μας φαίνεται αρκετά δυνατός.</strong></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΠΑΟΚ - ΓΚΙΝΓΚΑΜΠ ', '1418299777', 'opw.jpg', '<p><span style="font-size:14px"><strong>ΠΑΟΚ (3ος - 7β)</strong><span style="font-family:tahoma,arial,helvetica,sans-serif">&nbsp;- Προκρίνεται μόνο με νίκη στους «32» του Europa League και έχει την… τύχη να παίζει τον υπέρ πάντων αγώνα στην Τούμπα. Στα δύο ευρωπαϊκά παιχνίδια που προηγήθηκαν, ο «Δικέφαλος» ανέβασε την απόδοσή του και αφού αρχικά απέσπασε ισοπαλία από τη Φιορεντίνα στην Ιταλία (1-1), στη συνέχεια έφερε τον όμιλο στα μέτρα του, κερδίζοντας με 2-0 την Ντιναμό Μινσκ εκτός έδρας. Στο πρωτάθλημα γνώρισε την ήττα στην Ξάνθη με 4-2 σε ένα «τρελό» παιχνίδι, όπου σε καμία περίπτωση δε φαινόταν ότι θα σημειωθούν 6 γκολ. Η ζημιά έγινε κατά το ήμισυ αφού προηγουμένως είχε χάσει βαθμούς και ο Ολυμπιακός (στο -4) και στη αργότερα και ο Παναθηναϊκός (στο -5). Ο ΠΑΟΚ καλείται να παρουσιαστεί πιο συμπαγής για να μη δώσει δικαιώματα στους Γάλλους, οι οποίοι τον εξέθεσαν στον πρώτο αγώνα (2-0). Τα προβλήματα για τον Αναστασιάδη δεν είναι λίγα. Οι Κατσικάς και Μακ έμειναν εκτός αποστολής, ενώ λιγότερο σοβαρά προβλήματα αντιμετωπίζουν οι Τζαβέλλας και Τζιόλης. Αμφίβολη κρίνεται η συμμετοχή του Σκόνδρα.&nbsp;</span><br />
<br />
<strong>ΓΚΙΝΓΚΑΜΠ (2η - 7β)&nbsp;</strong><span style="font-family:tahoma,arial,helvetica,sans-serif">- Έχασε μεγάλη ευκαιρία να αυξήσει τις πιθανότητές της για πρόκριση, όταν ηττήθηκε από τη Φιορεντίνα στη Γαλλία (1-2). Ο προπονητής Γκουβερνέκ δε φοβάται σε καμία περίπτωση την ατμόσφαιρα της Τούμπας, κάτι που επιβεβαίωσε και ο Ματίς. Στη Θεσσαλονίκη είχε ταξιδέψει ο βασικός μέσος Ντιαλό ώστε να εξαντλήσει τις πιθανότητες να αγωνιστεί στο κρίσιμο παιχνίδι, όμως τελικά έμεινε εκτός αποστολής και προστέθηκε στη λίστα των απόντων. Οι Σαμασά (Τ), Λεμέτρ (Α), Μαρβό (Μ), Σβαρτς (Ε) και Ντουνιαμά είναι εκτός μάχης. Οι φιλοξενούμενοι προέρχονται από δύο πολύ μεγάλες νίκες στο γαλλικό πρωτάθλημα, το 5-1 επί της Καέν εντός και το 3-2 επί της Ρεμς εκτός έδρας, με τις οποίες ανέβηκαν 3β. πάνω από τη ζώνη του υποβιβασμού. Χωρίς ισοπαλία μακριά από την έδρα της από το ξεκίνημα της σεζόν (3-0-5), συνηθίζει τα μεγάλα σκορ και ελπίζει πως αυτή τη φορά θα αποδειχθεί συμπαγής και αμυντικά.</span><br />
<br />
<strong>ΕΚΤΙΜΗΣΗ / ΣΤΟΙΧΗΜΑ - Ο ΠΑΟΚ έχει την ευρωπαϊκή εμπειρία, κάτι που δεν ισχύει για την Γκινγκάμπ. Επίσης, η εξέδρα θα παίξει τον δικό της ρόλο στον αγώνα. Όσο λοιπόν και αν οι Γάλλοι πιστεύουν ότι δε θα επηρεαστούν από την παρουσία του κόσμου, η πραγματικότητα μάλλον θα αποδειχθεί διαφορετική. Μένει ο ΠΑΟΚ να εμφανιστεί και αγωνιστικά έτοιμος για να πάρει τη νίκη και την πρόκριση στην επόμενη φάση.</strong></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Παρασκευής', '1418388181', 'deite-poses-xiliades-evro-evgale-enas-25xronos-apo-ta-giannitsa-sto-st_2.jpg', '<p><span style="color:#FF0000">102.</span> ΣΑΝΤΧΑΟΥΖΕΝ - ΜΠΟΧΟΥΜ (19.30) &nbsp;<span style="color:#DAA520">Χ2 ΔΕ</span></p>

<p><span style="color:#FF0000">108</span>. ΚΡΕΤΕΙΓ-ΑΡΛ (21.00) &nbsp;<span style="color:#DAA520">2-3 ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">114.</span> ΒΑΛΒΑΙΚ-ΧΕΛΜΟΝΤ ΣΠΟΡ (21.00) <span style="color:#DAA520">ΓΚΟΛ&nbsp;</span></p>

<p><span style="color:#FF0000">128.</span> ΑΛΜΕΡΙΑ-ΡΕΑΛ (21.45) <span style="color:#DAA520">UNDER 3.5</span></p>

<p>Για μέγιστες αποδόσεις και κέρδη στην</p><script src=''http://affiliates.2winbet.gr/banmake.php?type=1&name=JPG-logo-90x60&id=52''></script>
<div id=''vivaswfid52''></div>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Euroleague Basketball', '1418388883', '1.jpg', '<p><span style="color:#FF0000">Ειδικές επιλογές...</span>.</p><p>1. <span style="color:#0000CD">Ούνιξ Καζάν -Ζαλγκίρις </span>&nbsp; ----&gt; <span style="color:#DAA520">Πόντοι φιλοξενούμενης ομάδας οβερ 67.5</span> &nbsp; <span style="color:#FF0000">&nbsp;(1.80)</span></p><p>2.<span style="color:#0000CD">Αναντολού Εφές - Νίζνι </span>------&gt; <span style="color:#DAA520">Πόντοι γηπεδούχο ομάδας οβερ 78.5</span> &nbsp; <span style="color:#FF0000">(1.88)</span></p><p>3.<span style="color:#0000CD">Λαμποράλ Κούτσα-Βαλένθια</span> ------&gt; <span style="color:#DAA520">Νίκη γηπεδουχος</span> &nbsp;<span style="color:#FF0000"> &nbsp;(1.66)</span></p><p>&nbsp;</p><p>Συνολική απόδοση 5.61 στην</p><div id="vivaswfid52">&nbsp;</div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σαββάτου', '1418481172', 'deite-poses-xiliades-evro-evgale-enas-25xronos-apo-ta-giannitsa-sto-st_2.jpg', '<p><span style="color:#FF0000">401.</span> ΑΕΛ ΚΑΛΛΟΝΗΣ-ΠΑΝΑΙΤΩΛΙΚΟΣ (17.15) <span style="color:#DAA520">1Χ ΔΕ</span></p>

<p><span style="color:#FF0000">215.</span>ΝΑΝΤ-ΜΠΟΡΝΤΟ (18.00) <span style="color:#DAA520">2-3 ΓΚΟΛ</span></p>

<p><span style="color:#FF0000">220</span>.ΒΑΛΕΝΘΙΑ-ΒΑΓΙΕΚΑΝΟ (19.00) <span style="color:#DAA520">1</span></p>

<p><span style="color:#FF0000">223</span>.ΠΑΛΕΡΜΟ-ΣΑΣΣΟΥΟΛΟ (19.00)<span style="color:#DAA520"> Χ2 ΔΕ</span></p>

<p>&nbsp;</p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις με γκολ.. απο Αγγλία ', '1409669635', '82869.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000">101</span>. ΚΡΟΥ- ΡΟΤΣΝΤΕΙΛ ( 21.30)<span style="color:#DAA520"> ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">105.</span> ΓΟΥΙΚΟΜ- ΚΟΒΕΝΤΡΙ (21.45) <span style="color:#DAA520">&nbsp;ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">107</span>. ΚΡΟΟΥΛΙ- ΚΕΜΠΡΙΤΖ(21.45) <span style="color:#DAA520">ΓΚΟΛ</span></span></p>

<p><span style="font-size:14px"><span style="color:#FF0000">111</span>. ΠΡΕΣΤΟΝ-ΣΡΙΟΥΣΜΠΕΙ(21.45) <span style="color:#DAA520">ΓΚΟΛ</span></span></p>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Επιστροφή της Paysafecard', '1443021265', 'paysafe_card.jpg', '<p><span style="font-size:14px"><span style="color:rgb(0, 0, 255)">Διαθέσιμη ξανα η έκδοση κωδικών pin στην Ελλάδα...</span></span></p><p><span style="font-size:13px"><span style="font-family:arial"><span style="font-size:14px">&nbsp; <span style="color:rgb(255, 0, 0)">Αναλυτικά η ανακοίνωση </span></span><br><br><span style="font-size:14px"><em>Η paysafecard επέστρεψε στην Ελλάδα και η αγορά paysafecard PINs είναι άμεσα εφικτή. Πληρωμές σε επιλεγμένα ηλεκτρονικά καταστήματα. Μπορείς να βρεις όλες τις πληροφορίες εδώ.<br><br>Η paysafecard είναι η πλέον αγαπημένη και προτιμώμενη online προπληρωμένη κάρτα της Ευρώπης. Με την paysafecard πληρώνεις στο διαδίκτυο εύκολα, γρήγορα και με ασφάλεια σε όλους τους γνωστούς παρόχους σε τομείς όπως Games, Social Media &amp; Communities, Musik, Film &amp; Entertainment και αμέτρητες άλλες κατηγορίες.</em></span></span></span><br>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πάοκ- Άεκ (εκτός κουπονιού) 20.30 ', '1443021858', 'katalogos.jpg', '<p><span style="font-size:14px"><span style="color:#000000"><strong>Ντερμπυ δικεφάλων...</strong></span></span></p><p><span style="font-size:14px">Δεν πραγματοποιεί και το καλύτερο δυνατό ξεκίνημα ο ΠΑΟΚ, ο οποίος όμως πανηγύρισε το πρώτο του τρίποντο στο πρωτάθλημα στη Βέροια. Αήττητη πηγαίνει στην Τούμπα η ΑΕΚ, που θα προσπαθήσει πρωτίστως να διαφυλάξει τα νότα της και εν συνεχεία θα ψάξει το γκολ.<span style="background-color:#008080">ΠΡΟΤΑΣΗ : ΗΜ. Χ</span><span style="color:#008000"> </span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Άνοιγμα οπαπ σε σουπερλίγκα...', '1443024246', 'images.jpg', '<p><span style="font-size:13px"><span style="font-family:arial"><span style="font-size:14px">Η Σούπερ Λίγκα ζητάει ως «ελάχιστη προσφερόμενη αποδεκτή αμοιβή» για τη χορηγία του πρωταθλήματος το ποσό των 3 εκατ. ευρώ(περιλαμβανομένου του ΦΠΑ, οπότε το καθαρό ποσό είναι 2,290 εκατ. ευρώ), όπως αναφέρεται στη σχετική πρόσκληση εκδήλωσης ενδιαφέροντος και υποβολής προσφορών που δημοσιοποιήθηκε χθες.<br><br>Η προθεσμία για την υποβολή προσφορών λήγει την ερχόμενη Παρασκευή 25 Σεπτεμβρίου στις 4 το απόγευμα και η Λίγκα δεν δέχεται να υπάρχει όρος αποκλειστικότητας στη συμφωνία, όπως ήθελε ο<strong><a class="newLink" href="http://www.betarades.gr/kouponi_c_1.html" title="Κουπόνι πάμε στοίχημα"> ΟΠΑΠ</a></strong>, προκειμένου να μη διαφημίζουν κάποιες ομάδες στη φανέλα τους εταιρείες ανταγωνιστικές στον Οργανισμό. Στην πρόσκληση ενδιαφέροντος αναφέρεται χαρακτηριστικά ότι "οι προσφορές οι οποίες θα έχουν ως όρο τη δέσμευση των επιμέρους ΠΑΕ μελών της Σούπερ Λίγκα περί μη προβολής ανταγωνιστών του προσφέροντα στον ιματισμό ή στις γηπεδικές εγκαταστάσεις ή σε άλλα περιουσιακά στοιχεία που ανήκουν στην κυριότητα ή εκμετάλλευση ή χρήση αυτών, δεν θα γίνονται αποδεκτές".<br><br>Στην περίπτωση που υπάρξει συμφωνία για την ονοματοδοσία του πρωταθλήματος, η σύμβαση θα ισχύσει από την 6η ή την 7η αγωνιστική. Με τις υπογραφές η Λίγκα θα εισπράξει τουλάχιστον το 20% της προσφερόμενης αμοιβής και η εξόφληση του 90% του συνολικού ποσού θα πρέπει να καταβληθεί το αργότερο με τη λήξη της κανονικής περιόδου του πρωταθλήματος και πριν από την έναρξη των play-off.<br><br>Στη Λίγκα υποστηρίζουν πως βρίσκονται σε συζητήσεις με τρεις εταιρείες, οι δύο από τις οποίες είναι στοιχηματικές, και στις προθέσεις τους είναι να καταθέσουν προσφορά. Τις εξελίξεις πάντως στο θέμα παρακολουθεί διακριτικά και ο ΟΠΑΠ, ο οποίος από το 2006 και μέχρι το περσινό πρωτάθλημα ήταν ο μέγας χορηγός του. Σύμφωνα με πληροφορίες ο Οργανισμός έστειλε επιστολή στον Γιώργο Μποροβήλο και αφήνει ανοιχτό το ενδεχόμενο να κάνει χρήση δικαιώματος που απορρέει από την προηγούμενη σύμβαση που είχε με τον συνεταιρισμό, βάσει του οποίου μπορεί να πάρει την ονοματοδοσία του πρωταθλήματος, αρκεί να δώσει το ίδιο ποσό της μεγαλύτερης προσφοράς που θα κατατεθεί.</span><br><br><strong>Πηγή: </strong>LIVE SPORT </span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Τριάδα για μεροκάματο', '1443082297', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:rgb(255, 0, 0)">1109.&nbsp;</span> ΕΛΦΣΜΠΟΡΓΚ -ΓΚΕΤΕΜΠΟΡΓΚ&nbsp; &nbsp; (20.05) &nbsp; &nbsp; <span style="color:rgb(0, 0, 128)">2-3 ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:rgb(255, 0, 0)">659. </span>&nbsp;&nbsp; ΕΜΠΟΛΙ-ΑΤΑΛΑΝΤΑ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (21.45) &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:rgb(0, 0, 128)"> ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:rgb(255, 0, 0)">740.</span> &nbsp;&nbsp; ΜΠΕΤΙΣ-ΛΑΚΟΡΟΥΝΙΑ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (23.05) &nbsp; &nbsp; &nbsp; &nbsp; <span style="color:rgb(0, 0, 128)">ΟΒΕΡ&nbsp; &nbsp; &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Νομοθεσία για τα  bonus στοιχηματικων εταιρειών', '1443082938', 'bonus.jpg', '<p><span style="font-size:16px">Σύμφωνα με τον νόμο (ΦΕΚ/B/1368) που ψηφίστηκε στην Ελληνική Βουλή και τέθηκε σε ισχύ την 01/09/2014<span style="color:#FF0000"> απαγορεύεται</span> οι στοιχηματικές <span style="color:#0000FF">εταιρείες ή οι ιστοσελίδες</span> που παρουσιάζουν στοιχηματικές εταιρείες, <span style="color:#FF0000">να διαφημίζουν οποιοδήποτε μπόνους</span> προσφέρει η εκάστοτε στοιχηματική εταιρεία είτε μεσω μπάνερ είτε μέσω κειμένου.</span></p><p style="text-align:justify"><span style="font-size:16px">Δημοσιεύθηκε στην Εφημερίδα της Κυβερνήσεως (ΦΕΚ/B/1368) η απόφαση για την ρύθμιση θεμάτων εμπορικής επικοινωνίας τυχερών παιγνίων.</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Παρασκευής', '1443189438', 'stoixima.jpg', '<p><span style="color:#FFA07A">1047.</span><span style="color:#FF0000"> </span><span style="color:#DAA520">ΚΡΕΤΕΙΓ-ΧΑΒΡΗ&nbsp; (21.00)&nbsp;</span><span style="color:#FF0000">&nbsp;&nbsp;</span><span style="color:#0000CD"> ΓΚΟΛ</span></p><p><span style="color:#FFA07A">1053.</span> <span style="color:#DAA520">ΑΖΑΞΙΟ-ΟΣΕΡ&nbsp;&nbsp;&nbsp; (21.00)&nbsp;</span>&nbsp;&nbsp;&nbsp; <span style="color:#0000CD">ΟΒΕΡ</span></p><p><span style="color:#FFA07A">561.</span><span style="color:#DAA520">ΦΟΥΛΑΜ-ΚΠΡ &nbsp; &nbsp; &nbsp; (21.45)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp; <span style="color:#0000CD">ΙΧ</span></p><div>&nbsp;</div>







<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179603);</script><div data-ti="14927_179603"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πάμε ταμείο', '1443270613', 'stoixima.jpg', '<p><span style="color:#FF0000">1152</span><span style="color:#FF8C00">. ΚΑΛΙΑΡΙ-ΛΑΤΙΝΑ&nbsp; (16.00)&nbsp;</span>&nbsp; <span style="color:#000080">1</span></p><p><span style="color:#FF0000">611</span>.<span style="color:#DAA520">ΚΑΛΛΟΝΗ-ΠΑΝΑΙΤΩΛΙΚΟΣ (16.00)&nbsp;&nbsp;</span> <span style="color:#000080">ΗΜ. Χ</span></p><p><span style="color:#FF0000">773</span>.<span style="color:#DAA520">ΒΟΛΦΣΜΠΟΥΡΓΚ-ΑΝΝΟΒΕΡΟ (1630)&nbsp;</span>&nbsp;&nbsp; <span style="color:#000080">1</span></p><p><span style="color:#FF0000">727</span><span style="color:#DAA520">.ΣΕΒΙΛΛΗ-ΒΑΓΙΕΚΑΝΟ (21.30)&nbsp;&nbsp;</span> <span style="color:#000080">1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Paysafecard..σταδιακά οι εταιρείες επαναφέρουν τις συναλλαγες...', '1443271117', 'paysafe_card.jpg', '<p>Η έκδση κωδικών επέστρεψε στην Ελλάδα και σταδιακα οι στοιχηματικές εταιρέιες δέχονται συναλλαγες..Μέχρι σήμερα paysafe δέχονται η bet365 , magicbet και betshop..</p><p>Συντομα αναμένεται να αποκασταθεί πλήρως η λειτουργια στο συνολο των στοιχηματικών εταιρειών..</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Επιλογές Σαββάτου..', '1443343193', 'pame_tameio.jpg', '<p><span style="color:#FF0000">951.</span>&nbsp; <span style="color:#DAA520">ΜΑΡΣΕΙΓ-ΑΝΖΕ (15.00)&nbsp;</span><span style="color:#000080"> 1</span></p><p><span style="color:#FF0000">997.</span>&nbsp; <span style="color:#DAA520">ΛΟΚΕΡΕΝ-ΚΛΑΜΠ ΜΠΡΙΖ(15.30)&nbsp;</span> <span style="color:#000080">ΓΚΟΛ</span></p><p><span style="color:#FF0000">867.&nbsp;</span> <span style="color:#DAA520">ΣΑΣΣΟΥΟΛΟ-ΚΙΕΒΟ&nbsp; (16.00)</span>&nbsp;<span style="color:#000080"> 1</span></p><p><span style="color:#FF0000">615</span>.&nbsp; <span style="color:#DAA520">ΠΑΝΙΩΝΙΟΣ-ΠΑΝΘΡΑΚΙΚΟΣ (18.15)</span> <span style="color:#000080">1</span></p><p><span style="color:#FF0000">617.</span><span style="color:#DAA520">&nbsp; ΛΕΒΑΔΕΙΑΚΟΣ-ΑΣΤΕΡΑΣ ΤΡΙΠΟΛΗΣ (18.15)</span> <span style="color:#000080">ΗΜ Χ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('SUPERLEAGUE Παναθηναικός-Πλατανιάς ', '1443348621', 'images.jpg', '<p><span style="color:#FF0000">Ανάλυση αγωνιστικής..</span></p><p style="text-align:justify"><span style="color:#0000CD">614.ΠΑΝΑΘΗΝΑΙΚΟΣ-ΠΛΑΤΑΝΙΑΣ(16.00)</span>.Τη περασμένη τετάρτη σε ένα 20 λεπτο σκόρπισε τον Λεβαδειακό και θα προσπαθήσει να το επαναλαβεισήμερα κόντρα στον Πλάτανιά που δεν έχει ξεκινήσει θετικά και θα πασχίσει να κρατήσει το μηδέν στην άμυνα αν και δύσκολο..χωρίς τιμή ο άσσος συνεπώς επιλογές με γκολ φαντάζουν ιδανικές<span style="color:#DAA520">.ΕΚΤΙΜΗΣΗ: 4-6 ΓΚΟΛ.</span></p><p style="text-align:justify">&nbsp;</p><p style="text-align:justify">&nbsp;</p><p style="text-align:justify">&nbsp;</p><p style="text-align:justify">&nbsp;</p><p>&nbsp;</p><p style="text-align:justify">&nbsp;</p><p></p>




<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179620);</script><div data-ti="14927_179620"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Μικρό κουπόνι σήμερα και επιλέγουμε γκολ και σημεία απο Τουρκία', '1443427039', 'pame_tameio.jpg', '<p><span style="color:#FF0000">1066.</span> ΚΑΣΙΜΠΑΣΑ-ΡΙΖΕΡΣΠΟΡ (19.00)&nbsp; <span style="color:#0000FF">1</span></p><p><span style="color:#FF0000">1087.</span>ΑΝΤΑΝΑΣΠΟΡ-ΜΑΛΑΤΙΑ (19.00) <span style="color:#0000FF">ΓΚΟΛ</span></p><p><span style="color:#FF0000">1067</span>.ΜΠΟΥΡΣΑΣΠΟΡ-ΕΣΚΙΣΕΧΕΡΣΠΟΡ (20.00)<span style="color:#0000FF"> 2-3 ΓΚΟΛ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('UEFA Champions League', '1443507384', 'gun_1381310671_uefa_champions_league.jpg', '<p><span style="color:#FF0000">985.&nbsp;</span> ΜΠΑΓΕΡΝ-ΝΤΙΝΑΜΟ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> 4-6 ΓΚΟΛ</span></p><p><span style="color:#FF0000">986.</span>&nbsp; ΑΡΣΕΝΑΛ-ΟΛΥΜΠΙΑΚΟΣ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">987</span>. ΜΠΑΤΕ ΜΠΟΡΙΣΟΦ-ΡΟΜΑ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp; ΓΚΟΛ</span></p><p><span style="color:#FF0000">989.</span> ΜΠΑΡΤΣΕΛΟΝΑ-ΛΕΒΕΡΚΟΥΖΕΝ&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> 1/1</span></p><p><span style="color:#FF0000">990.</span> ΜΑΚΑΜΠΙ-ΝΤΙΝΑΜΟ ΚΙΕΒΟΥ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">ΗΜ Χ</span></p><p><span style="color:#FF0000">991 </span>.ΠΟΡΤΟ-ΤΣΕΛΣΙ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp;&nbsp;&nbsp; Χ</span></p><p><span style="color:#FF0000">992.</span> ΒΑΛΕΝΘΙΑ-ΛΥΩΝ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp;&nbsp; ΗΜ Χ</span></p><p><span style="color:#FF0000">993.</span>ΖΕΝΙΤ-ΓΑΝΔΗ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp; 2-3 ΓΚΟΛ</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('UEFA Champions League..δεύτερο πιάτο με τους αγώνες Τετάρτης', '1443596396', 'images.jpg', '<p><span style="color:#FF0000">969</span>.&nbsp;&nbsp; <span style="color:#FFA500">ΓΚΛΑΝΤΜΠΑΧ-ΜΑΝΤΣΕΣΤΕΡ ΣΙΤΙ </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> ΙΧ</span></p><p><span style="color:#FF0000">978.</span>&nbsp;<span style="color:#FFA500"> ΜΑΝΤΣΕΣΤΕΡ ΓΙΟΥΝ.-ΒΟΛΦΣΜΠΟΥΡΓΚ&nbsp;</span> &nbsp;<span style="color:#0000FF">&nbsp; ΓΚΟΛ</span></p><p><span style="color:#FF0000">980.</span>&nbsp;<span style="color:#FFA500"> ΑΤΛΕΤΙΚΟ ΜΑΔΡΙΤΗΣ -ΜΠΕΝΦΙΚΑ&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp; 1/1</span></p><p><span style="color:#FF0000">981&nbsp; </span><span style="color:#FFA500">ΓΙΟΥΒΕΝΤΟΥΣ-ΣΕΒΙΛΛΗ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">Χ/1</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p><span style="color:#0000FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>




                                                            <script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Juventus - Sevilla  ', '1443597261', 'images.jpg', '<p><span style="color:#FF0000">Διαφορετικό πρόσωπο η Γιουβε ..</span>.</p><p><span style="font-size:16px">Το χειροτερό της ξεκίνημα στην στορία της πραγματοποιεί η Γιουβε στο Ιταλικό πρωτάθλημα όπου μετρά 5 βαθμούς σε έξι αγωνιστικές και αποκορύφωση την ήττα 201 από τη Νάπολι .Τεράστιο το όνομα της Γιουβε όμως και αναμένεται να δούμε ένα διαφορετικό πρόσωπο όπως στο Σίτι που επικράτησε 1-2 .Η Σεβίλλή έχει να αντιμετωπίσει το πρόβλημα των απουσιών και σταδικά βελτιώνεται δύσκολα όμως να φύγει με βαθμούς από το Τορίνο . <span style="color:rgb(0, 0, 255)">ΕΚΤΙΜΗΣΗ Χ/1</span></span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>


                  <script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('EUROPA LEAGUE', '1443710278', 'europa.jpg', '<p><span style="color:#FF0000">787.</span> ΛΑΤΣΙΟ-ΣΕΝΤ ΕΤΙΕΝ&nbsp; (20.00)&nbsp;&nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></p><p><span style="color:#FF0000">788.</span>ΜΠΕΣΙΚΤΑΣ-ΣΠΟΡΤΙΝΚΓ ΛΙΣ (20.00)&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> ΗΜ Χ</span></p><p><span style="color:#FF0000">806.</span>ΜΟΝΑΚΟ-ΤΟΤΕΝΑΜ (20.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">Χ</span></p><p><span style="color:#FF0000">839.</span>ΒΙΓΙΑΡΕΑΛ.ΒΙΚΤΟΡΙΑ (22.05)&nbsp; <span style="color:#0000FF">1</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Μια τριάδα για σήμερα Παρασκευή..Πέρασαν αρκετά απο τα χθεσινά ', '1443766173', 'stoixima.jpg', '<hr><hr><p style="text-align:justify"><big><span style="font-size:16px"><span style="color:#FF0000">Πέρασαν αρκετές επιλογές μας χτες από το europa league , για όσους δεν ακολούθησαν η σημερινή τριάδα προσφέρεται για ρεφάρισμα!!</span></span></big></p><p><big><span style="font-size:16px"><span style="color:#FF0000">1184.</span>ΛΑΜΙΑ-ΠΑΝΑΙΓΙΑΛΕΙΟΣ (18.00)&nbsp;<span style="color:#0000FF"> 1</span></span></big></p><p><big><span style="font-size:16px"><span style="color:#FF0000">697.</span>ΝΟΡΤΖΕΛΑΝΤ-ΟΝΤΕΣΕ (19.00)&nbsp;<span style="color:#0000FF"> ΓΚΟΛ</span></span></big></p><p><big><span style="font-size:16px"><span style="color:#FF0000">739.</span>ΜΠΙΛΕΦΕΝΤ-ΜΟΝΑΧΟ 1860 (19.30)&nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></big></p><p>&nbsp;</p><div>&nbsp;</div>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Επιλογές με γκόλ...', '1443851466', 'pame_tameio.jpg', '<p><span style="color:#FF0000">741.</span> ΣΑΝ ΠΑΟΥΛΙ-ΣΑΝΤΧΑΟΥΖΕΝ&nbsp; (14.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <span style="color:#0000FF">&nbsp;ΓΚΟΛ</span></p><p><span style="color:#FF0000">998.</span>&nbsp;ΛΑΤΙΝΑ-ΜΠΑΡΙ (16.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">665.</span>ΓΚΛΑΝΤΜΠΑΧ-ΒΟΛΦΣΜΠΟΥΡΓΚ (16.30)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">ΟΒΕΡ</span></p><p><span style="color:#FF0000">720.</span>ΝΑΙΜΕΓΚΕΝ-ΝΕΕΝ ΧΑΑΓΚ&nbsp; (17.30)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></p><p>&nbsp;</p>

<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Superleague ....Αγώνες Σαββάτου', '1443851846', 'superleague.jpg', '<p><span style="color:#0000FF">937. </span><span style="color:#FF8C00">ΠΑΝΘΡΑΚΙΚΟΣ-ΛΕΒΑΔΕΙΑΚΟΣ (16.00)&nbsp;</span>&nbsp;&nbsp; <span style="color:#0000FF">ΗΜ Χ</span></p><p><span style="color:#0000FF">938 .</span><span style="color:#FF8C00">ΠΑΝΑΙΤΩΛΙΚΟΣ-ΠΑΝΙΩΝΙΟΣ (18.15)</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> 1</span></p><p><span style="color:#0000FF">939 .</span><span style="color:#FF8C00">ΞΑΝΘΗ-ΠΑΝΑΘΗΝΑΙΚΟΣ (20.30)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> 2-3 ΓΚΟΛ</span></p>





<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Σύστημα Σαββάτου...', '1443852399', 'stoixima.jpg', '<p><span style="color:#FF0000">1101.</span> ΓΙΟΥΒΕ ΣΤΑΜΠΙΑ- ΚΑΣΕΡΤΑΝΑ&nbsp; (15.30)&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">1</span></p><p><span style="color:#FF0000">668.</span>ΧΕΡΤΑ-ΑΜΒΟΥΡΓΟ ( 16.30)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> Χ</span></p><p><span style="color:#FF0000">645. </span>ΑΣΤΟΝ ΒΙΛΑ-ΣΤΟΟΥΚ (17.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp; 2</span></p><p><span style="color:#FF0000">1158.</span>ΑΛΜΕΡΙΑ-ΤΕΝΕΡΙΦΗ (19.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> Χ</span></p><p style="text-align: justify;"><span style="color:#FF0000">939.</span>ΞΑΝΘΗ-ΠΑΝΑΘΗΝΑΙΚΟΣ (20.30)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> χ</span></p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#FF0000">&nbsp;&nbsp;&nbsp; Ζητάμε Τριάδες.</span></p><div>&nbsp;</div><div>&nbsp;</div><div>&nbsp;</div><div>&nbsp;</div><div>&nbsp;</div><div>&nbsp;</div><div>&nbsp;</div><div>&nbsp;</div><p style="text-align: justify;">&nbsp;</p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Παιχνίδι με έδρες...', '1443940741', 'z.jpg', '<p>&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">699.</span>ΒΑΓΙΕΚΑΝΟ-ΜΠΕΤΙΣ (13.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> &nbsp; 1</span></p><p>&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">684.</span> ΜΟΝΑΚΟ-ΡΕΝ (15.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; <span style="color:#0000FF">&nbsp;1</span></p><p>&nbsp;&nbsp; &nbsp;<span style="color:#0000FF">670.&nbsp; </span>ΣΑΛΚΕ-ΚΟΛΩΝΙΑ(16.30)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> &nbsp;1</span></p><p>&nbsp;&nbsp; <span style="color:#0000FF">1166</span>.ΟΣΑΣΟΥΝΑ-ΛΟΥΓΚΟ (18.00)&nbsp;&nbsp;&nbsp; &nbsp;<span style="color:#0000FF"> 1</span></p>



                                   <script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Δυάδα  από το Νησί...', '1443941157', 'premier2012.jpg', '<p>&nbsp;<span style="color:#FF0000">662. </span><span style="color:#FF8C00">ΣΟΥΟΝΣΙ-ΤΟΤΕΝΑΜ&nbsp; (18.00)&nbsp;&nbsp;</span><span style="color:#0000FF"> 2</span></p><p><span style="color:#FF0000">&nbsp;663</span>.<span style="color:#FF8C00">ΑΡΣΕΝΑΛ-ΜΑΝΤΣΕΣΤΕΡ ΓΙΟΥΝ (18.00)</span>&nbsp;<span style="color:#0000FF"> Χ</span></p>



                                                                           <script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div> ');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Superleague Greece.....', '1443941730', '010214115742_2538.jpg', '<p>&nbsp; <span style="color:#FF0000">940.</span> <span style="color:#FF8C00">ΠΑΣ ΓΙΑΝΝΙΝΑ-ΗΡΑΚΛΗΣ 1908 (18.15)&nbsp;</span> &nbsp;&nbsp;<span style="color:#0000CD">2-3 ΓΚΟΛ</span></p><p>&nbsp;&nbsp;<span style="color:#FF0000">941</span>. <span style="color:#FF8C00">ΑΕΛ ΚΑΛΛΟΝΗΣ-ΒΕΡΟΙΑ (18.15)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></p><p>&nbsp;<span style="color:#FF0000"> 942 </span>.<span style="color:#FF8C00">ΠΑΟΚ-ΟΛΥΜΠΙΑΚΟΣ (20.30)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<span style="color:#0000FF">ΗΜ Χ</span></p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Γκολάκια για σήμερα Δευτέρα..', '1444028866', 'goal_goal_goal_logo.png', '<p><span style="color:#FF0000">1089</span>. <span style="color:#FF8C00">ΜΑΡΙΕΧΑΜΝ - ΡΟΒΑΝΙΕΜΙ (18.00)</span>&nbsp;&nbsp;<span style="color:#0000FF"> ΓΚΟΛ </span></p><p><span style="color:#FF0000">943</span> .<span style="color:#FF8C00">ΑΣΤΕΡΑΣ ΤΡΙΠΟΛΗΣ-ΠΛΑΤΑΝΙΑΣ (19.30)</span> <span style="color:#0000FF">ΝΟ ΓΚΟΛ </span></p><p><span style="color:#FF0000">963</span>.<span style="color:#FF8C00">&nbsp; ΣΙΡΙΟΥΣ-ΦΡΕΙ (20.00)&nbsp; </span><span style="color:#0000FF">ΓΚΟΛ</span></p><p><span style="color:#FF0000">1017.</span><span style="color:#FF8C00">ΤΟΥΡ-ΝΤΙΖΟΝ (21.30)</span>&nbsp;&nbsp;<span style="color:#0000FF">&nbsp; 2-3 ΓΚΟΛ </span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Σύστημα από το νησί ...', '1444109681', 'z.jpg', '<p><span style="color:#FF0000">527.</span> <span style="color:#FF8C00">ΓΚΙΣΕΛΙ-ΜΑΚΛΣΦΙΛΝΤ (21.45)&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">2</span></p><p><span style="color:#FF0000">528.</span><span style="color:#FF8C00">ΚΙΝΤΕΡΜΙΝΣΤΕΡ-ΜΠΟΡΕΧΑΜ (21.45)</span>&nbsp;&nbsp; <span style="color:#0000FF">1</span></p><p><span style="color:#FF0000">551.</span> <span style="color:#FF8C00">ΜΠΡΙΣΤΟΛ-ΓΟΥΙΚΟΜ (21.45)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<span style="color:#0000FF"> Χ</span></p><p><span style="color:#FF0000">554</span><span style="color:#FF8C00">.ΦΛΙΤΓΟΥΝΤ-ΣΡΙΟΥΣΜΠΕΡΙ (21.45) &nbsp; &nbsp;</span> &nbsp;&nbsp; <span style="color:#0000FF">2</span></p><p><span style="color:#FF0000">559</span>.<span style="color:#FF8C00">ΚΡΟΟΥΛΙ-ΣΑΟΥΘΕΝΤ (21.45)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<span style="color:#0000FF"> 2</span></p><p><span style="color:#0000FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ζητάμε Τριάδες..</span></p><p>&nbsp;</p><p><span style="color:#0000FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Το Stoiximan.gr μεγάλος χορηγός της ΠΑΕ Ολυμπιακός', '1444126422', 'stoiximan.jpg', '<p>Η ΠΑΕ Ολυμπιακός και η <a href="https://www.stoiximan.gr/">Stoiximan</a> ανακοίνωσαν την σύναψη χορηγικής συμφωνίας, με το <a href="https://www.stoiximan.gr/">Stoiximan.gr</a> να αποτελεί τον μεγάλο χορηγό των νταμπλούχων.</p><p>Αναλυτικά η ανακοίνωση:</p><p>«Η κορυφαία ελληνική εταιρεία στοιχηματισμού στο διαδίκτυο θα κοσμεί από αυτή την Κυριακή τη φανέλα του Ολυμπιακού. Πέρα από τη χορηγική συμφωνία, η ΠΑΕ Ολυμπιακός και η <a href="https://www.stoiximan.gr/">Stoiximan</a>, οι οποίες υλοποιούν ήδη σημαντικές κοινωνικές δράσεις, δεσμεύτηκαν στην εφαρμογή ενός κοινού προγράμματος κοινωνικής προσφοράς και υπευθυνότητας.»</p><p>Ο Γιάννης Βρέντζος, Διευθύνων Σύμβουλος της ΠΑΕ Ολυμπιακός, υπογράμμισε: «Καλωσορίζουμε τη <a href="https://www.stoiximan.gr/">Stoiximan</a> στη μεγάλη οικογένεια του Ολυμπιακού. Το όραμά μας στον Ολυμπιακό ξεφεύγει από τα στενά όρια της αγωνιστικής δράσης και εκτείνεται στη συμμετοχή, στην προσφορά και στην αλληλεγγύη. Είμαι σίγουρος ότι η <a href="https://www.stoiximan.gr/">Stoiximan</a> θα είναι κοινωνός αλλά και αρωγός του οράματός μας αυτού. Ξεκινάμε μια σχέση εμπιστοσύνης και συμπόρευσης. Είμαστε χαρούμενοι που συνεργαζόμαστε με μια εταιρεία που επενδύει σημαντικά στον ελληνικό αθλητισμό και μέσω αυτού και στην ελληνική κοινωνία».</p><p>Ο Ιωάννης Σπανουδάκης, μέλος του Δ.Σ. της <a href="https://www.stoiximan.gr/">Stoiximan</a>, με αφορμή την επίσημη ανακοίνωση της συμφωνίας, σημείωσε: «Είμαστε ιδιαίτερα ευτυχείς για την επίτευξη αυτής της συνεργασίας. Η μεγαλύτερη ελληνική εταιρεία στοιχηματισμού στο διαδίκτυο ενώνει φυσιολογικά τον δρόμο της με τον μεγαλύτερο και πλέον επιτυχημένο ποδοσφαιρικό σύλλογο της χώρας. Η χρονική στιγμή δε της ανακοίνωσης, μετά από τη μεγάλη ευρωπαϊκή επιτυχία του Ολυμπιακού, καταδεικνύει τον κοινό μας τόπο: σκληρή δουλειά, καταξίωση, κορυφή. Είναι εξίσου σημαντικό για εμάς επίσης, ότι συνενώνουμε τις δυνάμεις μας πέρα από την εμπορική συνεργασία και σε ένα πλαίσιο προσφοράς και δράσεων κοινωνικής υπευθυνότητας».</p><p>Το `ντεμπούτο'' του <a href="https://www.stoiximan.gr/">Stoiximan.gr </a>στη φανέλα του Ολυμπιακού θα πραγματοποιηθεί στο παιχνίδι για την 6η αγωνιστική του Πρωταθλήματος της Super League, με τον ΠΑΟΚ, ενώ θα ακολουθήσει μέσα στις επόμενες μέρες ειδική εκδήλωση για την παρουσίαση της χορηγικής συμφωνίας.</p><p>Να σημειωθεί πως η <a href="https://www.stoiximan.gr/">Stoiximan</a> στηρίζει χορηγικά, εδώ και δύο χρόνια, εθνικές ομάδες, συλλόγους καθώς και αθλητές από όλο το φάσμα του ελληνικού αθλητισμού.</p><p>&nbsp;</p><p>&nbsp;</p><p>ΠΗΓΗ: sentragoal.gr</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Κατάθεση με moneysafe card στην 2winbet...', '1444149327', 'moneysafe_2winbet.png', '<p><span style="color:#FF0000">Aπολαύσετε όλες τις υπηρεσίες της </span><a href="http://2winbet.gr/?btag=15559" target="_blank"><span style="color:#FF0000">2winbet</span></a><span style="color:#FF0000">, στο αθλητικό στοίχημα, στο καζίνο, στο πόκερ, στα εικονικά σπορ, αλλά και σε όλες τις live επιλογές, κάνοντας τις συναλλαγές σας (ΑΝΑΛΗΨΕΙΣ-ΚΑΤΑΘΕΣΕΙΣ) με ασφάλεια, ταχύτητα και συνέπεια μέσω της Moneysafe...</span></p><h5><span style="color:#FF8C00">Τι είναι η MoneySafe;</span></h5><p>*Πλήρης MasterCard® κάρτα<br>*Χωρίς πιστωτικό έλεγχο<br>*Παρακολούθηση λογαριασμού της κάρτας μέσω του online λογαριασμού σας<br>*Χρειάζεται απλά να είστε άνω των 18 ετών για να την αγοράσετε</p><p>Η MoneySafe κάρτα είναι μια επαναφορτιζόμενη προπληρωμένη MasterCard κάρτα που εκδίδεται επιτόπου. Λειτουργεί περίπου όπως οποιαδήποτε άλλη MasterCard αλλά το ότι είναι προπληρωμένη σημαίνει ότι δεν μπορείτε να ξοδέψετε περισσότερα χρήματα από αυτά που είναι διαθέσιμα στη κάρτα σας. Μπορείτε να χρησιμοποιήσετε τη <span style="color:#FF8C00">MoneySafe MasterCard</span> σε καταστήματα λιανικής, στο διαδίκτυο και σε όλα τα ATM παγκοσμίως οπουδήποτε οι MasterCard κάρτες είναι αποδεκτές. Ενεργοποιήστε τη κάρτα σας εύκολα και γρήγορα είτε μέσω της SMS ενεργοποίησης ή μέσω της διαδικτυακής ενεργοποίησης (online web activation) και είστε έτοιμοι να χρησιμοποιήσετε τη καινούργια σας<span style="color:#FF8C00"> MoneySafe MasterCard.</span></p><p>Η<span style="color:#FF0000"> </span><a href="http://2winbet.gr/?btag=15559" target="_blank"><span style="color:#FF0000">2winbet</span></a><span style="color:#FF0000"> </span>σας δίνει την δυνατότητα να καταθέσετε και χωρίς να διαθέτετε Moneysafe Card για πρώτη φορά. Αγοράστε Moneysafe Voucher από το περίπτερο σας και στείλτε τον κωδικό μέσω email ή live συνομιλίας που θα βρείτε στο<span style="color:#FF0000"> </span><a href="http://2winbet.gr/?btag=15559" target="_blank"><span style="color:#FF0000">2winbet.gr</span></a><span style="color:#FF0000"> </span>και οι υπεύθυνοι της<span style="color:#FF0000"> </span><a href="http://2winbet.gr/?btag=15559" target="_blank"><span style="color:#FF0000">2winbet</span></a><span style="color:#FF0000"> </span>θα πιστώσουν&nbsp; τα χρήματα στον λογαριασμό σας !</p><h5><span style="color:#FF8C00">Πως λειτουργεί;</span></h5><p>Με την προπληρωμένη MoneySafe MasterCard® μπορείτε να κάνετε αγορές στο διαδίκτυο με ασφάλεια οπουδήποτε επιδεικνύεται το σήμα της MasterCard. Οι προσωπικές πληροφορίες του λογαριασμού της τραπέζης σας και των πιστωτικών σας καρτών παραμένουν ασφαλείς και προστατευμένες .Οι αγορές σας φαίνονται μόνο στο διαδικτυακό σας λογαριασμό και ποτέ δε θα λάβετε μια κατάσταση με τις συναλλαγές σας στη διεύθυνση σας. Φυσικά η MoneySafe κάρτα μπορεί να χρησιμοποιηθεί για να κάνετε αναλήψεις και καταθέσεις στην <a href="http://2winbet.gr/?btag=15559" target="_blank">2winbet</a>.</p><h5><span style="color:#FF8C00">Σημεία Πώλησης:</span></h5><p>*Μπορείτε να βρείτε όλα τα σημεία πώλησης της MoneySafe Card στο εξής <a href="http://www.moneysafecard.com/el/store-locator.html."><span style="color:#FF8C00">http://www.moneysafecard.com/el/store-locator.html.</span></a></p><p><a href="http://2winbet.gr/?btag=15559" target="_blank"><span style="color:#FF0000">H 2winbet</span></a><span style="color:#FF0000"> </span>θέλοντας να κάνει ακόμη ευκολότερη την απόκτησή της από όλους τους πελάτες της, προσφέρει τη δυνατότητα αποστολής της Moneysafe Card με αντικαταβολή.<br>Εκτός αυτού όμως κάνουμε ακόμη ένα βήμα για τη δική σας ευκολία. Αν επικοινωνήσετε μαζί μας και μας δώσετε τον αριθμό του voucher της κάρτας σας, τότε μπορούμε εμείς να κάνουμε την κατάθεση των χρημάτων στο λογαριασμό σας.</p><h5><span style="color:#FF8C00">Επικοινωνία:</span></h5><p>Για οποιαδήποτε ερώτηση, απορία ή διευκρίνιση, είμαστε πάντα στη διάθεσή σας με τους εξής τρόπους επικοινωνίας:<br>*E-mail: support@<a href="http://2winbet.gr/?btag=15559" target="_blank">2winbet.gr</a><br>*Υπηρεσία Live-Chat της <a href="http://2winbet.gr/?btag=15559" target="_blank">2winbet</a>.<br>*Τηλεφωνική Επικοινωνία στο 211-8505500<br>*Ιστοσελίδα moneysafe: http://www.moneysafecard.com/el/.</p><p><strong>KANTE THN&nbsp; ΕΓΓΡΑΦΗ ΣΑΣ ΕΔΩ :</strong> <a href="http://2winbet.gr/?btag=14936"><span style="color:#FF0000">http://2winbet.gr/?btag=14936</span></a></p><p>&nbsp;</p>

<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Η Paysafe επέστρεψε στη Magicbet..', '1444149988', 'paysafe.jpg', '<p>Η Paysafe επέστρεψε στη Magicbet!</p><p>&nbsp;</p><p>Η <strong><a class="maintext" href="http://record.affiliates.magicbet.gr/_jGZUKO3JWgwWqcfzuvZcQGNd7ZgqdRLk/1/" target="_blank"><strong>Magicbet</strong></a></strong> δίνει ακόμα μια λύση στο πρόβλημα των καταθέσεων.</p><p>Ο πιο απλός και δημοφιλής τρόπος συναλλαγής των παικτών του στοιχήματος&nbsp;επέστρεψε!&nbsp;Η κάρτα Paysafe είναι και πάλι διαθέσιμη σε αμέτρητα σημεία πώλησης σε όλη την επικράτεια και έτσι μπορείτε να ασχοληθείτε ξανά με τα αγαπημένα σας στοιχηματικά παιχνίδια χωρίς να… δίνετε λογαριασμό σε κανέναν.</p><p>Η <a class="maintext" href="http://record.affiliates.magicbet.gr/_jGZUKO3JWgwWqcfzuvZcQGNd7ZgqdRLk/1/" target="_blank"><strong>Magicbet</strong></a> αποδεικνύει για μια ακόμη φορά έμπρακτα ότι δίνει άμεσες λύσεις και είναι μία τις ελάχιστες εταιρίες που χρησιμοποιούν την ευρέως διαδεδομένη κάρτα συναλλαγής.</p><p><span style="font-size:16px">KANTE ΕΓΓΡΑΦΗ ΜΕ ΚΩΔΙΚΟ ΠΡΟΩΘΗΣΗΣ :<span style="color:#0000CD"> <strong><span style="font-size:18px">betvision </span></strong></span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Νότια Κορέα ..Κατηγορία β΄', '1444168490', 'soccer-ball-south-korea_50938519.jpg', '<p><span style="color:#FF0000">721.</span><span style="color:#FF8C00"> ΧΑΜΕΛ-ΓΚΙΕΟΝΓΚΑΜ (13.00)&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> &nbsp; &nbsp;&nbsp;&nbsp; Χ</span></p><p><span style="color:#FF0000">722</span><span style="color:#FF8C00">.ΓΚΑΝΓΚΒΟΝ-ΣΟΥΟΝ ΣΙΤΙ (13.00) &nbsp; &nbsp; </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <span style="color:#0000FF">2</span></p><p><span style="color:#FF0000">723</span>.<span style="color:#FF8C00">ΣΕΟΥΛ Η ΛΑΝΤ -ΓΚΟΙΑΝΓΚ ΧΙ (13.00) &nbsp;</span> &nbsp; &nbsp;&nbsp; &nbsp; <span style="color:#0000FF">1</span></p><p><span style="color:#FF0000">724.</span><span style="color:#FF8C00">ΝΤΑΕΓΚΟΥ-ΚΟΡΕΑΝ (13.00)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> &nbsp; &nbsp; 1</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Παρουσίαση neteller...', '1444169911', 'whatisneteller.gif', '<h3><span style="color:#008000"><strong>Υπηρεσίες</strong></span></h3><p>Ο λογαριασμός NETELLER είναι ένα είδος ηλεκτρονικού λογαριασμού αποθηκευμένης χρηματικής αξίας που χρησιμοποιείται από εκατομμύρια καταναλωτές σε περισσότερες από 200 χώρες για την κατάθεση, ανάληψη και μεταφορά κεφαλαίων προς και από NETELLER εμπορικές επιχειρήσεις και άλλους NETELLER πελάτες. Όταν κάνετε εγγραφή για την απόκτηση λογαριασμού, αποκτάτε πρόσβαση στις εξής υπηρεσίες:</p><h3><span style="color:#006400"><strong>Net+ Prepaid MasterCard®</strong></span></h3><p style="text-align:justify">Με το NETELLER, οι πελάτες αποκτούν πρόσβαση σε ένα από τα πλέον επιτυχημένα προγράμματα προπληρωμένων καρτών της αγοράς. Το πρόγραμμα Net+ καρτών μας, επιτρέπει στους καταναλωτές να δαπανούν χρήματα ηλεκτρονικά, με ασφάλεια και αυτοπροσώπως, σε εκατομμύρια MasterCard® σημεία πώλησης και επίσης να διαθέτουν απευθείας πρόσβαση στα μετρητά τους σε ATM σε όλο τον κόσμο.</p><p>&nbsp;</p><p style="text-align:center"><span style="color:#006400"><strong>Μεταφορά χρημάτων</strong></span></p><p>NETELLER Η μεταφορά χρημάτων είναι ένας γρήγορος, απλός και ασφαλής τρόπος να στέλνετε χρήματα με ηλεκτρονικό τρόπο και στη στιγμή. Διαθέσιμη μέσω του δωρεάν NETELLER λογαριασμού πληρωμών σας, NETELLER η μεταφορά χρημάτων είναι μια δωρεάν δυνατότητα, εναλλακτική των παραδοσιακών μεθόδων αποστολής χρημάτων</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('  Μπάσκετ Κύπελλο Ελλάδος ..', '1444226900', 'kipello.jpg', '<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="font-size:16px">&nbsp;&nbsp;&nbsp;<span style="color:rgb(218, 165, 32)">&nbsp;&nbsp; ΑΡΗΣ-ΑΕΚ (19.30) </span></span></p><p style="text-align: justify;"><span style="font-size:16px">Χώρις τον Βεζένκοφ ο οποίος θα αγωνίζεται πλέον στη Μπαρτσελόνα αλλα με ικανές προσθήκες η ομάδα του Αρη θα διεκδηκήσει την παρουσια του στο τελικό. Η Αεκ θέλει να πρωταγωνιστήσει στην Α1 κα θα δυσκολεψει αρκετά τον Αρη. Μαυροκεφάλιδης κατώ απο τα καλάθια και ο νεο αποκτηθείς Κάρτερ και ο ηγέτης Μαλί&nbsp; οι κορυφαίοι για το δικέφαλο..Κατάμεστο το nick galis . </span></p><p><span style="color:#0000FF"><span style="font-size:16px">ΕΚΤΙΜΗΣΗ:&nbsp; 1</span></span></p><div>&nbsp;</div>




<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Παγκόσμιο κύπελλο 2018 - Προκριματικά  (Πρωινοί αγώνες )', '1444243801', '1_world_cup_2018_qualifier_draw_afc.jpg', '<p style="text-align: justify;"><span style="color:#FF0000">733. </span><span style="color:#FF8C00">ΤΙΜΟΡ ΛΕΣΤΕ- ΠΑΛΑΙΣΤΙΝΗ (10.00)&nbsp;</span> &nbsp;&nbsp; <span style="color:#0000FF">2</span></p><p style="text-align: justify;"><span style="color:#FF0000">807</span><span style="color:#FF8C00">.Β ΚΟΡΕΑ- ΦΙΛΙΠΠΙΝΕΣ (10.30)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; <span style="color:#0000FF">1</span></p><p style="text-align: justify;"><span style="color:#FF0000">741.</span><span style="color:#FF8C00"> ΚΙΡΓΙΣΤΑΝ-ΤΑΤΖΙΚΙΣΤΑΝ (15.00)&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; <span style="color:#0000FF">1</span></p><p style="text-align: justify;"><span style="color:#FF0000">778.</span><span style="color:#FF8C00">ΣΙΓΚΑΠΟΥΡΗ-ΑΦΓΑΝΙΣΤΑΝ (15.00)&nbsp;</span>&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">&nbsp;&nbsp; 1</span></p><p style="text-align: justify;"><span style="color:#FF0000">791</span>.<span style="color:#FF8C00">ΒΙΕΤΝΑΜ-ΙΡΑΚ (15.00)&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">Χ</span></p><p style="text-align: justify;"><span style="color:#FF0000">792</span>.<span style="color:#FF8C00">ΜΙΑΝΜΑΡ-ΛΙΒΑΝΟΣ (15.00)&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <span style="color:#0000FF">2</span></p>


<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Παγκόσμιο κύπελλο 2018 - Προκριματικά', '1444244234', 'world_cup_2018_qualifier_draw.png', '<p><span style="color:#FF0000">742</span>.<span style="color:#FF8C00">ΙΟΡΔΑΝΙΑ-ΑΥΣΤΡΑΛΙΑ (17.00)</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> 2</span></p><p><span style="color:#FF0000">740.</span><span style="color:#FF8C00">ΣΑΟΥΔΙΚΗ ΑΡΑΒΙΑ-ΗΑΕ (20.00)&nbsp;</span>&nbsp; &nbsp;<span style="color:#0000FF"> &nbsp; &nbsp; 1</span></p><p><span style="color:#FF0000">760</span>.<span style="color:#FF8C00">ΚΑΤΑΡ- ΚΙΝΑ (18.30)</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">&nbsp;&nbsp; 2</span></p><p><span style="color:#FF0000">777.</span><span style="color:#FF8C00">ΟΜΑΝ-ΙΡΑΝ (17.30)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> 2</span></p><p>&nbsp;</p>


<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Παγκόσμιο κύπελλο 2018 - Προκριματικά Ζώνη Νοτίου Αμερικής ', '1444244961', '1437841788_n.jpg', '<p><span style="color:#FF0000">769.</span> <span style="color:#FF8C00">ΒΟΛΙΒΙΑ-ΟΥΡΟΥΓΟΥΑΗ&nbsp; (23.00) &nbsp; &nbsp; &nbsp; &nbsp;</span> &nbsp; &nbsp; &nbsp;<span style="color:#0000FF">&nbsp; 2</span></p><p><span style="color:#FF0000">775.</span><span style="color:#FF8C00">ΚΟΛΟΜΒΙΑ-ΠΕΡΟΥ (23.30)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <span style="color:#0000CD">1</span></p><p><span style="color:#FF0000">818.</span><span style="color:#FF8C00">ΒΕΝΕΖΟΥΕΛΑ-ΠΑΡΑΓΟΥΑΗ (02.30)</span> &nbsp; &nbsp;&nbsp;<span style="color:#0000FF"> 2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">828.</span><span style="color:#FF8C00">ΧΙΛΗ-ΒΡΑΖΙΛΙΑ (00.00)&nbsp; &nbsp; </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> ΓΚΟΛ</span></p><p><span style="color:#FF0000">830.</span><span style="color:#FF8C00">ΑΡΓΕΝΤΙΝΗ-ΙΣΗΜΕΡΙΝΟΣ (03.00)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">1</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>








<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά Ευρωπαϊκού Πρωταθλήματος 2016', '1444245503', 'euro-2016.jpg.pagespeed.ce_.vfzo0ypi1m.jpg', '<p><span style="color:#FF0000">797.</span><span style="color:#FF8C00"> ΙΡΛΑΝΔΙΑ - ΓΕΡΜΑΝΙΑ &nbsp; (21.45)&nbsp;</span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">ΟΒΕΡ</span></p><p><span style="color:#FF0000">798.</span><span style="color:#FF8C00">ΣΚΩΤΙΑ&nbsp; - ΠΟΛΩΝΙΑ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (21.45)&nbsp;&nbsp;&nbsp;</span> &nbsp; &nbsp; <span style="color:#0000FF">&nbsp; ΗΜ Χ</span></p><p><span style="color:#FF0000">799</span>. <span style="color:#FF8C00">ΟΥΓΓΑΡΙΑ-ΝΗΣΟΙ ΦΕΡΟΕ (21.45)&nbsp;&nbsp;</span> &nbsp; &nbsp;<span style="color:#0000FF"> 1</span></p><p><span style="color:#FF0000">803</span>. <span style="color:#FF8C00">Β.ΙΡΛΑΝΔΙΑ -ΕΛΛΑΔΑ (21.45)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;<span style="color:#0000FF"> ΗΜ Χ</span></p><p><span style="color:#FF0000">804.</span><span style="color:#FF8C00">ΡΟΥΜΑΝΙΑ-ΦΙΛΑΝΔΙΑ (21.45)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color:#FF0000">&nbsp;</span><span style="color:#0000FF">&nbsp;&nbsp;&nbsp; 2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">805</span>.<span style="color:#FF8C00">ΑΛΒΑΝΙΑ-ΣΕΡΒΙΑ (21.45)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; <span style="color:#0000FF">Χ</span></p><p><span style="color:#FF0000">806.</span><span style="color:#FF8C00">ΠΟΡΤΟΓΑΛΙΑ-ΔΑΝΙΑ (21.45)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; <span style="color:#0000FF">1&nbsp;&nbsp;</span></p><p>&nbsp;</p>





<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Μπάσκετ: Κύπελλο Ελλάδας  Ολυμπιακός - Παναθηναϊκός', '1444246631', 'osfp-pao-basket-650x325.jpg', '<p><span style="color:#FF0000">ΠΡΟΗΜΙ</span><span style="color:#0000CD">ΤΕΛΙΚΟΣ....</span></p><p style="text-align: justify;">&nbsp;<span style="font-size:16px"><span style="color:#FF0000">ΟΛΥΜΠΙΑΚΟΣ</span>&nbsp;&nbsp; Με την απουσία&nbsp; του Οθέλο Χάντερ ολοκλήρωσε ο Ολυμπιακός την προετοιμασία του για το ντέρμπι με τον Παναθηναϊκό, για τα προημιτελικά του Κυπέλλου. Ο Γιάννης Σφαιρόπουλος δεν μπορεί να υπολογίζει στις υπηρεσίες του Αμερικανού σέντερ, λόγω του τραυματισμού του και έτσι θα είναι ο μοναδικός απών από τον πρώτο… τελικό της φετινής σεζόν.</span></p><div class="apospasma" style="margin-top:10px;"><p style="text-align: justify;"><span style="font-size:16px"><span style="color:#006400">ΠΑΝΑΘΗΝΑΙΚΟΣ</span> Οι «πράσινοι» δούλεψαν και σήμερα σε φουλ ρυθμούς και χωρίς κανένα πρόβλημα, ολοκλήρωσαν την απογευματινή τους προπόνηση ενόψει του ντέρμπι για το κύπελλο Ελλάδας κόντρα στον Ολυμπιακό στο ΣΕΦ.</span></p><p style="text-align: justify;"><span style="font-size:16px">Μετά την ολοκλήρωση της προπόνησης το τεχνικός τιμ αλλά και οι παίκτες, μετέβησαν σε ξενοδοχείο όπου και θα διανυκτερεύσουν, με την προετοιμασία της ομάδας, να ολοκληρώνεται την Πέμπτη, ανήμερα της αναμέτρησης, με την τελευταία προπόνηση.</span></p><p style="text-align: justify;"><span style="color:#0000CD"><span style="font-size:16px">ΕΚΤΙΜΗΣΗ : 1</span></span></p></div><div id="stcpDiv" style="position: absolute; top: -1999px; left: -1988px;"><p><span style="color:#141823; font-family:helvetica,arial,sans-serif; font-size:12px">Ο Σάσα Τζόρτζεβιτς και οι παίκτες του βρέθηκαν το απόγευμα της Τετάρτης (07/10) στο ΟΑΚΑ, προκειμένου να γυμναστούν, πριν τον κρίσιμο αγώνα κόντρα στον Ολυμπιακό. Η προπόνηση διεξήχθη ομαλά, χωρίς κανένα απρόοπτο, με τους Κυπελλούχους Ελλάδας να καταλύουν στη συνέχεια σε ξενοδοχείο, όπου και θα διανυκτερεύσουν.</span></p><p><span style="color:#141823; font-family:helvetica,arial,sans-serif; font-size:12px">Μάλιστα, η προετοιμασία του Παναθηναϊκού δεν έχει ολοκληρωθεί ακόμη. Αυτό θα γίνει, το πρωί της Πέμπτης (08/10), ανήμερα του προημιτελικού με τον Ολυμπιακό, μετά από μία πρωινή προπόνηση.</span></p>- See more at: http://www.basketblog.gr/index.php?option=com_content&amp;view=article&amp;id=149539:2015-10-07-18-50-18&amp;catid=228:panathinaikos&amp;Itemid=227#sthash.9GUuTO2i.dpuf</div>




<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά Ευρωπαϊκού Πρωταθλήματος 2016         09/10/2015', '1444340315', 'hqdefault.jpg', '<p><span style="color:#FF0000">831.</span><span style="color:#FF8C00">ΣΛΟΒΑΚΙΑ -ΛΕΥΚΟΡΩΣΙΑ (21.45)&nbsp; &nbsp;&nbsp; &nbsp; &nbsp;</span><span style="color:#0000FF"> 1/1</span></p><p><span style="color:#FF0000">832</span><span style="color:#FF8C00">.ΠΓΔΜ-ΟΥΚΡΑΝΙΑ (21.45)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color:#0000FF">&nbsp; &nbsp; &nbsp; ΗΜ Χ</span></p><p><span style="color:#FF0000">837.</span><span style="color:#FF8C00">ΜΑΥΡΟΒΟΥΝΙΟ-ΑΥΣΤΡΙΑ (21.45)&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; </span><span style="color:#0000FF">&nbsp;&nbsp; &nbsp; Χ</span></p><p><span style="color:#FF0000">840.</span><span style="color:#FF8C00">ΜΟΛΔΑΒΙΑ-ΡΩΣΙΑ (21.45)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; </span><span style="color:#0000FF">&nbsp; &nbsp;&nbsp; 2</span></p><p><span style="color:#FF0000">843.</span><span style="color:#FF8C00"> ΣΛΟΒΕΝΙΑ-ΛΙΘΟΥΑΝΙΑ (21.45) &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span style="color:#0000FF"> &nbsp; 1</span></p><p><span style="color:#FF0000">846</span><span style="color:#FF8C00">. ΑΓΓΛΙΑ-ΕΣΘΝ0ΝΙΑ (21.45) &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span style="color:#0000FF">&nbsp;&nbsp; 4-6 ΓΚΟΛ</span></p><div>&nbsp;</div>


<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>
');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Paysafecard : Ποίες εταιρίες δέχονται ενημέρωση 09/10/2015', '1444408487', 'paysafe_card.jpg', '<p style="text-align: justify;"><span style="color:#0000FF">Η δημοφιλής paysafecard επέστρεψε...</span>αλλά μόνο τρέις είναι οι στηχοιματικές εταιρίες που τη δέχονται ήτοι <span style="color:#FFD700">bet</span>shop,<span style="color:#006400">bet365</span><span style="color:#006400"> </span>κα <span style="color:#FF0000">magic</span>bet .Σταδιακά επιλύονται θέματα που προέκυψαν απο τα capitalcontol και οι εταιρίες θα αποκαταστήσουν τις συναλλαγές.Η paysafe ανέκαθεν υπήρξε η Νο1 επιλογή των Ελλήνων παιχτών στην αγορά του στοιχήματος και διαδυκτιακών συναλλαγών και με χαρά υποδέχτηκαν την επιστροφή της.</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Παρουσίαση moneysafe...Άμεσες πληρωμές απο στοιχηματικές', '1444409812', 'image.jpg', '<p><span style="color:rgb(139, 69, 19)">Τι είναι η MoneySafe</span>; *Πλήρης MasterCard® κάρτα*Χωρίς πιστωτικό έλεγχο*Παρακολούθηση λογαριασμού της κάρτας μέσω του online λογαριασμού σας*Χρειάζεται απλά να είστε άνω των 18 ετών για να την αγοράσετε Η <span style="color:#DAA520">MoneySafe </span>κάρτα είναι μια επαναφορτιζόμενη προπληρωμένη<span style="color:#DAA520"> MasterCard </span>κάρτα που εκδίδεται επιτόπου. Λειτουργεί περίπου όπως οποιαδήποτε άλλη <span style="color:#DAA520">MasterCard</span> αλλά το ότι είναι προπληρωμένη σημαίνει ότι δεν μπορείτε να ξοδέψετε περισσότερα χρήματα από αυτά που είναι διαθέσιμα στη κάρτα σας. Μπορείτε να χρησιμοποιήσετε τη <span style="color:#DAA520">MoneySafe MasterCard</span> σε καταστήματα λιανικής, στο διαδίκτυο και σε όλα τα <span style="color:#FF0000">ATM</span> παγκοσμίως οπουδήποτε οι <span style="color:#DAA520">MasterCard</span> κάρτες είναι αποδεκτές. Ενεργοποιήστε τη κάρτα σας εύκολα και γρήγορα είτε μέσω της <span style="color:#0000FF">SMS</span> ενεργοποίησης ή μέσω της διαδικτυακής ενεργοποίησης (online web activation) και είστε έτοιμοι να χρησιμοποιήσετε τη καινούργια σας <span style="color:#DAA520">MoneySafe MasterCard. -</span></p><p><span style="color:#8B4513">Πως λειτουργεί; </span>Με την προπληρωμένη MoneySafe MasterCard® μπορείτε να κάνετε αγορές στο διαδίκτυο με ασφάλεια οπουδήποτε επιδεικνύεται το σήμα της MasterCard. Οι προσωπικές πληροφορίες του λογαριασμού της τραπέζης σας και των πιστωτικών σας καρτών παραμένουν ασφαλείς και προστατευμένες .Οι αγορές σας φαίνονται μόνο στο διαδικτυακό σας λογαριασμό και ποτέ δε θα λάβετε μια κατάσταση με τις συναλλαγές σας στη διεύθυνση σας. Φυσικά η MoneySafe κάρτα μπορεί να χρησιμοποιηθεί για να κάνετε αναλήψεις και καταθέσεις -</p><p>Σημεία Πώλησης: *Μπορείτε να βρείτε όλα τα σημεία πώλησης της MoneySafe Card στο εξής<a href="http://www.moneysafecard.com/el/store-locator.html.">http://www.moneysafecard.com/el/store-locator.html.</a></p><p>Επικοινωνία: Για οποιαδήποτε ερώτηση, απορία ή διευκρίνιση, είμαστε πάντα στη διάθεσή σας με τους εξής τρόπους επικοινωνίας:</p><p>*Τηλεφωνική Επικοινωνία στο 211-8505500</p><p>Iστοσελίδα moneysafe: <a href="http://www.moneysafecard.com/el/. -">http://www.moneysafecard.com/el/. </a></p><p><span style="color:#FF0000">ΣΗΜΑΝΤΙΚΗ ΕΝΗΜΕΡΩΣΗ: </span>Με την εγγραφή σας στην<strong> :</strong>&nbsp;<strong><a href="http://2winbet.gr/?btag=14936"><span style="color:#FF0000"> </span><span style="color:#FF0000">http://2winbet.gr/?btag=14936 </span></a></strong>επικοινωνήστε με το τμήμα εξυπηρέτησης για το πως θα αποκτήσετε την moneysafecard.</p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΣΛΟΒΑΚΙΑ-ΛΕΥΚΟΡΩΣΙΑ  (21.45) ', '1444410836', 'hqdefault.jpg', '<p><span style="font-size:16px"><span style="color:rgb(0, 0, 205)">Προκριματικά Euro 2016... </span>Με νίκη κλειδώνει και μαθηματικά τη πρόκριση. Εχοντας μείνει στο 0-0 με τους Ουκρανούς στον αγώνα του Σεπτεμβρίου διατηρώντας τη δεύτερη θέση έχει την ευκαιρία νικόντας σήμερα κόντρα&nbsp; στην αδιάφορη Λευκορωσία να εξασφαλίσει τη παρουσια της στη Γαλλία το 2016. Είναι το απόλυτο φαβορί οχι μόνο λόγω κινήτρου αλλά και από πλευράς δυναμικότητας .Η Σλοβακία βρίσκεται στη δέυτερη θεση με 19 βαθμους μώλις 2 βαθμούς πισω από την Ισπανία.</span></p><p><span style="font-size:16px">Οι Λευκορώσοι έχουν αποκλειστεί και βαθμολογικά συνεπώς χώρις κανένα ουσιαστικό ενδιαφέρον ο αγλωνας για αυτούς και με το κλίμα ήδη αρνητικό στην ομάδα.</span></p><p><span style="font-size:16px"><span style="color:rgb(255, 0, 0)">ΕΚΤΙΜΗΣΗ </span>: <span style="color:rgb(0, 0, 255)">ΑΣΣΟΣ και 2-3 ΓΚΟΛ </span></span></p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Επιλογές  κουπονιού 10/10/2015 ', '1444454622', 'stoixima.jpg', '<p><span style="color:#FF0000">2293 </span>.<span style="color:#DAA520">ΜΑΚΛΣΦΙΛΝΤ-ΚΙΝΤΕΡΜΙΝΣΤΕΡ (14.30)&nbsp;</span> &nbsp; &nbsp;<span style="color:#0000FF">&nbsp; 1</span></p><p><span style="color:#FF0000">2306</span>. <span style="color:#DAA520">ΠΑΝΑΙΓΙΑΛΕΙΟΣ-ΛΑΡΙΣΑ(16.00)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> ΗΜΧ</span></p><p><span style="color:#FF0000">2072.</span> <span style="color:#DAA520">ΣΑΟΥΘΕΝΤ-ΠΟΡΤ ΒΕΙΛ (17.00)&nbsp; </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> 1</span></p><p><span style="color:#FF0000">2029.</span><span style="color:#DAA520">ΤΕΝΕΡΙΦΗ-ΛΕΓΚΑΝΕΣ (19.00) </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style="color:#0000FF">1</span></p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Γκόλ από το νησί...', '1444454990', 'pame_tameio.jpg', '<p><span style="color:#FF0000">2066.</span><span style="color:#DAA520">ΜΠΕΡΙ-ΓΟΥΙΓΚΑΝ&nbsp; (17.00)&nbsp; &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style="color:#800080"> &nbsp; ΓΚΟΛ</span></p><p><span style="color:#FF0000">2011.</span><span style="color:#DAA520">ΝΟΡΘΑΜΠΤΟΝ-ΧΑΡΤΠΟΥΛ (17.00)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp; &nbsp; &nbsp;<span style="color:#800080"> &nbsp; ΟΒΕΡ</span></p><p><span style="color:#FF0000">2008</span>.<span style="color:#DAA520">ΛΟΥΤΟΝ-ΓΙΟΡΚ (17.00)&nbsp;&nbsp;&nbsp; &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;<span style="color:#800080"> 2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">2303.</span><span style="color:#DAA520">ΣΑΟΥΘΠΟΡΤ- ΤΟΡΚΙ (17.00)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; <span style="color:#800080">&nbsp; ΓΚΟΛ</span></p><p>&nbsp;</p><p>&nbsp;</p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά Euro 2016   10/10/2015', '1444455726', 'euro-2016.jpg.pagespeed.ce_.vfzo0ypi1m.jpg', '<p><span style="color:#FF0000">848.</span><span style="color:#DAA520">&nbsp; ΑΖΕΡΜΠΑΪΤΖΑΝ- ΙΤΑΛΙΑ&nbsp; (19.00)&nbsp; &nbsp;</span> &nbsp; &nbsp;<span style="color:#0000FF"> 2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">851.</span><span style="color:#DAA520">ΤΣΕΧΙΑ-ΤΟΥΡΚΙΑ (21.45)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;<span style="color:#0000FF"> ΗΜΧ</span></p><p><span style="color:#FF0000">852</span>. <span style="color:#DAA520">ΚΡΟΑΤΙΑ- ΒΟΥΛΓΑΡΙΑ (21.45)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; <span style="color:#0000FF">&nbsp;&nbsp; &nbsp; &nbsp; 1</span></p><p><span style="color:#FF0000">854.</span><span style="color:#DAA520"> ΙΣΡΑΗΛ-ΚΥΠΡΟΣ (21.45)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">856</span>. <span style="color:#DAA520">ΒΟΣΝΙΑ-ΟΥΑΛΙΑ (21.45)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> 1</span></p><p>&nbsp;</p>


<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακής  11/10/2015', '1444541868', 'z.jpg', '<p><span style="color:#FF0000">2018.</span> <span style="color:#DAA520">ΚΑΛΙΑΡΙ - ΤΣΕΖΕΝΑ (13.30)&nbsp;</span>&nbsp;&nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">2309 </span><span style="color:#DAA520">.ΕΡΓΟΤΕΛΗΣ-ΛΑΜΙΑ (16.00)&nbsp;&nbsp;</span>&nbsp; <span style="color:#0000FF">UNDER</span></p><p><span style="color:#FF0000">2135.</span> <span style="color:#DAA520">ΜΕΣΙΝΑ- ΜΑΤΕΡΑ (16.00)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">1</span></p><p><span style="color:#FF0000">20126. </span><span style="color:#DAA520">ΑΣΚΟΛΙ-ΠΕΣΚΑΡΑ (21.30)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;<span style="color:#0000FF"> ΓΚΟΛ</span></p><p>&nbsp;</p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά Euro 2016   11/10/2015', '1444542214', 'maxresdefault.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">858.</span> <span style="color:#DAA520">ΣΕΡΒΙΑ-ΠΟΡΤΟΓΑΛΙΑ (19.00) </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style="color:#0000FF">UNDER</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">860.</span> <span style="color:#DAA520">ΑΡΜΕΝΙΑ-ΑΛΒΑΝΙΑ (19.00)&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> ΗΜ Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">861</span>. <span style="color:#DAA520">ΕΛΛΑΔΑ-ΟΥΓΓΑΡΙΑ (19.00)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;<span style="color:#0000FF"> Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">862.</span> <span style="color:#DAA520">ΦΙΝΛΑΝΔΙΑ- Β ΙΡΛΑΝΔΙΑ (19.00)&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> 2-3 ΓΚΟΛ</span></span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('FOOTBALL LEAGUE   Τρίκαλα -Καλλιθέα ', '1444543097', 'football-league3.jpg', '<p><span style="font-size:16px"><span style="color:rgb(0, 0, 255)">Ποντάρουν στην έδρα...</span>Χωρίς ήττα τα Τρίκαλα στις δυο πρώτες αγωνιστικές έχοντας μία ισοπαλία στην πρεμιέρα και τη νίκη επί του Αγροτικού Αστέρα. Με την προιστορία υπέρ τους οι γηπεδουχοι και με τη δύναμη του κόσμου ευκολα η δυσκολα θα πάρουν τη νίκη . Η Καλλιθέα μετρά μία νίκη μια ήττα. <span style="color:#FF0000">ΕΚΤΙΜΗΣΗ </span>: <span style="color:#0000FF">ΑΣΣΟΣ</span></span></p><p>&nbsp;</p><p>&nbsp;</p><p><br>&nbsp;</p>




<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",179642);</script><div data-ti="14927_179642"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προκριματικά Euro 2016    12/10/2015', '1444628149', 'maxresdefault.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">877.</span> <span style="color:#DAA520">ΣΟΥΗΔΙΑ-ΜΟΛΔΑΒΙΑ (19.00)&nbsp; &nbsp;</span> &nbsp;<span style="color:#0000FF"> &nbsp; 2-3 ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">878.</span> <span style="color:#DAA520">ΡΩΣΙΑ- ΜΑΥΡΟΒΟΥΝΙΟ (19.00) &nbsp;</span> &nbsp;&nbsp; <span style="color:#0000FF">&nbsp;&nbsp; ΗΜ Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">892.</span><span style="color:#DAA520">ΟΥΚΡΑΝΙΑ-ΙΣΠΑΝΙΑ&nbsp; (21.45)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;<span style="color:#0000FF"> 2-3 ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">887.</span><span style="color:#DAA520"> ΛΙΘΟΥΑΝΙΑ-ΑΓΓΛΙΑ (21.45)&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">2</span></span></p><p>&nbsp;</p>


<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",180029);</script><div data-ti="14927_180029"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Football   League     Απόλλων Σμύρνης-Αχαρναικός (18.00)  ', '1444655136', 'fot.jpg', '<p><span style="font-size:16px"><span style="color:rgb(0, 0, 255)">ΑΠΟΛΛΩΝ :</span>&nbsp; Σε εξαιρετική κατάσταση ο Απόλλωνας με το (0-0) στα Χανία τη περασμένη Δευτέρα να στιγματήστηκε για τα παράπονα σε βάρος της διαιτησίας σχετικά με το ακυρωθέν γκολ.Διαθέτει ποιότητα και τη στήριξη του κόσμου, μαλιστα σχετική ανακόινωση εξεδώθει απο τη διοίκηση όπου καλεί το κοσμο στο σημερινό ματς .</span></p><p><span style="font-size:16px"><span style="color:rgb(0, 128, 0)">ΑΧΑΡΝΑΙΚΟΣ:</span> Χωρίς νίκη ακόμα ο Αχαρναικός έχοντας μια ισοπαλία και την εντός έδρας ήττα από τον Εργοτέλη που έδωσε αφορμή γα μουρμούρες στο πάγκο.</span></p><p><span style="font-size:16px"><span style="color:#800080">ΕΚΤΙΜΗΣΗ :&nbsp;</span> 1/1</span></p><table style="width:100.0%" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td><p>ΒΑΘΜΟΛΟΓΙΑ</p></td></tr><tr><td><table style="width:71.54%" border="0" cellpadding="0" cellspacing="1"><tbody><tr><td style="height:16px"><p><strong>Θέση</strong></p></td><td style="height:16px"><p><strong>Ομάδα</strong></p></td><td style="height:16px"><p><strong>Β</strong></p></td><td style="height:16px"><p><strong>Α</strong></p></td><td style="height:16px"><p><strong>Ν</strong></p></td><td style="height:16px"><p><strong>Ι</strong></p></td><td style="height:16px"><p><strong>Η</strong></p></td><td style="height:16px"><p><strong>Υ</strong></p></td><td style="height:16px"><p><strong>Κ</strong></p></td></tr><tr><td colspan="7" style="height:18px"><p><strong>1ος όμιλος</strong></p></td><td style="height:18px">&nbsp;</td><td style="height:18px">&nbsp;</td></tr><tr><td style="height:18px"><p>1</p></td><td style="height:18px"><p>ΑΕΛ Π.Α.Ε.</p></td><td style="height:18px"><p>9</p></td><td style="height:18px"><p>3</p></td><td style="height:18px"><p>3</p></td><td style="height:18px"><p>0</p></td><td style="height:18px"><p>0</p></td><td style="height:18px"><p>7</p></td><td style="height:18px"><p>1</p></td></tr><tr><td style="height:17px"><p>2</p></td><td style="height:17px"><p>ΤΡΙΚΑΛΑ</p></td><td style="height:17px"><p>7</p></td><td style="height:17px"><p>3</p></td><td style="height:17px"><p>2</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>6</p></td><td style="height:17px"><p>3</p></td></tr><tr><td style="height:17px"><p>3</p></td><td style="height:17px"><p>ΑΟ ΚΑΣΣΙΟΠΗ</p></td><td style="height:17px"><p>6</p></td><td style="height:17px"><p>2</p></td><td style="height:17px"><p>2</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>4</p></td><td style="height:17px"><p>1</p></td></tr><tr><td style="height:18px"><p>4</p></td><td style="height:18px"><p>ΑΠΟΛΛΩΝ ΣΜΥΡΝΗΣ</p></td><td style="height:18px"><p>4</p></td><td style="height:18px"><p>2</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>0</p></td><td style="height:18px"><p>3</p></td><td style="height:18px"><p>2</p></td></tr><tr><td style="height:17px"><p>5</p></td><td style="height:17px"><p>ΠΜΣ ΑΓΡΟΤΙΚΟΣ ΑΣΤΗΡ</p></td><td style="height:17px"><p>4</p></td><td style="height:17px"><p>3</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>3</p></td><td style="height:17px"><p>3</p></td></tr><tr><td style="height:17px"><p>6</p></td><td style="height:17px"><p>ΕΡΓΟΤΕΛΗΣ Γ.Σ. ΠΑΕ</p></td><td style="height:17px"><p>4</p></td><td style="height:17px"><p>3</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>3</p></td><td style="height:17px"><p>3</p></td></tr><tr><td style="height:18px"><p>7</p></td><td style="height:18px"><p>ΖΑΚΥΝΘΟΣ ΠΑΕ</p></td><td style="height:18px"><p>4</p></td><td style="height:18px"><p>3</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>3</p></td><td style="height:18px"><p>3</p></td></tr><tr><td style="height:18px"><p>8</p></td><td style="height:18px"><p>ΑΣ ΑΝΑΓΕΝΝΗΣΗ ΚΑΡΔΙΤ</p></td><td style="height:18px"><p>4</p></td><td style="height:18px"><p>3</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>1</p></td></tr><tr><td style="height:17px"><p>9</p></td><td style="height:17px"><p>ΧΑΝΙΑ Α.Ο.</p></td><td style="height:17px"><p>4</p></td><td style="height:17px"><p>3</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td></tr><tr><td style="height:17px"><p>10</p></td><td style="height:17px"><p>ΛΑΜΙΑ ΠΑΕ</p></td><td style="height:17px"><p>4</p></td><td style="height:17px"><p>3</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>2</p></td><td style="height:17px"><p>4</p></td></tr><tr><td style="height:18px"><p>11</p></td><td style="height:18px"><p>ΑΣ ΟΛΥΜΠΙΑΚΟΣ Β.</p></td><td style="height:18px"><p>3</p></td><td style="height:18px"><p>2</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>0</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>1</p></td></tr><tr><td style="height:18px"><p>12</p></td><td style="height:18px"><p>ΚΑΛΛΙΘΕΑ</p></td><td style="height:18px"><p>3</p></td><td style="height:18px"><p>3</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>0</p></td><td style="height:18px"><p>2</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>3</p></td></tr><tr><td style="height:17px"><p>13</p></td><td style="height:17px"><p>ΚΙΣΣΑΜΙΚΟΣ</p></td><td style="height:17px"><p>2</p></td><td style="height:17px"><p>2</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>2</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>2</p></td><td style="height:17px"><p>2</p></td></tr><tr><td style="height:17px"><p>14</p></td><td style="height:17px"><p>ΑΧΑΡΝΑΙΚΟΣ ΑΟ</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>2</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>2</p></td></tr><tr><td style="height:18px"><p>15</p></td><td style="height:18px"><p>ΠΑΝΑΙΓΙΑΛΕΙΟΣ ΠΑΕ</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>3</p></td><td style="height:18px"><p>0</p></td><td style="height:18px"><p>1</p></td><td style="height:18px"><p>2</p></td><td style="height:18px"><p>0</p></td><td style="height:18px"><p>2</p></td></tr><tr><td style="height:17px"><p>16</p></td><td style="height:17px"><p>ΠΑΝΑΧΑΙΚΗ 2005</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>1</p></td></tr><tr><td style="height:17px"><p>17</p></td><td style="height:17px"><p>ΠΑΝΣΕΡΡΑΙΚΟΣ</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>0</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>1</p></td><td style="height:17px"><p>2</p></td></tr><tr><td style="height:18px"><p>18</p></td><td style="height:18px"><p>ΠΑΝΕΛΕΥΣΙΝΙΑΚΟΣ</p></td><td style="height:18px"><p>0</p></td><td style="height:18px"><p>2</p></td><td style="height:18px"><p>0</p></td><td style="height:18px"><p>0</p></td><td style="height:18px"><p>2</p></td><td style="height:18px"><p>2</p></td><td style="height:18px"><p>6</p></td></tr></tbody></table></td></tr></tbody></table>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Επιλογές Τρίτη  13/10/2015', '1444713032', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">2562.</span><span style="color:#DAA520"> ΕΣΤΕΡ - ΛΑΝΤΣΚΡΟΝΑ (20.00)&nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style="color:#0000FF"> 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2569</span>. <span style="color:#DAA520">ΣΑΟΥΘΠΟΡΤ - ΤΣΕΣΤΕΡ (21.45)&nbsp;&nbsp;</span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; <span style="color:#0000FF">2</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2575.</span><span style="color:#DAA520"> ΒΕΛΓΙΟ-ΙΣΡΑΗΛ (21.45)&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> &nbsp; 1/1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2576. </span><span style="color:#DAA520">ΤΟΥΡΚΙΑ- ΙΣΛΑΝΔΙΑ (21.45)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp;&nbsp; 1</span></span></p><p>&nbsp;</p>

<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",180029);</script><div data-ti="14927_180029"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('   EURO 2016 Κύπρος -Βοσνία (21.45)', '1444724697', 'maxresdefault.jpg', '<p style="text-align: justify;"><span style="font-size:16px"><span style="color:rgb(0, 0, 255)">Ενα ματς τελικός..</span>.Ιστορικής σημασίας το παιχνίδι για τους Κυπρίους που έχουν την ευκαιρία να διεκδηκήσουν την παρουσια τους&nbsp; στα τελικά του Εuro 2016 στη Γαλλία. Μετά το μεγάλο διπλό μέσα στο ισραήλ (1-2) χρειάζονται μόνο νική επί της Βοσνίας για να καταλάβουν τη 3η θέση και ταυτόχρονα να μη κερδίσει το ισραήλ στο Βέλγιο που έχει μεγάλο βαθμό δυσκολίας.<span style="color:#0000FF">Από την άλλη η Βοσνία</span> βολέυεται και με την ισοπαλία αφου έκανε το χρεος της και νίκησε την Ουαλία 2-0 .Χωρίς αγωνιστικά προβλήματα αμφότεροι. Γεμάτο και ατμόσφαιρα στο ΓΣΠ..</span></p><p style="text-align: justify;"><span style="font-size:16px"><span style="color:rgb(255, 0, 0)">ΕΚΤΙΜΗΣΗ : 1Χ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Τετάρτη 14/10/2015', '1444798613', 'pame_tameio.jpg', '<p><span style="color:#0000FF">2750.</span><span style="color:#DAA520"> ΣΕΝΤΑΙ - ΟΜΙΓΙΑ (13.00) &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF">&nbsp; 1</span></p><p><span style="color:#0000FF">2639.</span> <span style="color:#DAA520">ΝΤΟΡΟΓΚΙ- ΚΑΒΓΚΑΡΙ (15.00)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">&nbsp; 2</span></p><p><span style="color:#0000FF">2663.</span> <span style="color:#DAA520">ΜΠΡΑΝ-ΓΙΕΡΒ (20.00)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp;&nbsp;&nbsp;&nbsp; 1</span></p><p><span style="color:#0000FF">2673. </span><span style="color:#DAA520">ΑΛΜΕΡΙΑ-ΤΑΡΑΓΟΝΑ (21.30)&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">1</span></p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",180029);</script><div data-ti="14927_180029"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Πέμπτη 15/10/2015..Πέρασαν 3/4 απο τα χθεσινά.....', '1444883984', 'z.jpg', '<p><span style="color:#0000FF">Πέρασαν οι προτάσεις μας..</span></p><p>Από τις χθεσινές προτάσεις έμεινε στο χ η Σεντάι και στη συνέχεια περάσανε το διπλό της Καγκάρι , ο άσσος τς Μπράν και τέλος η νίκη της Αλμερίας.</p><p><span style="color:#FF0000">Πέμττη 15/10/2015</span></p><p><span style="color:#FF0000">2632.</span><span style="color:#FF8C00"> ΤΟΜ ΤΟΣΚ- ΒΟΛΓΑ (16.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp;&nbsp;&nbsp; UNDER</span></p><p><span style="color:#FF0000">2729.</span> <span style="color:#DAA520">ΙΝΤΕΡ ΤΟΥΡΚΟΥ -ΓΙΑΡΟ (18.30)&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">1</span></p><p><span style="color:#FF0000">2740</span>.<span style="color:#FF8C00"> ΣΤΕΑΟΥΑ-ΤΙΜΙΣΟΑΡΑ(21.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> ΓΚΟΛ</span></p><p><span style="color:#FF0000">2742</span><span style="color:#FF8C00">. ΣΑΡΑΓΟΣΑ-ΓΙΑΓΚΟΣΤΕΡΑ (21.30)&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Έναρξη της EUROLEAGUE BASKETBALL', '1444885651', 'euroleague-draw.png', '<p><span style="color:#0000FF">Πρώτη αγωνιστική </span>σήμερα για την Ευρωλίγκα και περιμένουμε να δούμε σε τι βαθμο ετοιμότητας είναι οι ομάδες..</p><p><span style="color:#A52A2A">Συνοπτικά προτεινούμε..</span></p><p><strong>3026. ΚΑΡΣΙΓΙΑΚΑ -ΜΠΑΡΤΣΕΛΟΝΑ :</strong> Η Τουρκική Καρσιγιάκα θα έχει δύσκολο έργο απέναντι στο μεγαθήριο του Ευρωπαικού μπάσκετ Μπαρτσελόνα που όπωςκάθε χρόνο στοχεύει την είσοδο στο final 4.<span style="color:#0000FF"> EKTIMHΣΗ 2.</span></p><p><strong>3027.ΤΣΣΚΑ ΜΟΣΧΑΣ-ΜΑΚΑΜΠΙ ΤΕΛ ΑΒΙΒ : </strong>Χωρίς αξία ο άσσος λογικά οι Ρώσοι δε θα χαριστούν και θα πάρουν το παιχνίδ θέλοντας να κάνουν καλή αρχή παίζοντας και στηνέδρα τους να μη δώσουν δικαιώματ αμφισβήτησης.<span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 1</span></p><p><strong>3028.ΕΡΥΘΡΟΣ ΑΣΤΕΡΑΣ-ΣΤΡΑΣΒΟΥΡΓΟ:</strong> Άπαντες γνωρίζουν ην απίστευτη ατμόσφαιρα που δημιουργούν οι Σέρβοι φίλαθλοι σε κάθε αγώνα της ομάδας τους.Μία έδρα που δυσκολεύει κάθε αντίπαλο.Τους Γάλλους θα περιμενουμε να τους δούμε καθώς θεωρητικά ειναι η πιο αδύναμη ομάδα του ομίλου και θα κρίνουμε.Ευκολα η δύσκολα λοιπόν άσσος . <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 1</span></p><p><strong>3029. ΝΤΑΡΟΥΣΑΦΑΚΑ-ΣΑΣΑΡΙ : </strong>Δύσκολα η Σάσαρι στη Τουρκία <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ 1</span></p><p><strong>3030.ΜΑΛΑΓΑ-ΜΠΑΜΠΕΡΓΚ : </strong>Και εδω χωρίς αξία ο άσσος λογικα νικη για Μάλαγα απέναντι στους μαχητικούς Γερμανούς<span style="color:#0000FF">. ΕΚΤΙΜΣΗ 1</span></p><p><strong>3031.ΟΛΥΜΠΙΑΚΟΣ-ΤΣΕΝΤΕΒΙΤΑ:</strong> Αναμφίβολο φαβορί και ψηλά οι στοχοι του Ολύμπιακού έναντι της αδύναμης Τσεντεβίτα.Μακρία από τν φυσική του έδρα ο ΟΛυμπιακος λόγω τιμωρίας ξεκινάει τις υποχρεώσεις από το Ηράκλειο της Κρήτης.Αδιαφορα σοιχηματικά το ματσς..Απλά απολαμβάνουμε τον αγώνα.Χωρις αξία οι αποδόσεις. <span style="color:#0000FF">ΕΚΤΙΜΗΣΗ ΝΟ ΒΕΤ</span></p><p>&nbsp;</p><p>&nbsp;</p><div>&nbsp;</div>


<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",180029);</script><div data-ti="14927_180029"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Παρασκευή  16/10/2015 ', '1444975662', 'stoixima.jpg', '<p><span style="color:#FF0000">515.</span> <span style="color:#DAA520">ΑΓΡΟΤΙΚΟΣ ΑΣΤΕΡΑΣ- ΖΑΚΥΝΘΟΣ (16.00)&nbsp; </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF">&nbsp; &nbsp; 1</span></p><p><span style="color:#FF0000">533.</span><span style="color:#DAA520">ΜΙΝΤΙΛΑΝΤ-ΡΑΝΤΕΡΣ (19.00)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></p><p><span style="color:#FF0000">572.</span><span style="color:#DAA520">ΝΙΟΡ- ΟΣΕΡ (21.00)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">593.</span> <span style="color:#DAA520">ΜΟΝΑΚΟ - ΛΥΩΝ (21.30)&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <span style="color:#0000FF">&nbsp;&nbsp; ΟΒΕΡ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σαββάτο 17/10/2015', '1445059112', 'stoixima.jpg', '<p><span style="color:#FF0000">663</span><span style="color:#0000FF">.</span><span style="color:#DAA520">ΝΥΡΕΒΕΡΓΗ - ΦΣΒ ΦΡΑΝΚΦΟΥΡΤΗΣ(14.00)&nbsp;</span><span style="color:#0000FF">&nbsp;&nbsp;&nbsp; 1</span></p><p><span style="color:#FF0000">724</span><span style="color:#DAA520">.ΤΟΤΕΝΑΜ-ΛΙΒΕΡΠΟΥΛ (14.45)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; <span style="color:#0000FF">ΟΒΕΡ</span></p><p><span style="color:#FF0000">727</span>.<span style="color:#DAA520">ΝΤΙΖΟΝ- ΕΒΙΑΝ (15.00)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;<span style="color:#0000FF"> ΓΚΟΛ</span></p><p><span style="color:#FF0000">820.</span><span style="color:#DAA520">ΒΟΛΦΣΜΠΟΥΡΓΚ-ΧΟΦΕΝΧΑΙΜ (16.30) &nbsp; &nbsp;</span> &nbsp; &nbsp; &nbsp; <span style="color:#0000FF">&nbsp; 1</span></p><p><span style="color:#FF0000">1085</span>.<span style="color:#DAA520">ΤΟΥΛΟΥΖ-ΑΝΖΕ (21.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> 1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακή 18/10/2015', '1445148952', 'z.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1217. </span><span style="color:#DAA520">ΑΛΜΕΡΙΑ- ΕΛΤΣΕ (13.00) &nbsp; &nbsp; &nbsp; &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style="color:#0000FF"> ΓΚΟΛ </span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1263.</span> <span style="color:#DAA520">ΜΠΟΧΟΥΜ-ΛΕΙΨΙΑ (14.30) &nbsp; &nbsp; &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style="color:#0000FF">&nbsp; Χ2</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1453.</span> <span style="color:#DAA520">ΛΕΒΑΔΕΙΑΚΟΣ-ΠΑΝΑΙΤΩΛΙΚΟΣ (18.15) </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF">&nbsp; 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1525.</span> <span style="color:#DAA520">ΗΡΑΚΛΗΣ-ΠΑΟΚ (20.30)&nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> ΗΜ Χ</span></span></p><p>&nbsp;</p><p>&nbsp;</p>



<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14927),ba("_mId",180029);</script><div data-ti="14927_180029"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Μπάσκετ 18/10/2015', '1445149882', 'mpala-mpasket.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">3065.</span> <span style="color:#DAA520">ΜΠΙΛΜΠΑΟ - ΓΚΡΑΝ ΚΑΝΑΡΙΑ (14.00)</span>&nbsp;<span style="color:#0000FF"> 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">3078.</span><span style="color:#DAA520">ΤΣΜΟΚΙ-ΖΕΝΙΤ (17.30) &nbsp; &nbsp; &nbsp; </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF">&nbsp; 2</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">3091.</span><span style="color:#DAA520">ΛΙΜΟΖ- ΝΤΙΖΟΝ (21.00)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp;&nbsp; 1</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Δευτέρα 19/10/2015', '1445247118', 'stoixima.jpg', '<p><span style="color:#FF0000">1606.</span> <span style="color:#DAA520">ΠΑΝΑΘΗΝΑΙΚΟΣ-ΠΑΣ ΓΑΝΝΙΝΑ (17.15)</span>&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF"> 1/1</span></p><p><span style="color:#FF0000">1608</span>.<span style="color:#DAA520">ΛΑΜΙΑ-ΑΠΟΛΛΩΝ (18.00)&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF">&nbsp; Χ2</span></p><p><span style="color:#FF0000">1633.</span><span style="color:#DAA520"> ΜΠΙΕΛ -ΚΙΑΣΟ (20.45)&nbsp;&nbsp; &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> 1/1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Champions league  Τρίτη 20/10/2015 ', '1445315930', 'images.jpg', '<p><span style="color:#FF0000">1722.</span><span style="color:#DAA520"> ΑΡΣΕΝΑΛ - ΜΠΑΓΕΡΝ (21.45) &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> &nbsp; ΗΜ Χ</span></p><p><span style="color:#FF0000">1723. </span><span style="color:#DAA520">ΒΑΛΕΝΘΙΑ - ΓΑΝΔΗ (21.45)</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> 1/1</span></p><p><span style="color:#FF0000">1724.</span> <span style="color:#DAA520">ΖΕΝΙΤ- ΛΥΩΝ (21.45)&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<span style="color:#0000FF">&nbsp; 2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">1725</span>. <span style="color:#DAA520">ΛΕΒΕΡΚΟΥΖΕΝ- ΡΟΜΑ (21.45)</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> ΝΟ ΓΚΟΛ</span></p><p><span style="color:#FF0000">1726.</span> <span style="color:#DAA520">ΜΠΑΤΕ ΜΠΡΙΣΟΦ - ΜΠΑΡΤΣΕΛΟΝΑ (21.45) &nbsp;</span>&nbsp; &nbsp; <span style="color:#0000FF">&nbsp;&nbsp; 2</span></p><p><span style="color:#FF0000">1727</span>.<span style="color:#DAA520">ΝΤΙΝΑΜΟ-ΟΛΥΜΠΙΑΚΟΣ (21.45)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">Χ2</span></p><p><span style="color:#FF0000">1728.</span> <span style="color:#DAA520">ΝΤΙΝΑΜΟ ΚΙΕΒΟΥ -ΤΣΕΛΣΙ (21.45) </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style="color:#0000FF"> 2-3 ΓΚΟΛ</span></p><p><span style="color:#FF0000">1729.</span><span style="color:#DAA520">ΠΟΡΤΟ-ΜΑΚΑΜΠΙ (21.45)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp;&nbsp;&nbsp; 1/1</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Champions league Τετάρτη 21/10/2015', '1445402358', 'images.jpg', '<p><span style="color:#FF0000">1846</span><span style="color:#DAA520">.ΒΟΛΦΣΜΠΟΥΡΓΚ - ΑΙΝΤΧΟΦΕΝ (21.45)</span>&nbsp;&nbsp; <span style="color:#0000FF">1</span></p><p><span style="color:#FF0000">1847</span>. <span style="color:#DAA520">ΓΑΛΑΤΑΣΑΡΑΙ- ΜΠΕΝΦΙΚΑ (21.45)&nbsp;</span> <span style="color:#0000FF">ΗΜ Χ</span></p><p><span style="color:#FF0000">1849.</span><span style="color:#DAA520">ΜΑΛΜΕ-ΣΑΧΤΑΡ (21.45)</span><span style="color:#0000FF">&nbsp; ΓΚΟΛ</span></p><p><span style="color:#FF0000">1851</span>.<span style="color:#DAA520">ΠΑΡΙ ΣΕΝ ΖΕΡΜΕΝ - ΡΕΑΛ ΜΑΔΡΙΤΗΣ (21.45) </span><span style="color:#0000FF">2-3&nbsp; ΓΚΟΛ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΟΥΕΦΑ Γιουρόπα Λιγκ', '1445489642', 'europa.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1886.</span> <span style="color:#DAA520">ΑΛΚΜΑΑΡ- ΑΟΥΓΚΣΜΠΟΥΡΓΚ (20.00)</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1888</span>.<span style="color:#DAA520">ΑΠΟΕΛ - ΑΣΤΕΡΑΣ ΤΡΙΠΟΛΗΣ (20.00)&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1892.</span><span style="color:#DAA520">ΜΟΝΑΚΟ-ΚΑΡΑΜΠΑΚ (20.00)&nbsp; </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style="color:#0000FF">&nbsp; 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1908</span>. <span style="color:#DAA520">ΠΑΟΚ- ΚΡΑΣΝΟΝΤΑΡ (22.05)&nbsp;&nbsp;</span> &nbsp; &nbsp; &nbsp; <span style="color:#0000FF">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 1Χ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Παρασκευής 23/10/2013', '1445576311', 'z.jpg', '<p>1939. ΟΥΦΑ - ΚΡΙΛΙΑ (17.00)&nbsp; UNDER</p><p>1954. ΡΙΖΕΣΠΟΡ - ΑΚΙΣΑΣΠΟΡ (19.00)&nbsp;&nbsp;&nbsp; 1</p><p>199. ΧΑΒΡΗ - ΣΟΣΟ (21.00)&nbsp; ΓΚΟΛ</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σαββάτου 24/10/2015 ', '1445667159', 'pame_tameio.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">2933.</span> <span style="color:#DAA520">ΟΥΡΑΛ - ΑΝΚΑΡ (12.00) &nbsp; &nbsp; &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <span style="color:#0000FF">UNDER</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2159.</span> <span style="color:#DAA520">ΚΑΛΛΟΝΗ -ΛΕΒΑΔΕΙΑΚΟΣ (15.00)</span> &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <span style="color:#0000FF">ΗΜ Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2987.</span> <span style="color:#DAA520">ΖΑΚΥΝΘΟΣ- ΚΑΛΛΙΘΕΑ (16.00)&nbsp; &nbsp;</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#0000FF"> 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2460</span>.<span style="color:#DAA520">ΑΡΣΕΝΑΛ -ΕΒΕΡΤΟΝ (19.30)&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#0000FF">&nbsp;&nbsp; 1</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακή 25/10/2015', '1445755590', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">2590</span>.&nbsp; <span style="color:#DAA520">ΝΤΙΝΑΜΟ ΜΟΣΧΑΣ - ΣΠΑΡΤΑΚ ΜΟΣΧΑΣ (13.30)</span>&nbsp; <span style="color:#0000FF">UNDER</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2594.</span><span style="color:#DAA520"> ΜΑΓΙΟΡΚΑ - ΑΛΜΕΡΙΑ (14.00)</span> <span style="color:#0000FF">ΓΚΟΛ </span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2690. </span><span style="color:#DAA520">ΜΙΛΑΝ -ΣΑΣΣΟΥΟΛΟ (16.00)</span>&nbsp; <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2759.</span> <span style="color:#DAA520">ΠΑΝΙΩΝΙΟΣ - ΒΕΡΟΙΑ (17.15)</span>&nbsp; <span style="color:#0000FF">1</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Δευτέρα 26/10/2015', '1445876985', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">2951.</span> <span style="color:#DAA520">ΚΑΛΜΑΡ-ΓΚΕΦΛΕ (20.00)&nbsp;&nbsp;</span> <span style="color:#0000FF">1 </span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2966</span>.<span style="color:#DAA520">ΠΙΖΑ-ΡΙΜΙΝΙ (21.00)&nbsp;&nbsp;</span> <span style="color:#0000FF">ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2969.</span><span style="color:#DAA520">ΝΟΒΑΡΑ-ΠΕΣΚΑΡΑ (21.30)</span>&nbsp;<span style="color:#0000FF"> 2</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Τρίτη 27/10/2015', '1445946835', 'pame_tameio.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">542.</span><span style="color:#DAA520">ΚΑΛΙΘΕΑ- ΛΑΜΙΑ (19.30)</span> <span style="color:#0000FF">1/1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">556.</span><span style="color:#DAA520">ΤΟΥΡ- ΑΝΖΕ (21.00)&nbsp;</span>&nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">623.</span><span style="color:#DAA520">ΜΠΑΣΤΙΑ -ΡΕΝ (22.00)</span>&nbsp; <span style="color:#0000FF">2</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Κύπελλο Ελλάδας', '1446041985', 'pame_tameio.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">665.</span><span style="color:#DAA520"> ΠΑΝΑΘΗΝΑΙΚΟΣ-ΛΕΒΑΔΕΙΑΚΟΣ (17.15)</span><span style="color:#0000FF">&nbsp; UNDER</span></span></p><p><span style="color:#FF0000"><span style="font-size:16px">666.</span></span><span style="color:#DAA520"><span style="font-size:16px">ΠΑΝΑΙΤΩΛΙΚΟΣ -ΠΑΝΙΩΝΙΟΣ(17.15)&nbsp; </span></span><span style="color:#0000FF"><span style="font-size:16px">Χ2</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">676.</span><span style="color:#DAA520">ΠΑΟΚ-ΠΑΝΘΡΑΚΙΚΟΣ (17.15 )&nbsp;</span>&nbsp; <span style="color:#0000FF">ΗΜ Χ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('EYROCUP', '1446042260', 'eurocuplogo.png', '<p><span style="font-size:16px"><span style="color:#FF0000">3013.</span> <span style="color:#DAA520">OΥΝΙΚΣ ΚΑΖΑΝ - ΑΡΗΣ (18.00)</span>&nbsp; <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">301</span><span style="color:#DAA520">7.ΠΑΟΚ-ΜΠΕΣΙΚΤΑΣ (19.00)&nbsp;</span> <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">3021</span>.<span style="color:#DAA520">ΓΑΛΑΤΑΣΑΡΑΙ-ΧΑΠΟΕΛ (20.00)</span>&nbsp; <span style="color:#0000FF">1</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Πέμπτη 29/10/2015', '1446099838', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">794.</span> <span style="color:#DAA520">ΚΡΙΛΙΑ- ΝΤΙΝΑΜΟ ΜΟΣΧΑΣ (17.00)&nbsp; </span><span style="color:#0000FF">UNDER</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">826</span>.<span style="color:#DAA520">ΚΟΡΤΡΑΙΚ-ΑΝΤΕΡΛΕΧΤ (21.30)</span>&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">829.</span><span style="color:#DAA520">ΣΑΜΠΤΟΡΙΑ-ΕΜΠΟΛΙ (21.45)</span>&nbsp; <span style="color:#0000FF">Χ2</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Παρασκευή 30/10/2015 ', '1446184959', 'z.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">Πέρασαν οι προτάσεις μας χτες με τρια στα τρία ...για σήμέρα&nbsp; εχουμε τα εξής ..</span></span></p><p>&nbsp;</p><p><span style="font-size:16px"><span style="color:#FF0000">841</span>.<span style="color:#DAA520">ΣΛΑΒΙΑ ΣΟΦΙΑΣ -ΜΠΟΤΕΒ (14.30)&nbsp;</span> <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">875.</span><span style="color:#DAA520">ΜΠΟΧΟΥΜ -ΣΑΝ ΠΑΟΥΛΙ (19.30)&nbsp;</span>&nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">901</span>. <span style="color:#DAA520">ΣΟΣΟ - ΕΒΙΑΝ (21.00)&nbsp;&nbsp;</span>&nbsp;<span style="color:#0000FF"> ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">942.</span> <span style="color:#DAA520">ΤΟΝΤΕΛΑ - ΜΠΕΝΦΙΚΑ (22.30)</span> <span style="color:#0000FF">2</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σαββάτο 31/10/2015', '1446273782', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1024.</span> <span style="color:#DAA520">ΜΑΛΜΕ-ΝΟΡΚΕΠΙΝΓΚ (14.00)</span>&nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1028.</span><span style="color:#DAA520">ΚΡΟΟΥΛΙ- ΓΙΟΡΚ(14.30)&nbsp;</span>&nbsp;&nbsp;<span style="color:#0000FF"> ΗΜ Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1125</span>.<span style="color:#DAA520">ΛΙΒΟΡΝΟ- ΤΡΑΠΑΝΙ (16.00)</span>&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1262</span>.<span style="color:#DAA520">ΠΛΑΤΑΝΙΑΣ-ΚΑΛΛΟΝΗ (17.15)</span><span style="color:#0000FF"> 1</span></span></p><p>&nbsp;</p>


<script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14936),ba("_mId",180029);</script><div data-ti="14936_180029"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακή 01/11/2015', '1446359604', 'pame_tameio.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1480. </span><span style="color:#DAA520">ΕΙΜΠΑΡ-ΒΑΙΕΚΑΝΟ (13.00)&nbsp;</span>&nbsp; <span style="color:#0000FF">Χ2</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1541</span><span style="color:#DAA520">. ΝΙΣ-ΛΙΛ (15.00)</span>&nbsp;<span style="color:#0000FF"> ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1645</span>. <span style="color:#DAA520">ΜΟΝΑΚΟ- ΑΝΖΕ</span> <span style="color:#DAA520">(18.00)</span><span style="color:#0000FF">&nbsp;&nbsp; 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1738.</span><span style="color:#DAA520">ΚΛΟΥΖ-ΣΤΕΑΟΥΑ (20.30)</span>&nbsp;&nbsp;&nbsp; <span style="color:#0000FF">ΗΜ Χ</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Μπάσκετ..', '1446371411', 'medium_20150616101846_mpala_mpasket_spalding_nba_tf_250_size_6.jpeg', '<p><span style="font-size:16px"><span style="color:#FF0000">3549</span>.<span style="color:#DAA520">ΛΑΜΠΟΡΑΛ ΚΟΥΤΣΑ -ΓΚΡΑΝ ΚΑΝΑΡΙΑ (14.00)</span>&nbsp; 1</span></p><p><span style="font-size:16px"><span style="color:#FF0000">3465</span>.<span style="color:#DAA520">ΤΣΙΜΠΟΝΑ-ΙΓΚΟΚΕΑ (18.00)</span>&nbsp; 1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Δευτέρα 02/11/2015', '1446442660', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1819</span>.<span style="color:#DAA520">ΜΟΝΤΑΝΑ- ΛΕΦΣΚΙ ( 14.00)&nbsp;</span>&nbsp;<span style="color:#0000CD"> 2</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1828</span>.<span style="color:#DAA520">ΚΑΛΛΙΘΕΑ-ΧΑΝΙΑ (16.00)</span> <span style="color:#0000FF">ΗΜ Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1861.</span><span style="color:#DAA520">ΠΑΛΕΡΜΟ - ΕΜΠΟΛΙ (22.00) </span><span style="color:#0000FF">ΓΚΟΛ </span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Champion league...', '1446552509', 'images.jpg', '<p><span style="font-size:16px"><span style="color:#0000FF">1920. </span><span style="color:#DAA520">ΑΙΝΤΧΟΦΕΝ- ΒΟΛΦΣΜΠΟΥΡΓΚ (21.45)</span>&nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#0000FF">1923.</span><span style="color:#DAA520">ΜΠΕΝΦΙΚΑ-ΓΑΛΑΤΑΣΑΡΑΙ (21.45)</span> <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#0000FF">1925.</span> <span style="color:#DAA520">ΣΑΧΤΑΡ - ΜΑΛΜΕ (21.45)&nbsp;&nbsp;</span>&nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ </span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Τετάρτη 4/11/2015', '1446627521', 'images.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1995.</span><span style="color:#DAA520">ΓΑΝΔΗ - ΒΑΛΕΝΘΙΑ (21.45)</span> <span style="color:#0000FF">ΓΚΟΛ </span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1996</span>.<span style="color:#DAA520">ΛΥΩΝ- ΖΕΝΙΤ (21.45)</span>&nbsp;&nbsp; <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2002.</span><span style="color:#DAA520">ΤΣΕΛΣΙ- ΝΤΙΝΑΜΟ (21.45)&nbsp;&nbsp;</span> <span style="color:#0000FF">1</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Πέμπτη 05/11/2015', '1446700467', 'europa.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">2054. </span><span style="color:#DAA520">ΣΕΛΤΙΚ-ΜΟΛΝΤΕ (20.00)</span>&nbsp; <span style="color:#0000FF">1/1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2055</span>.<span style="color:#DAA520"> ΣΙΟΝ-ΜΠΟΡΝΤΟ (20.00)</span>&nbsp;&nbsp; <span style="color:#0000FF">ΗΜ Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2068</span> . <span style="color:#DAA520">ΤΟΤΕΝΑΜ- ΑΝΤΕΡΛΕΧΤ (22.05) </span><span style="color:#0000FF">1</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Παρασκευή 06/11/2015', '1446788167', 'pame_tameio.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">2217.</span><span style="color:#DAA520">ΑΜΙΑΝ- ΑΒΡΑΝΣ (21.00)&nbsp;</span> <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2265</span>.<span style="color:#DAA520">ΕΒΙΑΝ-ΒΑΛΕΝΣΙΕΝ (21.00)</span>&nbsp;<span style="color:#0000FF"> 2-3 ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2271</span>.<span style="color:#DAA520">ΟΣΕΡ-ΛΑΝΣ (21.00)</span>&nbsp; <span style="color:#0000FF">ΗΜ 1</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Euroleague mpasket..', '1446788605', 'medium_20150616101846_mpala_mpasket_spalding_nba_tf_250_size_6.jpeg', '<p><span style="font-size:18px"><span style="color:#FF0000">3037.</span> <span style="color:#DAA520">ΖΙΕΛΟΝΑ-ΠΑΝΑΘΗΝΑΙΚΟΣ (20.00)</span><span style="color:#0000FF"> 2</span></span></p><p><span style="font-size:18px"><span style="color:#FF0000">3033</span><span style="color:#DAA520"> .ΕΡΥΘΡΟΣ-ΦΕΝΕΡΝΜΠΑΧΤΣΕ (21.00)</span>&nbsp; <span style="color:#0000FF">2</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σαββάτο 07/11/2015', '1446873859', 'z.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">2427.</span> <span style="color:#DAA520">ΑΑΛΕΝ - ΕΡΦΟΥΡΤ (15.00)</span>&nbsp; <span style="color:#0000FF">1 ΚΑΙ ΟΒΕΡ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2668.</span><span style="color:#DAA520">ΤΕΝΕΡΙΦΗ - ΑΛΑΒΕΣ (19.00)&nbsp;</span>&nbsp; <span style="color:#0000FF">Χ2</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2734. </span><span style="color:#DAA520">ΕΙΜΠΑΡ-ΧΕΤΑΦΕ (21.30)&nbsp;</span>&nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακή 08/11/2015', '1446974439', 'soccer-ball1.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">2911. </span><span style="color:#DAA520">ΑΓΡΟΤΙΚΟΣ ΑΣΤΕΡΑΣ- ΛΑΜΙΑ &nbsp;(15.00) </span>&nbsp;<span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2933.</span> <span style="color:#DAA520">ΕΜΠΟΛΙ-ΓΙΟΥΒΕΝΤΟΥΣ &nbsp;(16.00)</span> &nbsp;<span style="color:#0000FF">1Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">639.</span><span style="color:#DAA520">ΣΕΒΙΛΛΗ-ΡΕΑΛ ΜΑΔΡΙΤΗΣ (21.30) </span>&nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">649.</span><span style="color:#DAA520">ΜΠΟΡΝΤΟ-ΜΟΝΑΚΟ (22.00) </span><span style="color:#0000FF">&nbsp;Χ2</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Τρίτη 10/11/2015 ', '1447138483', 'images.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">748.</span><span style="color:#DAA520">ΓΟΥΙΓΚΑΝ-ΜΠΛΑΚΠΟΥΛ (21.45) </span><span style="color:#0000FF">ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">766.</span><span style="color:#DAA520">ΠΛΙΜΟΥΘ-ΜΙΛΓΟΥΟΛ (21.45)</span>&nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Τετάρτη 11/11/2015 ', '1447251320', '_.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">790.</span> <span style="color:#DAA520">ΙΟΡΔΑΝΙΑ-ΜΑΛΤΑ (17.00) </span>&nbsp;<span style="color:#0000FF"> 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">797.</span><span style="color:#DAA520">ΕΣΘΟΝΙΑ-ΓΕΩΡΓΙΑ (19.00)</span> &nbsp;<span style="color:#0000FF">ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">799.</span><span style="color:#DAA520">ΣΟΥΔΑΝ-ΖΑΜΠΙΑ (19.00) </span>&nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Πέμπτη 12/11/2015 ', '1447307890', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">839</span><span style="color:#DAA520">.ΙΝΔΙΑ-ΓΟΥΑΜ (15.30)&nbsp;</span><span style="color:#0000FF">&nbsp; 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">870</span>. <span style="color:#DAA520">ΝΟΡΒΗΓΙΑ-ΟΥΓΓΑΡΙΑ (21.45)&nbsp;</span> <span style="color:#0000FF">ΗΜ Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">871.</span><span style="color:#DAA520">ΒΟΛΙΒΙΑ-ΒΕΝΕΖΟΥΕΛΑ (22.00)</span> <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Φιλικά ...Παρασκευή 13/11/2015', '1447395501', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">2103</span>. <span style="color:#DAA520">ΤΣΕΧΙΑ-ΣΕΡΒΙΑ (21.30)&nbsp;</span> <span style="color:#0000FF">Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2102</span><span style="color:#DAA520">.ΙΣΠΑΝΙΑ-ΑΓΓΛΙΑ (21.45)</span>&nbsp;&nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2106</span>.<span style="color:#DAA520">ΒΕΛΓΙΟ-ΙΤΑΛΙΑ (21.45)&nbsp;</span><span style="color:#0000FF">&nbsp; ΗΜ Χ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Επιλογές Σαββάτου  14/11/2015', '1447484830', 'pame_tameio.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1000.</span><span style="color:#DAA520">ΑΑΧΕΝ-ΒΕΡΛ (15.00)</span>&nbsp;<span style="color:#0000FF"> 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1019.</span><span style="color:#DAA520">ΡΩΣΙΑ-ΠΟΡΤΟΓΑΛΙΑ (16.00)</span>&nbsp; <span style="color:#0000FF">ΗΜ Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1200</span>.<span style="color:#DAA520">ΛΟΥΓΚΟ-ΕΛΤΣΕ (21.45)</span>&nbsp; <span style="color:#0000FF">ΓΚΟΛ</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακή 15/11/2015', '1447577595', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1281.</span><span style="color:#DAA520">ΣΠΕΤΣΙΑ-ΚΑΛΙΑΡΙ (13.30)</span> <span style="color:#0000FF">Χ2</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1327.</span><span style="color:#DAA520">ΕΡΓΟΤΕΛΗΣ-ΟΛΥΜΠΙΑΚΟΣ ΒΟΛΟΥ (15.00)</span>&nbsp; <span style="color:#0000FF">ΗΜ Χ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1397.</span><span style="color:#DAA520">ΑΛΜΕΡΙΑ-ΠΟΝΦΕΡΑΝΤΙΝΑ (18.00)</span>&nbsp;&nbsp;<span style="color:#0000FF"> 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1413</span><span style="color:#DAA520">.ΟΣΑΣΟΥΝΑ-ΜΑΓΙΟΡΚΑ (20.15)&nbsp;&nbsp;</span>&nbsp; <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Δευτέρα 16/11/2015', '1447649000', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1438</span>.<span style="color:#DAA520">ΠΑΝΑΙΓΙΑΛΕΙΟΣ-ΚΙΣΣΑΜΙΚΟΣ (15.00)</span><span style="color:#0000FF"> 1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1440.</span><span style="color:#DAA520">ΚΑΣΣΙΟΠΗ-ΧΑΝΙΑ (18.00)&nbsp;</span><span style="color:#0000FF"> Χ/1</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Επιλογές με γκόλ Τρίτη 17/11/2015', '1447764391', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1533.</span><span style="color:#DAA520">ΡΩΣΙΑ-ΚΡΟΑΤΙΑ (18.00)</span> <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1542.</span><span style="color:#DAA520">ΤΥΝΗΣΙΑ-ΜΑΥΡΙΤΑΝΙΑ (19.00)</span> <span style="color:#0000FF">ΝΟ ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1580</span><span style="color:#DAA520">.ΑΥΣΤΡΙΑ-ΕΛΒΕΤΙΑ (21.45)</span> <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Τετάρτη 18/11/2015', '1447826026', 'pame_tameio.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1606.</span><span style="color:#DAA520">ΛΕΤΟΝΙΑ U19-ΣΛΟΒΕΝΙΑ U19 (17.30)&nbsp;</span> <span style="color:#0000FF">1X</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1607</span>.<span style="color:#DAA520">ΣΚΩΤΙΑ U19-ΙΡΛΑΝΔΙΑ U19 (17.30) </span><span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Παρασκευή 20/11/2015', '1448000985', 'goal_goal_goal_logo.png', '<p><span style="font-size: 16px;"><span style="color: rgb(255, 0, 0);">1728.</span><span style="color: rgb(218, 165, 32);">ΛΑΝΣ-ΝΙΟΡ&nbsp; (21.00)&nbsp;</span> <span style="color: rgb(0, 0, 255);">ΗΜ Χ</span></span></p><p><span style="font-size: 16px;"><span style="color: rgb(255, 0, 0);">1731.</span><span style="color: rgb(218, 165, 32);">ΣΟΣΟ-ΛΑΒΑΛ (21.00)&nbsp;</span> <span style="color: rgb(0, 0, 255);">Χ2</span></span></p><p><span style="font-size: 16px;"><span style="color: rgb(255, 0, 0);">1753.</span> <span style="color: rgb(218, 165, 32);">ΝΙΣ-ΛΥΩΝ (21.30)&nbsp;&nbsp;</span> <span style="color: rgb(0, 0, 255);">ΗΜ 1</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σάββατο 21/11/2015', '1448087218', 'stoixima.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">1839.</span> <span style="color:#DAA520">ΜΕΤΣ-ΟΣΕΡ (15.00)</span> <span style="color:#0000FF">2-3 ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1897.</span><span style="color:#DAA520">ΝΟΒΑΡΑ-ΣΠΕΤΣΙΑ (16.00)&nbsp;</span> <span style="color:#0000FF">Χ2</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">1973.</span><span style="color:#DAA520">ΕΒΕΡΤΟΝ-ΑΣΤΟΝ ΒΙΛΑ (17.00)</span> <span style="color:#0000FF">ΓΚΟΛ</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2138</span>.<span style="color:#DAA520">ΡΕΑΛ-ΜΠΑΡΤΣΕΛΟΝΑ (19.15) </span><span style="color:#0000FF">ΗΜ 1</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακή 22/11/2015 ', '1448183354', 'z_6.jpg', '<p><span style="font-size: 16px;"><span style="color: rgb(255, 0, 0);">2268.</span><span style="color: rgb(218, 165, 32);">ΒΕΡΟΝΑ-ΝΑΠΟΛΙ (13.30)&nbsp;</span>&nbsp; <span style="color: rgb(0, 0, 255);">1Χ</span></span></p><p><span style="font-size: 16px;"><span style="color: rgb(255, 0, 0);">2318.</span> <span style="color: rgb(218, 165, 32);">ΖΑΚΥΝΘΟΣ-ΤΡΙΚΑΛΑ (15.00)</span>&nbsp;<span style="color: rgb(0, 0, 255);">&nbsp; 1Χ</span></span></p><p><span style="font-size: 16px;"><span style="color: rgb(255, 0, 0);">2432</span>.<span style="color: rgb(218, 165, 32);">ΜΠΑΡΙ-ΛΙΒΟΡΝΟ (18.30) </span><span style="color: rgb(0, 0, 255);">2-3 ΓΚΟΛ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις με γκολ Δευτέρα 23/11/2015', '1448259165', 'stoixima.jpg', '<p><span style="font-size:16px">2542. ΚΙΣΣΑΜΙΚΟΣ -ΕΡΓΟΤΕΛΗΣ (18.00)&nbsp; 2-3 ΓΚΟΛ</span></p><p><span style="font-size:16px">2546.ΡΟΣΤΟΦ - ΟΥΦΑ (18.00)&nbsp;&nbsp;&nbsp;&nbsp; UNDER </span></p><p><span style="font-size:16px">2565. ΧΑΒΡΗ- ΜΠΡΕΣΤ (21.30)&nbsp;&nbsp; ΓΚΟΛ</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Champions League', '1448352325', 'championsss.jpg', '<p><span style="font-size: 16px;">2669. ZENIT-ΒΑΛΕΝΘΙΑ (19.30)&nbsp; ΗΜ Χ</span></p><p><span style="font-size: 16px;">2680.ΛΥΩΝ-ΓΑΝΔΗ (21.45)&nbsp;&nbsp; 2-3 ΓΚΟΛ</span></p><p><span style="font-size: 16px;">2684.ΠΟΡΤΟ- ΝΤΙΝΑΜΟ ΚΙΕΒΟΥ(21.45)&nbsp; 2-3 ΓΚΟΛ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Champions league', '1448455290', 'th695g5g9l.jpg', '<p><span style="font-size: 16px;">2778.ΓΙΟΥΒΕΝΤΟΥΣ-ΜΑΝΤΣΕΣΤΕΡ ΣΙΤΙ&nbsp; (21.45)&nbsp; ΗΜ Χ</span></p><p><span style="font-size: 16px;">2779.ΓΚΛΑΝΤΜΠΑΧ-ΣΕΒΙΛΛΗ (21.45)&nbsp;&nbsp; 2-3 ΓΚΟΛ</span></p><p><span style="font-size: 16px;">2782.ΣΑΧΤΑΡ-ΡΕΑΛ ΜΑΔΡΙΤΗΣ (21.45)&nbsp;&nbsp; 2/2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('europa league', '1448550868', 'thmz2ze4ig.jpg', '<p><span style="font-size: 16px;">2822.ΑΛΚΜΑΑΡ-ΠΑΡΤΙΖΑΝ (20.00) 1</span></p><p><span style="font-size: 16px;">2824.ΒΑΣΙΛΕΙΑ-ΦΙΟΡΕΝΤΙΝΑ (20.00)&nbsp; ΓΚΟΛ</span></p><p><span style="font-size: 16px;">2828.ΜΟΝΑΚΟ-ΑΝΤΕΡΛΕΧΤ (20.00) ΗΜ Χ</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Παρασκευή 27/11/2015', '1448617111', 'thsz7vhomq.jpg', '<p><span style="font-size: 16px;">541.ΡΙΖΕΣΠΟΡ-ΚΟΝΙΑΣΠΟΡ (19.00)&nbsp;&nbsp; Χ2</span></p><p><span style="font-size: 16px;">564.ΕΒΙΑΝ-ΛΑΒΑΛ (21.00)&nbsp; Χ2</span></p><p><span style="font-size: 16px;">571. ΠΑΡΙ - ΝΤΙΖΟΝ (21.00)&nbsp; ΓΚΟΛ</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σαββάτο 28/11/2015', '1448704297', 'thnq0elws8.jpg', '<p><span style="font-size: 16px;">722. ΚΟΜΟ -ΜΠΑΡΙ (16.00)&nbsp; 2</span></p><p><span style="font-size: 16px;">908. ΑΛΜΕΡΙΑ-ΝΟΥΜΑΝΘΙΑ (19.00)&nbsp; 1</span></p><p><span style="font-size: 16px;">949.ΑΝΖΕ-ΛΙΛ (21.00) ΗΜ Χ</span></p><p><span style="font-size: 16px;">967.ΜΑΛΑΓΑ-ΓΡΑΝΑΔΑ (21.30) 1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Κυριακή 29/11/2015', '1448779942', 'stoixima.jpg', '<p><span style="font-size:16px">1015.ΧΕΤΑΦΕ-ΒΙΓΙΑΡΕΑΛ (13.00) 1Χ</span></p><p><span style="font-size:16px">1107.ΚΙΕΒΟ-ΟΥΝΤΙΝΕΖΕ (16.00) Χ</span></p><p><span style="font-size:16px">1174.ΑΣΚΟΛΙ-ΤΡΑΠΑΝΙ (18.00) ΓΚΟΛ</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Τρίτη 01/12/2015', '1448964089', 'untitled.png', '<p><span style="font-size: 16px;">1385. ΛΟΡΙΑΝ- ΝΙΣ (20.00)&nbsp; 2-3 ΓΚΟΛ</span></p><p><span style="font-size: 16px;">1420. ΝΑΝΤ-ΛΥΩΝ (22.00)&nbsp; ΗΜ Χ</span></p><p><span style="font-size: 16px;">1429.ΧΑΒΡΗ-ΕΒΙΑΝ (22.00) ΓΚΟΛ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 02/12/2015', '1449045439', 'thv9y36n2k.jpg', '<p><span style="font-size: 16px;">1467.ΠΛΑΤΑΝΙΑΣ-ΑΠΟΛΛΩΝ (16.00)&nbsp; ΗΜ Χ</span></p><p><span style="font-size: 16px;">1482.ΑΛΤΑΧ-ΡΙΝΤ (19.30)&nbsp; 1</span></p><p><span style="font-size: 16px;">1494.ΤΡΟΥΑ-ΤΟΥΛΟΥΖ (20.00) 2</span></p><p><span style="font-size: 16px;">1520.ΑΛΜΕΡΙΑ-ΘΕΛΤΑ (22.00) 1Χ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πέμπτη 03/12/2015', '1449130727', 'thv9y36n2k.jpg', '<p><span style="font-size: 16px;">1526. ΒΕΡΟΙΑ-ΚΑΛΛΙΘΕΑ (15.00) ΗΜ Χ</span></p><p><span style="font-size: 16px;">1552.ΛΕΒΑΝΤΕ-ΕΣΠΑΝΙΟΛ (22.00) Χ2</span></p><p><span style="font-size: 16px;">1553.ΜΙΡΑΝΤΕΣ-ΜΑΛΑΓΑ (22.00)&nbsp; 2 </span></p><p>&nbsp;</p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις με γκολ Παρασκευή 04/12/2015', '1449214887', 'goal_goal_goal_logo.png', '<p><span style="font-size:16px">1618. ΡΟΣΤΟΦ-ΡΟΥΜΠΙΝ ΚΑΖΑΝ (18.00) 2-3 ΓΚΟΛ</span></p><p><span style="font-size:16px">1654. ΣΑΛΚΕ-ΑΝΝΟΒΕΡΟ (21.30) ΓΚΟΛ</span></p><p><span style="font-size:16px">1659.ΛΑΤΣΙΟ- ΓΙΟΥΒΕΝΤΟΥΣ (21.45)&nbsp; UNDER</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σαββάτο 05/12/2015', '1449317669', 'katalogos.jpg', '<p><span style="font-size:16px">1722.ΛΑΤΙΝΑ-ΛΙΒΟΡΝΟ (16.00) 2</span></p><p><span style="font-size:16px">1741.ΧΕΡΤΑ-ΛΕΒΕΡΚΟΥΖΕΝ (16.30) 2</span></p><p><span style="font-size:16px">1777.ΣΟΥΟΝΣΙ-ΛΕΣΤΕΡ (17.00)&nbsp; Χ2</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακή 06/12/2015', '1449385378', 'images.jpg', '<p><span style="font-size:16px">2006.ΒΙΛΕΜ-ΚΑΜΠΟΥΡ (13.30)&nbsp; ΓΚΟΛ</span></p><p><span style="font-size:16px">2053.ΠΑΟΚ-ΠΑΝΙΩΝΙΟΣ (15.00) ΗΜ Χ</span></p><p><span style="font-size:16px">2117.ΤΟΥΝ-ΒΑΣΙΛΕΙΑ (17.00)&nbsp; 2</span></p><p><span style="font-size:16px">2242.ΚΑΡΠΙ-ΜΙΛΑΝ (21.45)&nbsp;&nbsp; Χ/2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Δευτέρα 07/12/2015', '1449474666', 'th.jpg', '<p><span style="font-size: 16px;">2269.ΚΑΛΛΙΘΕΑ- ΕΡΓΟΤΕΛΗΣ (17.00)&nbsp;&nbsp;&nbsp; ΗΜ Χ</span></p><p><span style="font-size: 16px;">2298.ΕΣΠΑΝΙΟΛ-ΛΕΒΑΝΤΕ (21.30)&nbsp; 2-3 ΓΚΟΛ</span></p><p><span style="font-size: 16px;">2307.ΕΒΕΡΤΟΝ-ΚΡΣΤΑΣ ΠΑΛΛΑΣ (22.00) 1</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Χριστουγεννιάτικη προσφορά για το καζίνο από την 2winbet', '1449510581', 'n.png', '<p><span style="color:#FF0000">Casino Free Spins με την 1η σας Κατάθεση 100% έως 500 ευρώ</span></p><p>Κάντε την 1η σας Κατάθεση απο 10 € έως 500 €</p><p>Στείλτε email στο&nbsp;<a href="mailto:support@2winbet.gr" target="_blank">support@2winbet.gr</a>&nbsp;με Θέμα "CASINO Christmas Bonus" και θα πιστωθείτε έως και 500 Free Spins ανάλογα με την Καταθεσή σας</p><p>Όροι και Προυποθέσεις</p><p><br>Τα Free Spins θα πιστώνονται σε Ταυτοποιημένους Πελάτες που κατέθεσαν χρήματα στην πλατφόρμα μας.</p><p>Τα Free Spins έχουν Διάρκεια 7 ημέρες και θα πιστώνονται εντός 24 ωρών από το αίτημα σας</p><p>Τα Free Spins θα πιστώνονται σε Επιλεγμένα Slots της Netent !</p><p>H Προσφορά Ισχύει απο της 27/11/2015 έως 25/12/2015</p><p>&nbsp;</p><p>ΚΑΝΤΕ ΕΓΓΡΑΦΗ ΑΠΌ ΕΔΩ</p><script type="text/javascript">!function(e,t,a,n,c,s){e.bcAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments),e[c].u=e[c].u||n};var i=t.createElement(a),o=t.getElementsByTagName(a)[0];i.async=!0,i.src=n+"analytics/ba.min.js",i.id=s,!t.getElementById(s)&&o.parentNode.insertBefore(i,o)}(window,document,"script","http://affiliates.2winbet.gr/global/","ba","bafTrSc"),ba("_setAccount",14936),ba("_mId",179621);</script><div data-ti="14936_179621"></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('UEFA Champions League', '1449576491', 'champions-league-trophy.jpg', '<p><span style="font-size: 16px;">2328. ΒΟΛΦΣΜΠΟΥΡΓΚ -ΜΑΝΤΣΕΣΤΕΡ ΓΙΟΥΝ. (21.45) ΗΜ Χ</span></p><p><span style="font-size: 16px;">2331.ΜΠΕΝΦΙΚΑ-ΑΤΛΕΤΙΚΟ (21.45) 4-6 ΓΚΟΛ</span></p><p><span style="font-size: 16px;">2334.ΣΕΒΙΛΛΗ-ΓΙΟΥΒΕΝΤΟΥΣ (21.45)&nbsp; ΗΜ Χ </span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('UEFA Champions League', '1449687247', 'champions-league-trophy.jpg', '<p><span style="font-size: 16px;">2393. ΒΑΛΕΝΘΙΑ-ΛΥΩΝ (21.45)2-3 ΓΚΟΛ</span></p><p><span style="font-size: 16px;">2398.ΟΛΥΜΠΙΑΚΟΣ ΑΡΣΕΝΑΛ (21.45) ΗΜ Χ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΟΥΕΦΑ Γιουρόπα Λιγκ', '1449757234', 'europa-league.jpg', '<p><span style="font-size:16px">2428.ΜΠΟΡΝΤΟ-ΡΟΥΜΠΙΝ ΚΑΖΑΝ (20.00) ΙΧ</span></p><p><span style="font-size:16px">2432.ΣΙΟΝ-ΛΙΒΕΡΠΟΥΛ(20.00) Χ/2</span></p><p><span style="font-size:16px">2445.ΤΟΤΕΝΑΜ-ΜΟΝΑΚΟ(22.05) ΗΜ Χ</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 11/12/2015', '1449842995', 'images.jpg', '<p><span style="font-size:16px">540.ΕΒΙΑΝ-ΜΠΡΕΣΤ (21.00)&nbsp; Χ</span></p><p><span style="font-size:16px">545.ΟΣΕΡ-ΤΟΥΡ (21.00) 2</span></p><p><span style="font-size:16px">546.ΠΑΡΙ-ΛΑΝΣ(21.00) 2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 12/12/2015', '1449910793', 'th.jpg', '<p><span style="font-size: 16px;">595. ΜΕΤΣ-ΝΤΙΖΟΝ (15.00)&nbsp; 2</span></p><p><span style="font-size: 16px;">614.ΖΑΚΥΝΘΟΣ-ΧΑΝΙΑ (15.00)&nbsp; 2</span></p><p><span style="font-size: 16px;">787.ΧΙΡΟΝΑ-ΕΛΤΣΕ (19.00) ΓΚΟΛ</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 13/12/2015', '1450011422', 'images.jpg', '<p><span style="font-size:16px">916.ΣΙΟΝ-ΒΑΣΙΛΕΙΑ (16.30)&nbsp; 2</span></p><p><span style="font-size:16px">931.ΞΑΝΘΗ-ΒΕΡΟΙΑ (17.15)&nbsp; Χ2</span></p><p><span style="font-size:16px">998.ΝΑΠΟΛΙ-ΡΟΜΑ (19.00)&nbsp; Χ2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('14/12/2015', '1450092056', 'katalogos.jpg', '<p>1<span style="font-size:16px">051.ΝΟΒΑΡΑ-ΤΡΑΠΑΝΙ (21.30) Χ2</span></p><p><span style="font-size:16px">1056.ΛΕΣΤΕΡ-ΤΣΕΛΣΙ (22.00) Χ2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 15/12/2015', '1450188528', 'goal11.jpg', '<p><span style="font-size:16px">1116.ΛΙΛ-ΛΑΒΑΛ &nbsp;(21.00) ΓΚΟΛ</span></p><p><span style="font-size:16px">1163.ΡΕΝ-ΤΟΥΛΟΥΖ (22.00) 2-3 ΓΚΟΛ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 16/12/2015', '1450254867', 'images.jpg', '<p>1184.ΚΑΛΛΙΘΕΑ-ΑΤΡΟΜΗΤΟΣ (17.15) &nbsp;1Χ</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 17/12/2015', '1450369710', 'thgosknj1g.jpg', '<p><span style="font-size: 16px;">1261.ΘΕΛΤΑ-ΑΛΜΕΡΙΑ (21.00)&nbsp;&nbsp; ΗΜ Χ</span></p><p><span style="font-size: 16px;">1268.ΓΡΕΝΑΔΑ-ΛΕΓΚΑΝΕΣ (22.00)&nbsp; 2-3 ΓΚΟΛ </span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 18/12/2015', '1450427836', 'th2bzy58mu.jpg', '<p><span style="font-size: 16px;">1304.ΛΑΒΑΛ-ΝΙΜ (21.00&nbsp; 2-3 ΓΚΟΛ</span></p><p><span style="font-size: 16px;">1322.ΕΜΕΝ-ΦΕΝΛΟ (21.00)&nbsp;&nbsp; Χ2</span></p><p><span style="font-size: 16px;">1338.ΠΕΡΟΥΤΖΙΑ-ΛΙΒΟΡΝΟ (22.00) Χ2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 19/12/2015', '1450512608', 'th9j0ru0h3.jpg', '<p><span style="font-size: 16px;">1356.ΤΟΥΡ-ΜΕΤΣ (15.00) Χ2</span></p><p><span style="font-size: 16px;">1374.ΚΟΜΟ- ΑΒΕΛΙΝΟ (16.00)&nbsp; Χ2</span></p><p><span style="font-size: 16px;">1499.ΒΑΛΕΝΘΙΑ-ΧΕΤΑΦΕ (17.00) 1</span></p><p><span style="font-size: 16px;">1577.ΜΠΑΣΤΙΑ-ΡΕΜΣ (22.00) Χ2 </span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 20/12/2015 ', '1450613102', 'thi7kkbxqv.jpg', '<p><span style="font-size: 16px;">1680. ΑΒΕΣ-ΦΑΡΕΝΣΕ (17.00 ΓΚΟΛ</span></p><p><span style="font-size: 16px;">1652.ΛΑΡΙΣΑ- ΤΡΙΚΑΛΑ (18.00)&nbsp; Χ/1</span></p><p><span style="font-size: 16px;">1748.ΙΝΤΕΡ-ΛΑΤΣΙΟ (21.45)&nbsp;&nbsp; 1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('21/12/2015', '1450682007', 'thi7kkbxqv.jpg', '<p><span style="font-size: 16px;">1761.ΚΑΛΛΙΘΕΑ-ΟΛΥΜΠΙΑΚΟΣ ΒΟΛΟΥ (15.00)&nbsp; Χ</span></p><p><span style="font-size: 16px;">1778. ΑΡΣΕΝΑΛ -ΜΑΝΤΣΕΣΤΕΡ ΣΙΤΙ 1/1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 22/12/2015', '1450774036', 'thhmq5cjrr.jpg', '<p>2002.ΑΠΟΕΛ-ΑΕΚ ΛΑΡΝΑΚΑΣ (17.00)&nbsp; Χ2</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πρόταση 23/12/2015', '1450863921', 'thomrkx9tt.jpg', '<p>2031.ΠΕΣΚΑΡΑ-ΜΟΝΤΕΝΑ (21.30)&nbsp; 2</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Χρόνια Πολλά !!!', '1450991806', 'n.png', '<p>ΧΡΟΝΙΑΑΑΑΑ ΠΟΛΛΑΑΑΑΑΑΑ</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΚΑΛΑ ΧΡΙΣΤΟΥΓΕΝΝΑ', '1451061496', 'isartas.gif', '<p>ΧΡΟΝΙΑ ΠΟΛΛΑ ΚΑΛΑ ΧΡΙΣΤΟΥΓΕΝΝΑ</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Δευτέρα 28/12/2015', '1451295381', 'goal_goal_goal_logo.png', '<p>2377. ΜΑΝΤΣΕΣΤΕΡ Γ. -ΤΣΕΛΣΙ (19.00)&nbsp; Χ</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 29/12/2015', '1451387211', '12032121_1487480728215451_673998168563287595_n.jpg', '<p>2383.ΦΟΥΛΑΜ-ΡΟΔΕΡΑΜ (21.45) 2</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('2434. ΒΙΓΙΑΡΕΑΛ-ΒΑΛΕΝΘΙΑ 17.00', '1451553022', '12032121_1487480728215451_673998168563287595_n.jpg', '<p>ΘΑ ΠΑΜΕ ΜΕ ΤΟΝ Χ ΗΜΙΧΡΟΝΟ ΑΣΣΟ ΤΕΛΙΚΟ !!</p><p>&nbsp;</p><p>ΚΑΛΗ ΠΡΩΤΟΧΡΟΝΙΑ</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΚΑΛΗ ΧΡΟΝΙΑ.....', '1451677886', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p>Η BETVISION ΣΑΣ ΕΥΧΕΤΑΙ ΚΑΛΗ ΧΡΟΝΙΑ</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 02/01/2016', '1451723194', 'thomrkx9tt.jpg', '<p><span style="font-size: 16px;">2596. ΠΑΣ ΓΙΑΝΝΙΝΑ-ΒΕΡΟΙΑ (17.15)&nbsp; ΗΜ Χ</span></p><p><span style="font-size: 16px;">2615.ΟΣΑΣΟΥΝΑ-ΤΑΡΑΓΟΝΑ (19.00) Χ2</span></p><p><span style="font-size: 16px;">2626.ΣΠΟΡΤΙΝΓΚ ΛΙΣ-ΠΟΡΤΟ (22.45) ΓΚΟΛ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 3/1/2016', '1451816814', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p>2653.ΛΕΒΑΔΕΙΑΚΟΣ-ΑΤΡΟΜΗΤΟΣ (17.15)&nbsp;&nbsp; ΗΜ Χ</p><p>2654.ΞΑΝΘΗ-ΠΑΟΚ (17.15)&nbsp;&nbsp; 2</p><p>2719.ΠΑΝΙΩΝΙΟΣ-ΟΛΥΜΠΙΑΚΟΣ (19.30)&nbsp; 1Χ</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Γαλλία ...ΝΙΣ-ΡΕΝ  04/01/2016', '1451924114', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="font-size:18px">2740. ΝΙΣ-ΡΕΝ (21.45)&nbsp;&nbsp; Χ2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Αγγλία Κύπελλο', '1452019175', '12032121_1487480728215451_673998168563287595_n.jpg', '<p><span style="font-size:16px">517. ΣΤΟΟΥΚ-ΛΙΒΕΡΠΟΥΛ (22.00) 2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πρόταση 6/1/2016', '1452106638', 'images.jpg', '<p>560.ΝΑΠΟΛΙ-ΤΟΡΙΝΟ (21.45)&nbsp; 4-6 ΓΚΟΛ</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 7/1/2016', '1452150055', 'soccer.jpg', '<p><span style="font-size: 16px;">567.ΓΙΑΝΝΕΝΑ-ΠΑΝΑΘΗΝΑΙΚΟΣ (15.00)&nbsp; ΗΜ Χ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Σύστημα τετράδες από Γαλλία ', '1452268539', '12032121_1487480728215451_673998168563287595_n.jpg', '<p>&nbsp;</p><p><span style="font-size:16px"><span style="color:#FF0000">ΩΡΑ ΕΝΑΡΞΗΣ 21.ΟΟ</span></span></p><p>&nbsp;</p><p><span style="font-size:16px">595.ΑΖΑΞΙΟ-ΧΑΒΡΗ&nbsp;&nbsp; 2</span></p><p><span style="font-size:16px">599.ΝΙΜ-ΜΠΡΕΣΤ 2</span></p><p><span style="font-size:16px">602.ΠΑΡΙ-ΤΟΥΡ 2</span></p><p><span style="font-size:16px">603.ΑΒΡΑΝΣ-ΟΡΛΕΑΝ 2</span></p><p><span style="font-size:16px">609.ΣΑΤΟΡΟΥ-ΣΕΝΤΑΝ 1</span></p><p><span style="font-size:16px">610.ΜΠΑΣΤΙΑ-ΝΤΟΥΝΚΕΡΟΥΕ 1</span></p><p>&nbsp;</p><p><span style="font-size:16px"><span style="color:#0000FF">ΖΗΤΑΜΕ ΤΕΤΡΑΔΕΣ...</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσες 9/1/2016', '1452342785', 'images.jpg', '<p><span style="font-size:16px">795.ΑΤΡΟΜΗΤΟΣ-ΠΛΑΤΑΝΙΑΣ (15.00)&nbsp; Χ</span></p><p><span style="font-size:16px">807.ΣΕΒΙΛΛΗ-ΑΘΛΕΤΙΚ ΜΠΙΛΜΠΑΟ (19.15)&nbsp; 1</span></p><p><span style="font-size:16px">815.ΑΝΖΕ-ΚΑΕΝ (21.00)&nbsp; 2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πρόταση 11.1.2016', '1452506192', 'goal11.jpg', '<p><span style="font-size:16px">968.ΜΕΤΣ-ΣΟΣΟ &nbsp;21.30 &nbsp; 2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Πέμπτη 14/01/2016', '1452758872', '12032121_1487480728215451_673998168563287595_n_1.jpg', '<p><span style="font-size: 16px;">1180. ΓΡΑΝΑΔΑ-ΒΑΛΕΝΘΙΑ (21.00) Χ/2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις  15/01/2016', '1452868691', 'soccer.jpg', '<p>1239. ΝΙΣ-ΑΝΖΕ (21.30) 2</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Ενα Γαλλικό για σήμερα ...', '1452947051', 'soccer_0.jpg', '<p>1455. ΤΡΟΥΑ -ΡΕΝ&nbsp; (21.00)&nbsp; Χ/2</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 17/01/2016', '1453028949', '12032121_1487480728215451_673998168563287595_n.jpg', '<p><span style="font-size:16px">1509. ΚΙΕΒΟ-ΕΜΠΟΛΙ (16.00)&nbsp;&nbsp; 2</span></p><p><span style="font-size:16px">1566.ΣΤΟΟΥΚ-ΑΡΣΕΝΑΛ (18.15) 2</span></p><p><span style="font-size:16px">1618.ΜΙΛΑΝ-ΦΙΟΡΕΝΤΙΝΑ (21.45) 1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 22/01/2016 ημέρα Παρασκευή', '1453469669', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="font-size:16px">1938.ΟΣΕΡ-ΤΟΥΡ (21.00)&nbsp; 2</span></p><p><span style="font-size:16px">1939.ΠΑΡΙ-ΣΟΣΟ(21.00) 2</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΠΡΟΣΦΟΡΑ 2WINBET ', '1453470210', '1stbonus_b.jpg', '<p>&nbsp;</p><p><span style="font-size:16px"><span style="color:rgb(255, 0, 0)">ΚΑΝΤΕ ΕΓΓΡΑΦΗ ΚΑΙ ΠΛΗΚΤΡΟΛΟΓΕΙΣΤΕ ΚΩΔΙΚΟ ΕΓΓΑΦΗΣ ΤΟ 14936</span></span></p><p><span style="font-size:14px"><span style="color:rgb(0, 0, 205)">1η Επιλογή</span>: Επιστροφή 1ης Κατάθεσης 50% έως 100€</span></p><div class="text_exposed_show"><p><span style="font-size:14px">Ανοίξτε τον λογαριασμό σας δωρεάν, κάντε μια κατάθεση στην 2Winbet και θα σας δώσουμε επιστροφή της πρώτης κατάθεσης σας μέχρι € 100.<br>Για να διεκδικήσετε το Bonus Επιστροφής:</span></p><p><span style="font-size:14px">Όταν χαθεί η 1η σας κατάθεση στην πλατφόρμα του στοιχήματος θα μας στείλετε ένα email και θα ζητήσετε την Επιστροφή. ( eggrafa@2winbet.gr )</span></p><p><span style="font-size:14px">Αν δεν έχετε ταυτοποιηθεί θα επισυνάψετε και τα έγγραφα για την ταυτοποίηση σας ( Ταυτότητα 2ο όψεις και πρόσφατο λογαριασμό ΔΕΚΟ / Κινητής Τηλεφωνίας ή υπεύθυνη Δήλωση του νόμου 105 στο email: ( eggrafa@2winbet.gr )</span></p><p><span style="font-size:14px"><span style="color:rgb(0, 0, 255)">2η Επιλογή</span>: 100% έως 100€ Δωρεάν Στοίχημα με την 1η Κατάθεση</span></p><p><span style="font-size:14px">Ανοίξτε τον λογαριασμό σας δωρεάν, κάντε μια κατάθεση στην 2Winbet και θα σας δώσουμε 100% έως 100€ Δωρεάν Στοίχημα (Free Bet)</span></p></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 23/01/2016', '1453539641', 'soccer_0_0.jpg', '<p><span style="font-size: 16px;">1996.ΑΣΚΟΛΙ-ΒΙΡΤΟΥΣ (16.00) 2</span></p><p><span style="font-size: 16px;">2000.ΝΟΒΑΡΑ-ΚΡΟΤΟΝΕ (16.0) ΓΚΟΛ<br>2054.ΛΕΣΤΕΡ-ΣΤΟΟΥΚ (17.00) 1</span></p><p><span style="font-size: 16px;">2177.ΛΟΥΓΚΟ-ΟΒΙΕΔΟ (19.00) 1</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('   EURO 2016 Κύπρος -Βοσνία (21.45)', '1444724697', 'picture-334-1453560153.gif', '<p style="text-align: justify;"><span style="font-size:16px"><span style="color:rgb(0, 0, 255)">Ενα ματς τελικός..</span>.Ιστορικής σημασίας το παιχνίδι για τους Κυπρίους που έχουν την ευκαιρία να διεκδηκήσουν την παρουσια τους&nbsp; στα τελικά του Εuro 2016 στη Γαλλία. Μετά το μεγάλο διπλό μέσα στο ισραήλ (1-2) χρειάζονται μόνο νική επί της Βοσνίας για να καταλάβουν τη 3η θέση και ταυτόχρονα να μη κερδίσει το ισραήλ στο Βέλγιο που έχει μεγάλο βαθμό δυσκολίας.<span style="color:#0000FF">Από την άλλη η Βοσνία</span> βολέυεται και με την ισοπαλία αφου έκανε το χρεος της και νίκησε την Ουαλία 2-0 .Χωρίς αγωνιστικά προβλήματα αμφότεροι. Γεμάτο και ατμόσφαιρα στο ΓΣΠ..</span></p><p style="text-align: justify;"><span style="font-size:16px"><span style="color:rgb(255, 0, 0)">ΕΚΤΙΜΗΣΗ : 1Χ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Κυριακή 24/01/2016', '1453633513', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="font-size:16px">2258.ΛΑΤΣΙΟ-ΚΙΕΒΟ (16.00) Χ2</span></p><p><span style="font-size:16px">2350.ΓΙΟΥΒΕΝΤΟΥΣ-ΡΟΜΑ (21.45) Χ/2</span></p><p><span style="font-size:16px">2351.ΛΥΩΝ-ΜΑΡΣΕΙΓ (22.00) Χ2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακή 25/10/2015', '1445755590', 'picture-348-1454121868.gif', '<p><span style="font-size:16px"><span style="color:#FF0000">2590</span>.&nbsp; <span style="color:#DAA520">ΝΤΙΝΑΜΟ ΜΟΣΧΑΣ - ΣΠΑΡΤΑΚ ΜΟΣΧΑΣ (13.30)</span>&nbsp; <span style="color:#0000FF">UNDER</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2594.</span><span style="color:#DAA520"> ΜΑΓΙΟΡΚΑ - ΑΛΜΕΡΙΑ (14.00)</span> <span style="color:#0000FF">ΓΚΟΛ </span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2690. </span><span style="color:#DAA520">ΜΙΛΑΝ -ΣΑΣΣΟΥΟΛΟ (16.00)</span>&nbsp; <span style="color:#0000FF">1</span></span></p><p><span style="font-size:16px"><span style="color:#FF0000">2759.</span> <span style="color:#DAA520">ΠΑΝΙΩΝΙΟΣ - ΒΕΡΟΙΑ (17.15)</span>&nbsp; <span style="color:#0000FF">1</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 30/01/2016', '1454173831', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p>948.ΤΡΟΥΑ-ΝΑΝΤ (21.00)&nbsp; χ/2</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Καλό μήνα και καλά κέρδη', '1454317127', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="font-size:18px">1188.ΛΑ ΚΟΡΟΥΝΙΑ-ΒΑΓΙΕΚΑΝΟ (21.30)&nbsp; Χ/1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 4/2/2016', '1454572615', 'images.jpg', '<p><span style="color:#FF0000">1456.</span><span style="color:#DAA520">ΡΕΝ-ΣΕΝΤ ΕΤΙΕΝ (22.00)</span>&nbsp;&nbsp; <span style="color:#0000FF">Χ/1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 5/2/2016', '1454663445', '12032121_1487480728215451_673998168563287595_n.jpg', '<p><span style="font-size:16px">1514.ΝΑΝΣΙ-ΜΕΤΣ (21.00)&nbsp; 1</span></p><p><span style="font-size:16px">1519.ΛΑΒΑΛ-ΑΖΑΞΙΟ (21.00)&nbsp; Χ</span></p><p><span style="font-size:16px">1520.ΤΟΥΡ-ΛΑΝΣ (21.00) 1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Euroleague', '1454663636', 'euroleague.jpg', '<p><span style="color:#DAA520">3559.ΟΛΥΜΠΙΑΚΟΣ-ΚΙΜΚΙ (21.45)&nbsp; ΟΒΕΡ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Σαββάτου 06/02/2016', '1454745391', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="color:#DAA520"><span style="font-size:18px">1580. ΜΟΝΑΚΟ-ΝΙΣ (15.00) 1</span></span></p><p><span style="color:#DAA520"><span style="font-size:18px">1604.ΑΣΚΟΛΙ-ΛΑΤΙΝΑ (16.00)1</span></span></p><p><span style="color:#DAA520"><span style="font-size:18px">1780.ΒΑΓΙΚΑΝΟ-ΛΑΣ ΠΑΛΜΑΣ (19.15)&nbsp; 1</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Κυριακή 7/2/2016', '1454861160', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="font-size:18px"><span style="background-color:#DAA520">2036. ΡΟΜΑ-ΣΑΜΠΝΤΟΡΙΑ (21.45)&nbsp; Χ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Δευτέρα 8/2/2016', '1454937183', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="color:#FF0000"><span style="font-size:18px">2114.ΧΑΒΡΗ-ΝΤΙΖΟΝ (21.30)&nbsp;&nbsp;&nbsp; Χ/Χ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 9/2/2016', '1455004919', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="font-size:18px"><span style="color:rgb(218, 165, 32)">2326.ΣΟΣΟ-ΜΟΝΑΚΟ (22.00) Χ/Χ&nbsp;&nbsp; </span></span></p><p>&nbsp;</p><p><span style="font-size:18px"><span style="color:rgb(218, 165, 32)">ΣΚΟΡ&nbsp; 2-2</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 12/2/2016', '1455271218', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="font-size:16px">2433.ΟΣΕΡ-ΝΑΝΣΙ (21.00)&nbsp; Χ/Χ</span></p><p><span style="font-size:16px">2435.ΝΤΙΖΟΝ-ΣΟΣΟ (21.00) 2/Χ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 14/2/2016', '1455476281', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="font-size:16px">1038.ΝΙΣ -ΜΑΡΣΕΙΓ (22.00) Χ/2</span></p><p>&nbsp;</p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 15/2/2016', '1455557513', '12032121_1487480728215451_673998168563287595_n.jpg', '<p><span style="color:#DAA520"><span style="font-size:18px">1115.ΛΑΝΣ-ΒΑΛΕΝΣΙΕΝ (21.30)&nbsp; Χ2</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακή 06/12/2015', '1449385378', 'picture-391-1455683691.gif', '<p><span style="font-size:16px">2006.ΒΙΛΕΜ-ΚΑΜΠΟΥΡ (13.30)&nbsp; ΓΚΟΛ</span></p><p><span style="font-size:16px">2053.ΠΑΟΚ-ΠΑΝΙΩΝΙΟΣ (15.00) ΗΜ Χ</span></p><p><span style="font-size:16px">2117.ΤΟΥΝ-ΒΑΣΙΛΕΙΑ (17.00)&nbsp; 2</span></p><p><span style="font-size:16px">2242.ΚΑΡΠΙ-ΜΙΛΑΝ (21.45)&nbsp;&nbsp; Χ/2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('ΟΥΕΦΑ Γιουρόπα Λιγκ', '1449757234', 'picture-396-1456216506.gif', '<p><span style="font-size:16px">2428.ΜΠΟΡΝΤΟ-ΡΟΥΜΠΙΝ ΚΑΖΑΝ (20.00) ΙΧ</span></p><p><span style="font-size:16px">2432.ΣΙΟΝ-ΛΙΒΕΡΠΟΥΛ(20.00) Χ/2</span></p><p><span style="font-size:16px">2445.ΤΟΤΕΝΑΜ-ΜΟΝΑΚΟ(22.05) ΗΜ Χ</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('21/12/2015', '1450682007', 'picture-407-1456587966.gif', '<p><span style="font-size: 16px;">1761.ΚΑΛΛΙΘΕΑ-ΟΛΥΜΠΙΑΚΟΣ ΒΟΛΟΥ (15.00)&nbsp; Χ</span></p><p><span style="font-size: 16px;">1778. ΑΡΣΕΝΑΛ -ΜΑΝΤΣΕΣΤΕΡ ΣΙΤΙ 1/1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('708. ΑΤΛΕΤΙΚΟ ΜΑΔΡΙΤΗΣ-ΜΠΑΡΤΣΕΛΟΝΑ ', '1460530984', '090316114627_7268.jpg', '<p><span style="font-size:14px"><span style="color:#FF0000"><span style="font-size:16px"><strong>708. Ατλέτικο Μαδρίτης – Μπαρτσελόνα</strong></span></span></span></p><p><span style="font-size:14px"><strong>13/4&nbsp; 21:45</strong></span></p><p>&nbsp;</p><p><span style="font-size:14px"><strong>Προϊστορία:</strong> &nbsp;2012(1-2), 2013(1-2), 2014(0-0), 2015(0-1), 2016(1-2)</span></p><p>&nbsp;</p><p><span style="font-size:14px"><span style="color:#0000FF"><strong><u>Εκτίμηση :</u></strong> </span>&nbsp; . Η Μπάρτσα γύρισε το εις βάρος της 0-1 σε 2-1 με δύο τέρματα από τον Σουάρες (63′ , 74′) κι έτσι γλίτωσε από ένα βατερλό που θα την έστελνε με μεγάλη πιθανότητα εκτός ημιτελικών Champions League. Οι μπλαουγκράνα γνωρίζουν πολύ καλά ότι θα έχουν δύσκολο αγώνα στο Βιθέντε Καλντερόν για να υπερασπιστούν τα κεκτημένα από το πρώτο ματς και γι” αυτό δεν αποκλείεται να δούμε να ξεκινάει με αμυντικούς προσανατολισμούς ο Λουΐς Ενρίκε (από τις ελάχιστες φορές που συμβαίνει σε αγώνες της Μπαρτσελόνα αυτό). Ο Γκοντίν δίνει κανονικά το παρόν για την ομάδα του Σιμεόνε ενώ η Μπαρτσελόνα παίζει με όλα τα αστέρια της. Η γνώμη μας είναι ότι και πάλι θα δούμε γκολ εκατέρωθεν οπότε θα προτείνουμε το <span style="color:#DAA520">g/g.</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('709.ΜΠΕΝΦΙΚΑ-ΜΠΑΓΕΡΝ', '1460531173', '090316114627_7268.jpg', '<p><span style="font-size:16px"><span style="color:rgb(255, 0, 0)"><strong>709. Μπενφίκα – Μπάγερν</strong></span></span></p><p><strong>13/4&nbsp; 21:45</strong></p><p>&nbsp;</p><p><strong>Προϊστορία:</strong> &nbsp;Δεν υπάρχει την τελευταία πενταετία</p><p>&nbsp;</p><p><span style="color:#0000FF"><strong><u>Εκτίμηση :</u></strong> </span>&nbsp; . Το 1-0 είναι το πιο πονηρό σκορ που θα μπορούσε να έρθει αφού δίνει αφ” ενός πολλές ελπίδες στους Πορτογάλους αλλά ταυτόχρονα κάνει ακλόνητο φαβορί την Μπάγερν σε περίπτωση που αυτή φτάσει στην επίτευξη ενός τέρματος και μόνο. Είναι γεγονός ότι η ομάδα του Γκουαρντιόλα μόνο στο Emirates έμεινε στο μηδέν στην φετινή της πορεία στο Champions League, αλλά με την άμυνα της Μπενφίκα δεν ξέρουμε αν μπορεί να τα βγάλει πέρα και στο Da Luz. Γκαϊτάν, Ζόνας και Ζούλιο Σέζαρ δε θα παίξουν από πλευράς αετών ενώ για την πρωταθλήτρια Γερμανίας δε θα παίξει ο Ρόμπεν και είναι αμφίβολοι οι Μπενάτια, Μπόατενγκ. Πιστεύουμε στην Μπενφίκα και την στηρίζουμε με την διπλή ευκαιρία υπέρ της.</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Euroleague Basketball ', '1460533427', 'euroleague.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">3442.</span>ΛΟΚΟΜΟΤΙΒ-ΜΠΑΡΤΣΕΛΟΝΑ 1</span></p><p>&nbsp;</p><p><span style="font-size:16px"><span style="color:#FF0000">3443.</span>ΛΑΜΠΟΡΑΛ-ΠΑΝΑΘΗΝΑΙΚΟΣ 2</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES (' Hellenic Volleyball League', '1460533688', 'katalogos.jpg', '<div>&nbsp;</div><div><span style="font-size:14px">Με τον τέταρτο ημιτελικό μεταξύ του ΠΑΟΚ και του Ολυμπιακού συνεχίζεται η συγκλονιστική σειρά των δύο ομάδων, με φόντο την πρόκριση στον τελικό της Volleyleague. Ο ΠΑΟΚ προηγείται με 2-1 νίκες, ενώ ο Ολυμπιακός ευελπιστεί στην ισοφάριση και να διεκδικήσει την πρόκριση στο Ρέντη (4ος ημιτελικός, 13/4, 18.00, Διαιτητές: Γεωργουλέας, Δεληκωστίδης, Novasports-1ΗD).</span></div><div class="itemFullText"><div style="padding: 3px 0 5px 0; float:left; width:728px; margin: 15px 15px 5px 0;  ">&nbsp;</div><div><span style="font-size:14px">O ΠΑΟΚ γιορτάζει σήμερα (12/4) τα 90α γενέθλια του και ο Γιάννης Καλμ</span></div><div><span style="font-size:14px">αζίδης και οι παίκτες του θέλουν α κάνουν το καλύτερο δώρο στον σύλλογο. Ο δικέφαλος μετά τις δύο νίκες στο Ρέντη έχει δεύτερη και τελευταία ευκαιρία για να αξιοποιήσει την έδρα του ώστε να κάνει το 3-1 στις νίκες και να πάει στους τελικούς, διαφορετικά θα πρέπει να διεκδικήσει την πρόκριση σε πέμπτο αγώνα που θα γίνει στο «Μελίνα Μερκούρη» του Ρέντη.<br><br>Ο Ολυμπιακός έχει γεμίσει τις μπαταρίες του αγωνιστικά και ψυχολογικά μετά τη νίκη στον τρίτο ημιτελικό και ο Ρομπέρτο Πιάτσα, όπως και οι παίκτες του πιστεύουν πως είναι ικανοί για την ισοφάριση ώστε να οδηγήσουν την σειρά σε πέμπτο αγώνα στο Ρέντη.</span></div><div>&nbsp;</div><div><span style="font-size:14px">ΠΗΓΗ:</span>http://www.volleynews.gr/</div></div>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('UEFA Europa League', '1460620589', 'm.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">799.</span><span style="color:#FF8C00">ΣΕΒΙΛΛΗ-ΑΘΛΕΤΙΚ ΜΠΙΛΜΠΑΟ</span> <span style="color:#0000FF">ΗΜ Χ</span></span></p><p>&nbsp;</p><p><span style="font-size:16px"><span style="color:#FF0000">802.</span><span style="color:#DAA520">ΣΠΑΡΤΑ ΠΡΑΓΑΣ-ΒΙΓΙΑΡΕΑΛ&nbsp;</span><span style="color:#0000FF"> ΗΜ Χ</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Euroleague Basketball', '1460620963', 'euroleague.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">3462. ΦΕΝΕΡ- ΡΕΑΛ 1</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Στημενα παιχνίδια -Απάτες', '1460625885', 'fixed-match-sites1.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">Στημένα παιχνίδια στο στοίχημα… η μεγάλη απάτη μέσω Facebook ή συνδρομητικά sites και πως σας κλέβουν!</span></span></p><p>&nbsp;</p><p>Στημένα παιχνίδια στο στοίχημα και αβαβα προγνωστικά… μια μεγάλη απάτη τα τελευταία χρόνια παίζεται επάνω στους παίκτες του στοιχήματος φυσικά μιλάμε για τους <strong>στημένους αγώνες</strong> και τα θύματα τους κάναμε μια έρευνα και βρήκαμε τους τρόπους με τους οποίους προσπαθούν και πολλές φορές επιτυγχάνουν να εξαπατήσουν τους παίκτες… διαβάστε τους με προσοχή…</p><p>&nbsp;</p><p>Χθες βράδυ έβαλα στο Google να ψάξει για «στημένα παιχνίδια» ή αλλιώς «fixed matches». Και μάλιστα έβαλα Ειδήσεις τελευταίων 24 ωρών. Είναι πραγματικό τρομερό πως η αναζήτηση έβγαλε πάνω από 800 αποτελέσματα. Μάλιστα, στις περισσότερες από αυτές τις περιπτώσεις, το αποτέλεσμα της αναζήτησης με οδηγούσε σε ιστοσελίδες (websites) που υπόσχονταν σίγουρη επιτυχία σε περίπτωση που κάποιος στοιχημάτιζε σε παιχνίδι που ήταν… στημένο.</p><p><strong>Ενδεικτικά αναφέρω μερικά από τα αποτελέσματα:</strong><br>best-soccer-tips1x2.com, προσφερόταν next fixed match για τις 12.09.2015. Το στοίχημα ήταν είτε 2/1 είτε 1/2 για ημίχρονο/τελικό, δηλαδή ανατροπή, και μάλιστα εγγυόταν και 100% επιτυχία. Επίσης, παραθέτονταν και οι μέθοδοι πληρωμής (Skrill, Neteller, Paysafe, Ukash, Payoneer ή Moneygram) κατόπιν φυσικά αποστολής email Απίστευτα πράγματα!!!</p><p>&nbsp;</p><p><strong>brag-tips.sportal.tips</strong> περηφανευόταν πως έχει παιχνίδι για τις 11.09.2015. Για την ακρίβεια, το ακριβές σκορ ενός αγώνα με απόδοση πάνω από 100.00, κάτι το οποίο επίσης είναι 100% σίγουρο! Μάλιστα, στη συγκεκριμένη ιστοσελίδα υπήρχαν και παραδείγματα αγώνων που «επαληθεύτηκαν», από τον Μάρτιο του 2015 μέχρι και σήμερα. Και μιλάμε για ακριβή σκορ με αποδόσεις από 41.00 μέχρι και 181.00!</p><p>&nbsp;</p><p><strong>Χρησιμοποιούν ονόματα ακόμη και διεθνών ποδοσφαιριστών!</strong><br>Προξενεί ακόμη μεγαλύτερη εντύπωση το γεγονός πως υπάρχουν ιστοσελίδες που χρησιμοποιούν ονόματα ακόμη και διεθνών ποδοσφαιριστών για να ανέβουν στο ranking της Alexa και να βρίσκονται πολύ ψηλότερα στις μηχανές αναζήτησης.</p><p>Παράδειγμα η benzema1x2.com, με ευθεία αναφορά στον διεθνή Γάλλο επιθετικό της Real Madrid, Karim Benzema. Η συγκεκριμένη ιστοσελίδα έχει και κάποιες ιδιαιτερότητες: κοκορεύεται πως έχει συνεργάτες σε Τουρκία, Γερμανία, Ιταλία, Κροατία παραθέτοντας μάλιστα τα ονόματα των συνεργατών. Για να μην βρεθώ προ δυσάρεστων εκπλήξεων, πουθενά εδώ δεν αναφέρεται ο όρος fixed matches, ωστόσο υπάρχει σιγουριά για πάνω από 95% επιτυχία σε παιχνίδια με αποδόσεις 2.50-3.50 και πάνω από 90% για παιχνίδια σε αποδόσεις 15.00-20.00! Ανάλογα πάντα με την… συνδρομή που θα επιλέξει κανείς να κάνει εγγραφή.</p><p>Πηγή <a href="http://www.stoiximaonline.com/2015/09/stimena-paixnidia-super-apodoseis/" target="_blank">stoiximaonline.com</a></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Παρασκευής ', '1460715023', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="font-size:16px"><span style="color:#FF0000">860.</span> <span style="color:#0000FF">ΛΑΒΑΛ-ΕΒΙΑΝ&nbsp; 21.00&nbsp;&nbsp;&nbsp; Χ2 </span></span></p><p>&nbsp;</p><p><span style="font-size:16px"><span style="color:#FF0000">861</span>.<span style="color:#0000FF">ΤΟΥΡ-ΝΙΜ 21.00&nbsp;&nbsp; 1</span></span></p><p>&nbsp;</p><p><span style="font-size:16px"><span style="color:#FF0000">898.</span><span style="color:#0000FF">ΠΕΣΚΑΡΑ-ΤΣΕΖΕΝΑ&nbsp; 22.00&nbsp;&nbsp; 1</span></span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('EuroleagueBasketball', '1460716980', 'euroleague.jpg', '<p>Χωρις πολλά πολλά νομίζω ασσακια και τα δυο!!!!δε με επεισαν ουτε ο παο ούτε η Μπαρτσα για διπλό.<br>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Σαββάτο 16/4/16', '1460789400', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="color:#0000FF">971. ΧΑΒΡΗ -ΝΑΝΣΙ 15.00&nbsp; Χ</span></p><p>&nbsp;</p><p><span style="color:#0000FF">989.ΝΟΒΑΡΑ-ΛΙΒΟΡΝΟ&nbsp; 16.00&nbsp;&nbsp; ΓΚΟΛ</span></p><p>&nbsp;</p><p><span style="color:#0000FF">1150. ΛΟΡΙΑΝ-ΤΟΥΛΟΥΖ 21.00&nbsp; 2</span></p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακής 17/4/16', '1460876984', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="color:#0000FF">1313,ΟΥΝΤΙΝΕΖΕ - ΚΙΕΒΟ 16.00&nbsp; 1</span></p><p>&nbsp;</p><p><span style="color:#0000FF">1397.ΠΛΑΤΑΝΙΑΣ-ΠΑΟΚ 19.00&nbsp;&nbsp; ΗΜ Χ</span></p><p>&nbsp;</p><p><span style="color:#0000FF">1400.&nbsp; ΛΑΤΣΙΟ- ΕΜΠΟΛΙ&nbsp; 19.00&nbsp; ΓΚΟΛ</span></p><p>&nbsp;</p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Δευτέρα 18/4/2016', '1460977515', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="color:#FF0000">1491.ΟΥΡΑΛ -ΡΥΜΠΙΝ ΚΑΖΑΝ&nbsp; 17.00&nbsp;&nbsp; UNDER </span></p><p>&nbsp;</p><p><span style="color:#FF0000">1526.NTIZON-ΠΑΡΙ 21.00&nbsp; GOAL</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Τρίτη 19/04/2016', '1461060306', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="color:#0000FF">1728. ΕΣΠΑΝΙΟΛ-ΘΕΛΤΑ&nbsp;&nbsp; 21.00&nbsp;&nbsp; 2</span></p><p>&nbsp;</p><p><span style="color:#0000FF">1732.ΑΣΚΟΛΙ-ΜΠΑΡΙ&nbsp; 21.30 ΓΚΟΛ</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Τετάρτη  20/04/2016', '1461144512', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="color:#FF0000">1827. ΧΑΚΑ-ΡΟΒΑΝΙΕΜΙ&nbsp; 17.00&nbsp;&nbsp; ΓΚΟΛ</span></p><p>&nbsp;</p><p><span style="color:#FF0000">1627.ΠΑΛΕΡΜΟ-ΑΤΑΛΑΝΤΑ 21.45&nbsp;&nbsp; 1</span></p><p>&nbsp;</p><p><span style="color:#FF0000">1633.ΕΜΠΟΛΙ-ΒΕΡΟΝΑ 21.45&nbsp;&nbsp; 2-3 ΓΚΟΛ</span></p><p>&nbsp;</p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Πέμπτη 21/04/16', '1461244090', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p>1635. ΜΙΛΑΝ-ΚΑΡΠΙ 21.45&nbsp;&nbsp; 1/1</p><p>&nbsp;</p><p>1970. ΓΡΑΝΑΔΑ-ΛΕΒΑΝΤΕ 22.00&nbsp; 2/Χ</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 22/4/2016', '1461331607', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="color:#0000FF">2050. ΚΛΕΡΜΟΝ-ΤΟΥΡ 21.00 1</span></p><p>&nbsp;</p><p><span style="color:#0000FF">2076.ΝΙΣ-ΡΕΜΣ&nbsp; 21.30&nbsp; 1</span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις Κυριακή 24/4/2016  ', '1461516767', '12072671_1488983581398499_3595698289145083732_n.jpg', '<p><span style="color:#0000FF"><span style="font-size:16px">2670. ΓΚΕΝΚ -ΓΑΝΔΗ 21.30&nbsp; Χ/Χ</span></span></p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('Προτάσεις 25/4/2016', '1461578066', '12032121_1487480728215451_673998168563287595_n.jpg', '<p><span style="color:#FF8C00">2712. ΡΟΜΑ-ΝΑΠΟΛΙ 16.00&nbsp;&nbsp;&nbsp; ΗΜ Χ</span></p><p>&nbsp;</p><p><span style="color:#FF8C00">2717.ΒΕΡΟΝΑ-ΜΙΛΑΝ 18.00 ΗΜ 2</span></p><p>&nbsp;</p><p>&nbsp;</p>');
INSERT INTO "bet_article" (title,created,body,image) VALUES ('UEFA Champions League', '1461648927', '090316114627_7268.jpg', '<p><span style="color:#FF0000"><span style="font-size:16px">534.&nbsp; ΜΑΝΤΣΕΣΤΕΡ ΣΙΤΙ ` - ΡΕΑΛ ΜΑΔΡΙΤΗΣ&nbsp; 21.45</span></span></p><p style="text-align: justify;">&nbsp;</p><p style="text-align: justify;">&nbsp;</p><div id="articleTranscript"><p style="text-align: justify;"><span style="font-size:14px">Τα ημιτελικά του <a href="http://gr.euronews.com/tag/champions-league/" target="_blank" title="Περισσότερα για: Τσάμπιονς Λιγκ">Τσάμπιονς Λιγκ</a> ξεκινάνε με το πολύ μεγάλο ντέρμπι της Μάντσεστερ Σίτι με την Ρεάλ Μαδρίτης.</span></p><p style="text-align: justify;"><span style="font-size:14px">Οι «πολίτες» έχουν πραγματοποιήσει φέτος την πορεία που ήθελαν στην Ευρώπη και θέλουν να κάνουν ακόμη ένα βήμα, με την πρόκριση τους στον τελικό.</span></p><p style="text-align: justify;"><span style="font-size:14px">Με τις εξαιρετικές εμφανίσεις στα προημιτελικά απέναντι στην Παρί Σεν Ζερμέν, η ομάδα του Πελεγκρίνι έδειξε πως δεν πρέπει να υποτιμηθεί από κανέναν αντίπαλο.</span></p><p style="text-align: justify;"><span style="font-size:14px">Φυσικά το ενδεχόμενο ενός τελικού της Σίτι με την Μπάγερν Μονάχου, ομάδα του Πεπ Γκουαρντιόλα, επόμενου προπονητή των Άγγλων, είναι άκρως δελεαστικό.</span></p><p style="text-align: justify;"><span style="font-size:14px">Από την άλλη πλευρά, η Ρεάλ Μαδρίτης έχει βάλει πλώρη για τον ενδέκατο ευρωπαϊκό τρόπαιο.</span></p><p style="text-align: justify;"><span style="font-size:14px">Με τον Ζινεντίν Ζιντάν στον πάγκο, η «Βασίλισσα» έχει εννέα συνεχόμενες νίκες στο πρωτάθλημα καθώς και την πρόκριση επί της Βόλφσμπουργκ με ανατροπή σκορ από τον πρώτο αγώνα.</span></p><p style="text-align: justify;"><span style="font-size:14px">Δεδομένου ότι απέφυγε τη Μπάγερν Μονάχου στα ημιτελικά καθώς και το ότι το πρώτο ματς με τη Σίτι είναι εκτός έδρας, η ομάδα της Μαδρίτης έχει όλα τα φόντα να φτάσει ως τον τελικό.</span></p><p style="text-align: justify;">&nbsp;</p><p style="text-align: justify;"><span style="color:#0000FF"><span style="font-size:14px">ΠΡΟΤΑΣΗ&nbsp; :Χ2</span></span></p></div><p>&nbsp;</p>');
COMMIT;

PRAGMA foreign_keys = true;
